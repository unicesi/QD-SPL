package org.openarchitectureware.adapter.rsdp.workflow;

public abstract class AbstractURIMapEntry {

   private String path;

   public AbstractURIMapEntry() {
      this(null);
   }

   public AbstractURIMapEntry(String path) {
      this.path = path;
   }

   public String getPath() {
      return path;
   }

   public void setPath(String location) {
      this.path = location;
   }

   public abstract String getMappedURI();
}
