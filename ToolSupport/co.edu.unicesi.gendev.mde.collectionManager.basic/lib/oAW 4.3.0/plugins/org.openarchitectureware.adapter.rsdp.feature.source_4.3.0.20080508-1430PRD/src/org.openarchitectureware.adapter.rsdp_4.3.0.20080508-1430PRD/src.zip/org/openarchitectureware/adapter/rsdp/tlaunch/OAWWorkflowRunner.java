package org.openarchitectureware.adapter.rsdp.tlaunch;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationType;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.ui.DebugUITools;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.search.IJavaSearchConstants;
import org.eclipse.jdt.core.search.IJavaSearchScope;
import org.eclipse.jdt.core.search.SearchEngine;
import org.eclipse.jdt.core.search.SearchMatch;
import org.eclipse.jdt.core.search.SearchParticipant;
import org.eclipse.jdt.core.search.SearchPattern;
import org.eclipse.jdt.core.search.SearchRequestor;
import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
import org.eclipse.uml2.uml.Model;
import org.openarchitectureware.adapter.rsdp.plugin.Activator;
import org.openarchitectureware.workflow.WorkflowRunner;

/**
 * @author rschoon
 * 
 */
public class OAWWorkflowRunner {
	Map<String, String> properties = null;

	Map<String, Object> slotContents = null;

	/**
	 * 
	 */
	public OAWWorkflowRunner() {
		this.properties = new HashMap<String, String>();
		this.slotContents = new HashMap<String, Object>();
	}

	/**
	 * @param key
	 * @param value
	 * @return
	 */
	public Object addSlot(String key, Object value) {
		return slotContents.put(key, value);
	}

	/**
	 * @param key
	 * @param value
	 * @return
	 */
	public Object addProperty(String key, String value) {
		return properties.put(key, value);
	}

	// 77932 ERROR WorkflowRunner - Class not found: 'oaw.uml2.Setup' [bean bean
	// class='oaw.uml2.Setup' in
	// C:\\rsdp7.0_beta\\runtime-New_configuration\\oaw4.demo.emf.uml2.generator\\src\\workflow.oaw:5]
	// 77962 ERROR WorkflowRunner - No getter or adder method for property
	// 'standardUML2Setup in clazz 'java.lang.Object' found
	// [standardUML2Setup='true' in
	// C:\\rsdp7.0_beta\\runtime-New_configuration\\oaw4.demo.emf.uml2.generator\\src\\workflow.oaw:5]
	// 77962 ERROR WorkflowRunner - Class not found: 'oaw.emf.XmiReader' [bean
	// component class='oaw.emf.XmiReader' in
	// C:\\rsdp7.0_beta\\runtime-New_configuration\\oaw4.demo.emf.uml2.generator\\src\\workflow.oaw:7]
	// 77962 ERROR WorkflowRunner - No getter or adder method for property
	// 'modelFile in clazz 'org.openarchitectureware.workflow.WorkflowComponent'
	// found [modelFile='example.uml' in
	// C:\\rsdp7.0_beta\\runtime-New_configuration\\oaw4.demo.emf.uml2.generator\\src\\workflow.oaw:8]
	// 77962 ERROR WorkflowRunner - No getter or adder method for property
	// 'outputSlot in clazz
	// 'org.openarchitectureware.workflow.WorkflowComponent' found
	// [outputSlot='model' in
	// C:\\rsdp7.0_beta\\runtime-New_configuration\\oaw4.demo.emf.uml2.generator\\src\\workflow.oaw:9]
	// 77962 ERROR WorkflowRunner - Class not found: 'oaw.xpand2.Generator'
	// [bean component class='oaw.xpand2.Generator' id='generator' in
	// C:\\rsdp7.0_beta\\runtime-New_configuration\\oaw4.demo.emf.uml2.generator\\src\\workflow.oaw:12]
	// 77962 ERROR WorkflowRunner - No getter or adder method for property
	// 'skipOnErrors in clazz
	// 'org.openarchitectureware.workflow.WorkflowComponent' found
	// [skipOnErrors='true' in
	// C:\\rsdp7.0_beta\\runtime-New_configuration\\oaw4.demo.emf.uml2.generator\\src\\workflow.oaw:12]
	// 77962 ERROR WorkflowRunner - No getter or adder method for property
	// 'metaModel in clazz 'org.openarchitectureware.workflow.WorkflowComponent'
	// found [bean metaModel class='oaw.type.emf.EmfMetaModel' in
	// C:\\rsdp7.0_beta\\runtime-New_configuration\\oaw4.demo.emf.uml2.generator\\src\\workflow.oaw:14]
	// 77962 ERROR WorkflowRunner - No getter or adder method for property
	// 'metaModel in clazz 'org.openarchitectureware.workflow.WorkflowComponent'
	// found [bean metaModel class='oaw.uml2.UML2MetaModel' in
	// C:\\rsdp7.0_beta\\runtime-New_configuration\\oaw4.demo.emf.uml2.generator\\src\\workflow.oaw:15]
	// 77962 ERROR WorkflowRunner - No getter or adder method for property
	// 'expand in clazz 'org.openarchitectureware.workflow.WorkflowComponent'
	// found [expand='templates::Root::Root FOR model' in
	// C:\\rsdp7.0_beta\\runtime-New_configuration\\oaw4.demo.emf.uml2.generator\\src\\workflow.oaw:16]
	// 77962 ERROR WorkflowRunner - No getter or adder method for property
	// 'outlet in clazz 'org.openarchitectureware.workflow.WorkflowComponent'
	// found [bean outlet in
	// C:\\rsdp7.0_beta\\runtime-New_configuration\\oaw4.demo.emf.uml2.generator\\src\\workflow.oaw:17]
	// 77962 ERROR WorkflowRunner - Workflow interrupted because of
	// configuration errors.

	/**
	 * @param model
	 * @param wfFile
	 */
	public static void launchOAWWorkflow(Model model, String wfFile) {

		// String wfFile = "somePath\\workflow.oaw";
		try {
			Logger.log("Model: " + model.toString());
			Logger.log("Workflow: " + wfFile);
			Logger.log("Run.....: ");
			OAWWorkflowRunner runner = new OAWWorkflowRunner();
			runner.addSlot("model", model);
			runner.run(wfFile);
			Logger.log("end.....: ");
		} catch (RuntimeException e) {
			Logger.log(e);
		}
	}

	public boolean run(String workflowFile) {
		WorkflowRunner runner = new WorkflowRunner();
		// Logger.log("Context: " + runner.getContext().toString());
		return runner.run(workflowFile, null, this.properties, this.slotContents);

	}

	//
	// From Workflow Launcher
	// @see package
	// org.openarchitectureware.eclipse.launch.WorkflowLaunchShortcut
	//
	// Works. How to add the model here ?
	//
	//
	//
	//
	//

	/**
	 * @param model
	 * @param wfFile
	 * @see org.openarchitectureware.eclipse.launch.WorkflowLaunchShortcut
	 */
	public static void launchOAWWorkflow(Model model, IFile wfFile) {
		Logger.log("Model: " + model.toString());
		Logger.log("Workflow: " + wfFile);
		Logger.log("Run.....: ");
		OAWWorkflowRunner runner = new OAWWorkflowRunner();
		runner.addSlot("model", model);
		// Works
		runner.launch(wfFile, "run");
		Logger.log("end.....: ");
	}

	/**
	 * @return
	 * 
	 * @see org.openarchitectureware.eclipse.launch.WorkflowLaunchShortcut
	 */
	protected ILaunchManager getLaunchManager() {
		return DebugPlugin.getDefault().getLaunchManager();
	}

	/**
	 * @see org.openarchitectureware.eclipse.launch.WorkflowLaunchShortcut
	 */
	private IFile currFile;

	/**
	 * @see org.openarchitectureware.eclipse.launch.WorkflowLaunchShortcut
	 */
	private final Map<IPath,ILaunchConfiguration> cache = new HashMap<IPath,ILaunchConfiguration>();

	/**
	 * @see org.openarchitectureware.eclipse.launch.WorkflowLaunchShortcut
	 */
	public void launch(final IFile file, final String mode) {

		currFile = file;
		final IType wfRunner = getWfRunner(currFile);
		if (wfRunner != null) {
			ILaunchConfiguration config = cache.get(currFile.getFullPath());
			if (config == null || !config.exists()) {
				config = createConfiguration(wfRunner);
				// try {
				// final ILaunchConfiguration[] configs =
				// getLaunchManager().getLaunchConfigurations();
				// for (int i = 0; i < configs.length; i++) {
				// final ILaunchConfiguration configuration = configs[i];
				// if (equals(configuration, config)) {
				// config = configuration;
				// break;
				// }
				// }
				// } catch (final CoreException e) {
				// e.printStackTrace();
				// }
				cache.put(currFile.getFullPath(), config);
			}
			DebugUITools.launch(config, mode);
			try {
				currFile.getProject().refreshLocal(IResource.DEPTH_INFINITE, new NullProgressMonitor());
			} catch (CoreException e) {
				Activator.getDefault().getLog().log(e.getStatus());
			}
			// LaunchView.addConfiguration(config, mode, currFile);
			return;
		} else {
			Logger.log("oAW release jars are not on the project's classpath!");

		}
	}

	/**
	 * @see org.openarchitectureware.eclipse.launch.WorkflowLaunchShortcut
	 */
	public class TypeDeclarationSearchRequestor extends SearchRequestor {

		private IType match = null;

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.eclipse.jdt.core.search.SearchRequestor#acceptSearchMatch(org.eclipse.jdt.core.search.SearchMatch)
		 */
		@Override
		public void acceptSearchMatch(final SearchMatch match) throws CoreException {
			this.match = (IType) match.getElement();
		}

		public IType getMatch() {
			return match;
		}
	}

	/**
	 * @return
	 */
	/**
	 * @param resource
	 * @return
	 * 
	 * @see org.openarchitectureware.eclipse.launch.WorkflowLaunchShortcut
	 */
	private IType getWfRunner(final IResource resource) {
		try {
			final IJavaProject project = JavaCore.create(resource.getProject());
			final SearchPattern pattern = SearchPattern.createPattern(WorkflowRunner.class.getName(), IJavaSearchConstants.TYPE,
					IJavaSearchConstants.DECLARATIONS, SearchPattern.R_PATTERN_MATCH | SearchPattern.R_CASE_SENSITIVE);
			final IJavaSearchScope scope = SearchEngine.createJavaSearchScope(new IJavaElement[] { project }, true);
			final TypeDeclarationSearchRequestor requestor = new TypeDeclarationSearchRequestor();

			final SearchEngine searchEngine = new SearchEngine();
			searchEngine.search(pattern, new SearchParticipant[] { SearchEngine.getDefaultSearchParticipant() }, scope, requestor, null);

			return requestor.getMatch();
		} catch (final CoreException e) {
			Logger.log(e);
			return null;
		}
	}

	private static final String WORKFLOW_LAUNCH_CONFIGURATION_TYPE_ID = "org.openarchitectureware.workflow.workflowLaunchConfigurationType";

	private static final String OAW_CONFIGURATION_NAME_PREFIX = "oAW Workflow Runner";

	/**
	 * Create & return a new configuration based on the specified
	 * <code>IType</code>.
	 * 
	 * @see org.openarchitectureware.eclipse.launch.WorkflowLaunchShortcut
	 * 
	 */
	protected ILaunchConfiguration createConfiguration(final IType type) {
		ILaunchConfiguration config = null;
		ILaunchConfigurationWorkingCopy wc = null;
		try {
			final ILaunchConfigurationType configType = getLaunchManager().getLaunchConfigurationType(WORKFLOW_LAUNCH_CONFIGURATION_TYPE_ID);// IJavaLaunchConfigurationConstants.ID_JAVA_APPLICATION);
			wc = configType.newInstance(null, getLaunchManager().generateUniqueLaunchConfigurationNameFrom(OAW_CONFIGURATION_NAME_PREFIX));// type.getElementName()));
		} catch (final CoreException exception) {
			Logger.log(exception);
			return null;
		}
		wc.setAttribute(IJavaLaunchConfigurationConstants.ATTR_MAIN_TYPE_NAME, type.getFullyQualifiedName());
		wc.setAttribute(IJavaLaunchConfigurationConstants.ATTR_PROJECT_NAME, currFile.getProject().getName());
		// add the workflow file
		wc.setAttribute(IJavaLaunchConfigurationConstants.ATTR_PROGRAM_ARGUMENTS, "\"" + currFile.getLocation().toString() + "\"");
		wc.setAttribute(IJavaLaunchConfigurationConstants.ID_JAVA_APPLICATION, "workflow - " + currFile.getLocation().toString());

		try {
			config = wc.doSave();
		} catch (final CoreException exception) {
			Logger.log(exception);
		}
		return config;
	}
}
