package org.openarchitectureware.adapter.rsdp.workflow;

public class PathMapEntry extends AbstractURIMapEntry {
   private String alias;
   
   public String getAlias() {
      return alias;
   }
   public void setAlias(String alias) {
      this.alias = alias;
   }
   
   @Override
   public String getMappedURI() {
      return "pathmap://"+getAlias()+"/";
   }
   
}
