package org.openarchitectureware.adapter.rsdp.tlaunch;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Logger {
	private static Log logger = LogFactory.getLog(Logger.class);

	public static void log(String string) {
		logger.info(string);
	}

	public static void log(Throwable throwable) {
		logger.error(throwable.getMessage(), throwable);
	}
	
}
