package org.openarchitectureware.adapter.rsdp.workflow;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openarchitectureware.emf.Mapping;
import org.openarchitectureware.uml2.Setup;
import org.openarchitectureware.workflow.WorkflowComponent;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.ast.parser.Location;
import org.openarchitectureware.workflow.container.CompositeComponent;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public class RSASetup extends Setup implements WorkflowComponent {
	private CompositeComponent container;

	private List<UmlExtensionProject> extensionProjects = new ArrayList<UmlExtensionProject>();

	private List<PathMapEntry> pathMapEntries = new ArrayList<PathMapEntry>();

	private static Log logger = LogFactory.getLog(RSASetup.class);

	private Location location = null;

	/**
	 * Register a plugin containing uml2 / rsa profiles
	 * @param plugin
	 */
	public void addUmlExtensionProject(UmlExtensionProject plugin) {
		extensionProjects.add(plugin);
	}

	public void addPathMapEntry(PathMapEntry pathMapEntry) {
		pathMapEntries.add(pathMapEntry);
	}

	public void checkConfiguration(Issues issues) {
	}

	public CompositeComponent getContainer() {
		return container;
	}

	public void invoke(WorkflowContext ctx, ProgressMonitor monitor,
			Issues issues) {
	}

	public void setInit(boolean b) {
		super.setStandardUML2Setup(b);

		// Add RSA/RSM specific uml file extensions
		addExtensionMap(new Mapping("emx",
				"org.eclipse.uml2.uml.resource.UMLResource"));
		addExtensionMap(new Mapping("epx",
				"org.eclipse.uml2.uml.resource.UMLResource"));

		// Add plugins containing profiles or type libraries
		addUriMaps(extensionProjects);

		// Add pathmap entry
		addUriMaps(pathMapEntries);
	}

	private void addUriMaps(List<? extends AbstractURIMapEntry> mapEntries) {
		for (Iterator<? extends AbstractURIMapEntry> ipp = mapEntries
				.iterator(); ipp.hasNext();) {
			AbstractURIMapEntry plugin = ipp.next();
			File location = new File(plugin.getPath());

			if (location.exists() == false || location.isDirectory() == false) {
				logger.error("Location " + location
						+ " doesn't exist or is not a valid directory");
			} else {
				URI locationURI = location.toURI();
				String mappedURI = plugin.getMappedURI();

				addUriMap(new Mapping(mappedURI, locationURI.toString()));
				logger.info("Added URI mapping " + locationURI + " as "
						+ mappedURI);
			}
		}
	}

	public void setContainer(CompositeComponent container) {
		this.container = container;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;

	}

}
