package org.openarchitectureware.adapter.rsdp.workflow;


public class UmlExtensionProject extends AbstractURIMapEntry {
   private String projectName;
   
   
   public UmlExtensionProject() {
      this(null, null);
   }
   
   public UmlExtensionProject(String projectName, String location) {
      super(location);
      this.projectName = projectName;
   }
   

   @Override
   public String getMappedURI() {
      return "platform:/resource/"+getProjectName()+"/";
   }

   public String getProjectName() {
      return projectName;
   }

   public void setProjectName(String projectName) {
      this.projectName = projectName;
   }
}
