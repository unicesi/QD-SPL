/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare 
 *******************************************************************************/
package org.openarchitectureware.xtext.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWizard;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.progress.UIJob;
import org.eclipse.ui.wizards.newresource.BasicNewResourceWizard;
import org.openarchitectureware.wizards.EclipseHelper;
import org.openarchitectureware.xtext.ui.XtextLog;

public class XtextProjectsWizard extends Wizard implements INewWizard {
	// constants
	private static final String PACKAGE_XTEXT_EDITOR_BASE = "org.openarchitectureware.xtext.editor.base";
	private static final String PACKAGE_XTEXT_CORE = "org.openarchitectureware.xtext.core";
	private static final String PACKAGE_XTEXT_CORE_BASE = "org.openarchitectureware.xtext.core.base";
	private static final String PACKAGE_XTEXT_GENERATOR = "org.openarchitectureware.xtext.generator";
	private static final String ORG_ANTLR = "org.antlr";

	private XtextProjectsWizardPage page;

	private ISelection selection;

	public XtextProjectsWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	@Override
	public void addPages() {
		page = new XtextProjectsWizardPage(selection);
		addPage(page);
	}

	@Override
	public boolean performFinish() {
		final ProjectInfo pi = page.getProjectInfo();
		IRunnableWithProgress op = new IRunnableWithProgress() {
			public void run(IProgressMonitor monitor) throws InvocationTargetException {
				try {
					doFinish(pi, monitor);
				} finally {
					monitor.done();
				}
			}
		};
		try {
			getContainer().run(true, false, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			Throwable realException = e.getTargetException();
			MessageDialog.openError(getShell(), "Error", realException.getMessage());
			return false;
		}
		return true;
	}

	void doFinish(final ProjectInfo pi, IProgressMonitor monitor) {
		new UIJob("creating Xtext projects...") {
			@Override
			public IStatus runInUIThread(IProgressMonitor monitor) {
				try {
					new ProjectCreator(pi).run(monitor);
				} catch (InvocationTargetException e) {
					XtextLog.logError(e);
				} catch (InterruptedException e) {
					XtextLog.logError(e);
				}
				return Status.OK_STATUS;
			}

		}.schedule();

	}

	public class ProjectCreator extends WorkspaceModifyOperation {
		ProjectInfo pi;

		public ProjectCreator(ProjectInfo pi) {
			this.pi = pi;
		}

		@Override
		protected void execute(IProgressMonitor monitor) throws CoreException, InvocationTargetException, InterruptedException {
			monitor.beginTask("Creating project " + pi.getProjectName(), 2);

			Set<String> refs = new HashSet<String>();
			refs.add(PACKAGE_XTEXT_CORE_BASE);
			refs.add(PACKAGE_XTEXT_GENERATOR);
			refs.add(PACKAGE_XTEXT_CORE);
			refs.add(ORG_ANTLR);
			List<String> srcfolders = new ArrayList<String>();
			srcfolders.add("src");
			srcfolders.add("src-gen");

			List<String> exportedPackages = new ArrayList<String>();
			// exportedPackages.add(pi.getBasePackage());
			// exportedPackages.add(pi.getProjectName() + ".parser");

			IProject dslProject = EclipseHelper.createOAWProject(pi.getProjectName(), srcfolders, Collections
					.<IProject> emptyList(), refs, exportedPackages, monitor, getShell());
			if (dslProject == null) {
				return;
			}
			monitor.worked(1);
			IFolder f = (IFolder) dslProject.findMember("src");
			String wf = "<workflow>\n   <property file='generate.properties'/>\n"
					+ "   <component file='org/openarchitectureware/xtext/Generator.oaw' inheritAll='true'/>\n" + "</workflow>";
			EclipseHelper.createFile("generate.oaw", f, wf, monitor);

			String props = "workspace.dir=../\n\n";
			props += "core.project.name=" + pi.getProjectName() + "\n";
			props += "grammar=./src/" + pi.getGrammarName() + "\n";
			props += "debug.grammar=true\n";
			props += "language.name=" + pi.getLanguageName() + "\n";
			props += "language.nsURI=" + pi.getNsURI() + "\n";
			props += "language.fileextension=" + pi.getFileExtension() + "\n";
			props += "basepath=" + pi.getBasePath() + "\n";
			props += "generator.project.name=" + pi.getProjectName() + ".generator\n\n";
			
			props += "generate.standaloneParser=false\n\n";

			props += "#IMPORTANT! When the following flag is activated (i.e. set to true) the generator will overwrite the manifest and plugin resources!\n";
			props += "overwrite.pluginresources=true\n";

			EclipseHelper.createFile("generate.properties", f, props, monitor);

			IFile grammar = EclipseHelper.createFile(pi.getGrammarName(), f, "//specify your DSL grammar rules here ...\n//IMPORTANT: You should change the property 'overwrite.pluginresources=true' in the properties file to 'overwrite.pluginresources=false' AFTER first generation\n\n",
					monitor);

			// creating editor project
			refs.add(PACKAGE_XTEXT_EDITOR_BASE);
			refs.add(pi.getProjectName());
			IProject editorProject = EclipseHelper.createOAWProject(pi.getProjectName() + ".editor", Arrays.asList(new String[] {
					"src", "src-gen", "icons" }), Collections.<IProject> emptyList(), refs, null, monitor, getShell());
			// add default outline icon to the editor projects icons
			// folder
			IFolder iconsFolder = (IFolder) editorProject.findMember("icons");
			EclipseHelper.createFile("default.gif", iconsFolder, Platform.getBundle(PACKAGE_XTEXT_EDITOR_BASE).getEntry(
					"icons/ov_obj.gif"), monitor);

			monitor.setTaskName("Opening file for editing...");
			BasicNewResourceWizard.selectAndReveal(grammar, PlatformUI.getWorkbench().getActiveWorkbenchWindow());
			EclipseHelper.openFileToEdit(getShell(), grammar);
			monitor.worked(1);

			if (pi.isCreateGeneratorProject()) {
				srcfolders = new ArrayList<String>();
				srcfolders.add("src");
				// creating editor project
				IProject p = EclipseHelper.createOAWProject(pi.getProjectName() + ".generator", srcfolders, Collections
						.<IProject> emptyList(), refs, null, monitor, getShell());

				StringBuilder wf1 = new StringBuilder();
				wf1.append("<workflow>\n");
				wf1.append("  <property name='modelFile' />\n");
				wf1.append("  <property name='targetDir' value='src-gen/'/>\n");
				wf1.append("  <component file='" + pi.getBasePath() + "/parser/Parser.oaw'>\n");
				wf1.append("     <modelFile value='${modelFile}'/>\n");
				wf1.append("     <outputSlot value='theModel'/>\n");
				wf1.append("  </component>\n");
				wf1.append("  <component class='oaw.workflow.common.DirectoryCleaner' directories='${targetDir}'/>\n");
				wf1.append("  <component class='oaw.xpand2.Generator'>\n");
				wf1.append("     <metaModel id='mm' class='org.eclipse.m2t.type.emf.EmfRegistryMetaModel'/>\n");
				wf1.append("     <expand value='" + pi.getBasePath().replaceAll("/", "::") + "::Main::main FOR theModel'/>\n");
				wf1.append("     <genPath value='${targetDir}'/>\n");
				wf1.append("  </component>\n");
				wf1.append("</workflow>");
				EclipseHelper.createFile("src/" + pi.getBasePath() + "/generator.oaw", p, wf1.toString(), monitor);

				StringBuilder xpt = new StringBuilder();
				xpt.append("\u00ABIMPORT " + pi.getLanguageName().toLowerCase() + "\u00BB\n\n");

				xpt.append("\u00ABREM\u00BB\n");
				xpt
						.append("   This is the 'main' template. \n   You should replace the type 'Object' with your respective meta type.\n");
				xpt.append("\u00ABENDREM\u00BB\n");
				xpt.append("\u00ABDEFINE main FOR Object\u00BB\n   \n");
				xpt.append("\u00ABENDDEFINE\u00BB");

				EclipseHelper.createFile("src/" + pi.getBasePath() + "/Main.xpt", p, xpt.toString(), monitor);
				EclipseHelper.createFile("src/HelloPDE.java", p, "/* Dummy class for PDE (won't export this plugin otherwise:-() */\nclass HelloPDE {}", monitor);
			}
		}
	}

	/**
	 * We will accept the selection in the workbench to see if we can initialize
	 * from it.
	 * 
	 * @see IWorkbenchWizard#init(IWorkbench, IStructuredSelection)
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
	}
}