/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.editors.text.EditorsUI;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.eclipse.ui.texteditor.ChainedPreferenceStore;
import org.openarchitectureware.xtext.editor.PreferencesConstants;
import org.openarchitectureware.xtext.editor.color.ColorProvider;
import org.osgi.framework.BundleContext;

public abstract class AbstractXtextEditorPlugin extends AbstractUIPlugin {
	private ColorProvider colorProvider;
	/**
	 * The combined preference store.
	 */
	private IPreferenceStore combinedPreferenceStore;

	public AbstractXtextEditorPlugin() {
		colorProvider = new ColorProvider();
	}

	@Override
	public void start(BundleContext context) throws Exception {
		super.start(context);
		PreferencesConstants.initializeDefaultValues(getPreferenceStore());
	}

	@Override
	public void stop(BundleContext context) throws Exception {
		super.stop(context);
		colorProvider.dispose();
		colorProvider = null;
	}

	public ImageDescriptor getImageDescriptor(String path) {
		return AbstractUIPlugin.imageDescriptorFromPlugin(getId(), path);
	}

	public String getId() {
		return getBundle().getSymbolicName();
	}

	public ColorProvider getColorProvider() {
		return colorProvider;
	}

	
	/**
	 * Returns a combined preference store, this store is read-only.
	 * 
	 * @return the combined preference store
	 */
	public IPreferenceStore getCombinedPreferenceStore() {
		if (combinedPreferenceStore == null) {
			IPreferenceStore generalTextStore = EditorsUI.getPreferenceStore();
			combinedPreferenceStore = new ChainedPreferenceStore(new IPreferenceStore[] { getPreferenceStore(),
					generalTextStore });
		}
		return combinedPreferenceStore;
	}
	
	public abstract LanguageUtilities getUtilities();
	
	

}
