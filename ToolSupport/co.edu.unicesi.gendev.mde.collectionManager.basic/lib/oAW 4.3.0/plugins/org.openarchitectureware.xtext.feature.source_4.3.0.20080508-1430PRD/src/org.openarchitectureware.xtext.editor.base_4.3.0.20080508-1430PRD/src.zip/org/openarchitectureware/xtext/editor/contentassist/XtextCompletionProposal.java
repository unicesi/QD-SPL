/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.contentassist;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.ICompletionProposalExtension4;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.openarchitectureware.xtext.XtextLog;
import org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal;

public class XtextCompletionProposal implements ICompletionProposal, ICompletionProposalExtension4 {

	private Proposal proposal;
	private Image img;

	public XtextCompletionProposal(Proposal proposal, Image img) {
		this.proposal = proposal;
		this.img = img;
	}

	public boolean isAutoInsertable() {
		return true;
	}

	public void apply(IDocument document) {
		try {
			String text = proposal.getToInsert();
			int length = proposal.getEndReplace() - proposal.getStartReplace();

			document.replace(proposal.getStartReplace(), length, text);
		} catch (BadLocationException ex) {
			XtextLog.logError(ex);
		}
	}

	public String getAdditionalProposalInfo() {
		return null;
	}

	public IContextInformation getContextInformation() {
		return null;
	}

	public String getDisplayString() {
		return proposal.getLabel();
	}

	public Image getImage() {
		return img;
	}

	public Point getSelection(IDocument document) {
		int length = proposal.getToInsert().length();
		return new Point(proposal.getStartReplace() + length, 0);
	}

}
