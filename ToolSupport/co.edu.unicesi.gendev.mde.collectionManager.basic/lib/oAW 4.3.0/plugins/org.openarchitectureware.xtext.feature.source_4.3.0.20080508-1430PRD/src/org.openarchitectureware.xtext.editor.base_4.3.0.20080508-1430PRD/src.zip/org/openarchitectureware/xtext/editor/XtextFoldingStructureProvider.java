/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.projection.ProjectionAnnotation;
import org.eclipse.jface.text.source.projection.ProjectionAnnotationModel;
import org.openarchitectureware.xtext.XtextLog;
import org.openarchitectureware.xtext.parser.parsetree.Node;

/**
 * Represents an internal helper class to provide additional folding support to
 * XtextEditors.
 * 
 */
public class XtextFoldingStructureProvider {

	/**
	 * Updates the (folding)annotation model of the the given editor
	 * 
	 * @param eObject
	 * @param abstractXtextEditor
	 * @param document
	 *            used to compute the start and end of folding markers for model
	 *            elements.
	 * @param progressMonitor
	 *            the progressMonitor this "updateFoldingRegions" process will
	 *            work (or stop working i.e. cancel).
	 */
	void updateFoldingRegions(Node rootNode,
			AbstractXtextEditor abstractXtextEditor, IDocument document,
			IProgressMonitor progressMonitor) {
		try {
			if (rootNode == null)
				return;
			ProjectionAnnotationModel model = (ProjectionAnnotationModel) abstractXtextEditor
					.getAdapter(ProjectionAnnotationModel.class);
			// nothing to update?
			if (model == null)
				return;

			// create all foldingregions
			Set<Position> currentRegions = new HashSet<Position>();

			createFoldingRegions(document, currentRegions, EcoreUtil
					.getAllContents(rootNode, true));

			updateFoldingRegions(model, currentRegions, progressMonitor);

		} catch (Exception e) {
			XtextLog
					.logInfo("Error update folding regions : " + e.getMessage());
		}
	}

	private void updateFoldingRegions(ProjectionAnnotationModel model,
			Set<Position> currentRegions, IProgressMonitor progressMonitor) {

		Annotation[] deletions = computeDifferences(model, currentRegions);

		Map<ProjectionAnnotation, Position> additionsMap = new HashMap<ProjectionAnnotation, Position>();

		for (Iterator<Position> iter = currentRegions.iterator(); iter
				.hasNext();) {
			additionsMap.put(new ProjectionAnnotation(), iter.next());
		}

		if ((deletions.length != 0 || additionsMap.size() != 0)
				&& (progressMonitor == null || !progressMonitor.isCanceled())) {
			model.modifyAnnotations(deletions, additionsMap,
					new Annotation[] {});
		}

	}

	@SuppressWarnings("unchecked")
	private Annotation[] computeDifferences(ProjectionAnnotationModel model,
			Set current) {
		List<Annotation> deletions = new ArrayList<Annotation>();
		for (Iterator<Annotation> iter = model.getAnnotationIterator(); iter
				.hasNext();) {
			Annotation annotation = iter.next();
			if (annotation instanceof ProjectionAnnotation) {
				Position position = model.getPosition((Annotation) annotation);
				if (current.contains(position))
					current.remove(position);
				else
					deletions.add(annotation);
			}
		}
		return deletions.toArray(new Annotation[deletions.size()]);
	}

	private void createFoldingRegions(IDocument document,
			Set<Position> regions, Iterator<?> iterator)
			throws BadLocationException {

		while (null != iterator && iterator.hasNext()) {

			Object next = iterator.next();
			if (next instanceof Node) {
				Node nextElement = (Node) next;

				try {
					if (nextElement.getModelElement() != null) {
						int startLine = document.getLineOfOffset(nextElement
								.getStart());
						int endLine = document.getLineOfOffset(nextElement
								.getEnd());

						if (startLine < endLine) {
							int start = document.getLineOffset(startLine);
							int end = document.getLineOffset(endLine)
									+ document.getLineLength(endLine);
							Position position = new Position(start, end - start);
							regions.add(position);
						}

						// recursive
						// createFoldingRegions(document, regions,
						// EcoreUtil.getAllContents(nextElement, true));
					}
				} catch (BadLocationException ble) {
					XtextLog.logError(ble);
				}
			} else {
				break;
			}
		}
	}

}
