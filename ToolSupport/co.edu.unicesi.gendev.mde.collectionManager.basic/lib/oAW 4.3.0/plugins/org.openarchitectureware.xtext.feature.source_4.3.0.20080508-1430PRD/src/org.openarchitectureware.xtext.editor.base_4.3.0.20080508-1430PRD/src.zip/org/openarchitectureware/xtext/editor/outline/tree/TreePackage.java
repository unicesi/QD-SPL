/**
 * <copyright>
 * </copyright>
 *
 * $Id: TreePackage.java,v 1.1 2007/08/10 07:19:22 sefftinge Exp $
 */
package org.openarchitectureware.xtext.editor.outline.tree;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.editor.outline.tree.TreeFactory
 * @model kind="package"
 * @generated
 */
public interface TreePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "tree";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.eclipse.org/emp/xtext/tree";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "tree";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	TreePackage eINSTANCE = org.openarchitectureware.xtext.editor.outline.tree.impl.TreePackageImpl.init();

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.editor.outline.tree.impl.UIContentNodeImpl <em>UI Content Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.editor.outline.tree.impl.UIContentNodeImpl
	 * @see org.openarchitectureware.xtext.editor.outline.tree.impl.TreePackageImpl#getUIContentNode()
	 * @generated
	 */
	int UI_CONTENT_NODE = 0;

	/**
	 * The feature id for the '<em><b>Children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UI_CONTENT_NODE__CHILDREN = 0;

	/**
	 * The feature id for the '<em><b>Parent</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UI_CONTENT_NODE__PARENT = 1;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UI_CONTENT_NODE__LABEL = 2;

	/**
	 * The feature id for the '<em><b>Image</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UI_CONTENT_NODE__IMAGE = 3;

	/**
	 * The feature id for the '<em><b>Context</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UI_CONTENT_NODE__CONTEXT = 4;

	/**
	 * The number of structural features of the '<em>UI Content Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UI_CONTENT_NODE_FEATURE_COUNT = 5;


	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode <em>UI Content Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>UI Content Node</em>'.
	 * @see org.openarchitectureware.xtext.editor.outline.tree.UIContentNode
	 * @generated
	 */
	EClass getUIContentNode();

	/**
	 * Returns the meta object for the containment reference list '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Children</em>'.
	 * @see org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getChildren()
	 * @see #getUIContentNode()
	 * @generated
	 */
	EReference getUIContentNode_Children();

	/**
	 * Returns the meta object for the container reference '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getParent <em>Parent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Parent</em>'.
	 * @see org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getParent()
	 * @see #getUIContentNode()
	 * @generated
	 */
	EReference getUIContentNode_Parent();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getLabel()
	 * @see #getUIContentNode()
	 * @generated
	 */
	EAttribute getUIContentNode_Label();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getImage <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Image</em>'.
	 * @see org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getImage()
	 * @see #getUIContentNode()
	 * @generated
	 */
	EAttribute getUIContentNode_Image();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getContext <em>Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Context</em>'.
	 * @see org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getContext()
	 * @see #getUIContentNode()
	 * @generated
	 */
	EAttribute getUIContentNode_Context();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	TreeFactory getTreeFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.editor.outline.tree.impl.UIContentNodeImpl <em>UI Content Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.editor.outline.tree.impl.UIContentNodeImpl
		 * @see org.openarchitectureware.xtext.editor.outline.tree.impl.TreePackageImpl#getUIContentNode()
		 * @generated
		 */
		EClass UI_CONTENT_NODE = eINSTANCE.getUIContentNode();

		/**
		 * The meta object literal for the '<em><b>Children</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference UI_CONTENT_NODE__CHILDREN = eINSTANCE.getUIContentNode_Children();

		/**
		 * The meta object literal for the '<em><b>Parent</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference UI_CONTENT_NODE__PARENT = eINSTANCE.getUIContentNode_Parent();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UI_CONTENT_NODE__LABEL = eINSTANCE.getUIContentNode_Label();

		/**
		 * The meta object literal for the '<em><b>Image</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UI_CONTENT_NODE__IMAGE = eINSTANCE.getUIContentNode_Image();

		/**
		 * The meta object literal for the '<em><b>Context</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UI_CONTENT_NODE__CONTEXT = eINSTANCE.getUIContentNode_Context();

	}

} //TreePackage
