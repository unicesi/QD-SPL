/**
 * <copyright>
 * </copyright>
 *
 * $Id: TreeFactory.java,v 1.1 2007/08/10 07:19:22 sefftinge Exp $
 */
package org.openarchitectureware.xtext.editor.outline.tree;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.editor.outline.tree.TreePackage
 * @generated
 */
public interface TreeFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	TreeFactory eINSTANCE = org.openarchitectureware.xtext.editor.outline.tree.impl.TreeFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>UI Content Node</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>UI Content Node</em>'.
	 * @generated
	 */
	UIContentNode createUIContentNode();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	TreePackage getTreePackage();

} //TreeFactory
