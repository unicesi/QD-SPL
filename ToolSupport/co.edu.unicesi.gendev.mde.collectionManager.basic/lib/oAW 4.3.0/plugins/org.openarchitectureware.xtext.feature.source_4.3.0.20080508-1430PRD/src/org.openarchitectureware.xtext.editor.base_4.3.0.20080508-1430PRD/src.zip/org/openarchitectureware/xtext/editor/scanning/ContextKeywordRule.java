package org.openarchitectureware.xtext.editor.scanning;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.rules.ICharacterScanner;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.RuleBasedScanner;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.openarchitectureware.xtext.AbstractXtextEditorPlugin;
import org.openarchitectureware.xtext.editor.AbstractXtextEditor;
import org.openarchitectureware.xtext.editor.PreferencesConstants;
import org.openarchitectureware.xtext.editor.color.ColorProvider;
import org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle;
import org.openarchitectureware.xtext.parser.model.NodeUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public class ContextKeywordRule extends KeywordRule {
	
	private static Log log = LogFactory.getLog(ContextKeywordRule.class);

	private class TokenResolver {

		private String currentWord;
		private int offset;
		private IToken defaultToken;
		private Object nullObject;
		private Map<String, Set<EClass>> nullElements;

		public TokenResolver(IToken defaultToken, Object nullObject,
				HashMap<String, Set<EClass>> nullElements) {
			this.defaultToken = defaultToken;
			this.nullElements = nullElements;
			this.nullObject = nullObject;
		}

		public IToken resolve() {
			IToken customToken = findCustomToken(currentWord, offset);
			return customToken != null ? customToken : defaultToken;
		}

		private IToken findCustomToken(String currentWord, int offset) {
			Node parent = NodeUtil.findNodeUnderOffset(editor.getLastResult(),
					offset).getParent();
			if (parent != null) {
				EObject context = parent.getModelElement();
				if (context != null) {
					return findCustomTokenForContext(currentWord, context);
				}
			}
			return null;
		}

		private IToken findCustomTokenForContext(String currentWord,
				EObject context) {

			try {
				if (nullElements.containsKey(currentWord)) {
					if (nullElements.get(currentWord)
							.contains(context.eClass())) {
						return null;
					}
				}

				FontStyle style = (FontStyle) plugin.getUtilities()
						.invokeExtension(StyleConstants.STYLE_EXTENSION_FILE_NAME, StyleConstants.STYLE_EXTENSION, currentWord,
								context);
				if (style == null) {
					return null;
				}
				if (style == nullObject) {
					neverCheckAgain(currentWord, context);
					return null;
				}
				int styleBit = 0;
				ColorProvider colorProvider = plugin.getColorProvider();
				Color forground = colorProvider.getColor(PreferenceConverter
						.getColor(plugin.getPreferenceStore(),
								PreferencesConstants.HIGHLIGHT_KEYWORDS));
				Color background = null;
				if (style.isBold())
					styleBit = styleBit | SWT.BOLD;
				if (style.isItalic())
					styleBit = styleBit | SWT.ITALIC;
				if (style.isStrikethrough())
					styleBit = styleBit | TextAttribute.STRIKETHROUGH;
				if (style.isUnderline())
					styleBit = styleBit | TextAttribute.UNDERLINE;
				org.openarchitectureware.xtext.editor.scanning.scanning.Color forgroundColor = style
						.getForgroundColor();
				if (forgroundColor != null) {
					forground = colorProvider.getColor(new RGB(forgroundColor
							.getR(), forgroundColor.getG(), forgroundColor
							.getB()));
				}
				org.openarchitectureware.xtext.editor.scanning.scanning.Color backgroundColor = style
						.getBackgroundColor();
				if (backgroundColor != null) {
					background = colorProvider.getColor(new RGB(backgroundColor
							.getR(), backgroundColor.getG(), backgroundColor
							.getB()));
				}
				return new Token(new TextAttribute(forground, background,
						styleBit));
			} catch (RuntimeException ignore) {
				// no custom style specified
				neverCheckAgain(currentWord, context);
				return null;
			}

		}

		private void neverCheckAgain(String currentWord, EObject context) {
			Set<EClass> set = nullElements.get(currentWord);
			if (set == null) {
				set = new HashSet<EClass>();
				nullElements.put(currentWord, set);
			}
			set.add(context.eClass());
		}

		public void setContext(String currentWord, int offset) {
			this.currentWord = currentWord;
			this.offset = offset;

		}
	}

	private AbstractXtextEditor editor;

	private final AbstractXtextEditorPlugin plugin;

	private HashMap<String, Set<EClass>> nullElements = new HashMap<String, Set<EClass>>();

	private Object nullObject;

	private TokenResolver tokenResolver;

	public ContextKeywordRule(Token keyword, List<String> keywords,
			AbstractXtextEditor editor, AbstractXtextEditorPlugin plugin) {
		super(keyword, keywords);
		this.editor = editor;
		this.plugin = plugin;
		try {
			this.nullObject = plugin.getUtilities().invokeExtension(StyleConstants.STYLE_EXTENSION_FILE_NAME,
					StyleConstants.NULL_OBJECT_EXTENSION);
		} catch (RuntimeException e) {
			nullObject = new Object();
		}
		tokenResolver = new TokenResolver(keyword, nullObject, nullElements);
	}

	public IToken evaluate(ICharacterScanner charScanner) {
		if (editor.useContextRule()) {
			RuleBasedScanner scanner = (RuleBasedScanner) charScanner;
			StringBuffer buff = new StringBuffer();
			boolean stopReading = false;
			int reads = 0;
			if (scanner.getColumn() > 0) {
				scanner.unread();
				if (Character.isJavaIdentifierPart(scanner.read()))
					return Token.UNDEFINED;
			}
			while (!stopReading) {
				reads++;
				char c = (char) scanner.read();
				String currentWord = buff.toString();
				if (buff.length() > 0 && !Character.isJavaIdentifierPart(c)) {
					if (isKeyword(currentWord)
							&& !keywordExists(currentWord + c)) {
						scanner.unread();
						tokenResolver.setContext(currentWord, scanner
								.getTokenOffset());
						try {
							return tokenResolver.resolve();
						} catch (Exception e) {
							log.error(e);
							return Token.UNDEFINED;
						}
					}
				}
				buff.append(c);
				stopReading = !keywordExists(currentWord);
			}

			for (int i = 0; i < reads; i++) {
				scanner.unread();
			}
			return Token.UNDEFINED;
		}
		return Token.UNDEFINED;
	}

}
