package org.openarchitectureware.xtext.editor.base.preferences;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

import org.openarchitectureware.xtext.BaseEditorPlugin;

public class PreferenceInitializer extends AbstractPreferenceInitializer {

	public void initializeDefaultPreferences() {
		IPreferenceStore store = BaseEditorPlugin.getDefault().getPreferenceStore();
		store.setDefault(PreferenceConstants.CHECK_STRATEGY, PreferenceConstants.CHECK_STRATEGY_ON_SAVE_ONLY);
	}

}
