package org.openarchitectureware.xtext.editor.scanning;

public interface StyleConstants {
	
	public static final String STYLE_EXTENSION_FILE_NAME = "Style";
	public static final String NULL_OBJECT_EXTENSION = "neverCheckAgainForThisTypeAndKeyword";
	public static final String STYLE_EXTENSION = "fontstyle";
	public static final String DELAY = "delayContextSensitiveStyling";

}
