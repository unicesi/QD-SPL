/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.editor;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IInformationControl;
import org.eclipse.jface.text.IInformationControlCreator;
import org.eclipse.jface.text.ITextHover;
import org.eclipse.jface.text.contentassist.ContentAssistant;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.contentassist.IContentAssistant;
import org.eclipse.jface.text.formatter.ContentFormatter;
import org.eclipse.jface.text.formatter.IContentFormatter;
import org.eclipse.jface.text.hyperlink.IHyperlinkDetector;
import org.eclipse.jface.text.information.IInformationPresenter;
import org.eclipse.jface.text.information.IInformationProvider;
import org.eclipse.jface.text.information.InformationPresenter;
import org.eclipse.jface.text.presentation.IPresentationReconciler;
import org.eclipse.jface.text.presentation.PresentationReconciler;
import org.eclipse.jface.text.reconciler.IReconciler;
import org.eclipse.jface.text.rules.DefaultDamagerRepairer;
import org.eclipse.jface.text.rules.ITokenScanner;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.editors.text.TextSourceViewerConfiguration;
import org.openarchitectureware.xtext.AbstractXtextEditorPlugin;
import org.openarchitectureware.xtext.editor.actions.IXtextEditorActionDefinitionIds;
import org.openarchitectureware.xtext.editor.contentassist.XTextModelContentAssist;
import org.openarchitectureware.xtext.editor.marker.ProblemHover;
import org.openarchitectureware.xtext.editor.navigation.XtextHyperlinkDetector;
import org.openarchitectureware.xtext.editor.outline.XtextOutlineInformationControl;
import org.openarchitectureware.xtext.editor.scanning.AbstractPartitionScanner;
import org.openarchitectureware.xtext.editor.scanning.CommentScanner;
import org.openarchitectureware.xtext.editor.scanning.ContentScanner;
import org.openarchitectureware.xtext.editor.scanning.StringScanner;

public class XtextSourceViewerConfiguration extends
		TextSourceViewerConfiguration {

	private ContentScanner contentScanner;

	private CommentScanner commentScanner;

	private AbstractXtextEditorPlugin plugin;

	private StringScanner stringScanner;

	private AbstractXtextEditor editor;

	public XtextSourceViewerConfiguration(AbstractXtextEditorPlugin plugin,
			AbstractXtextEditor editor) {
		super(plugin.getCombinedPreferenceStore());
		this.plugin = plugin;
		this.editor = editor;
	}

	@Override
	public IContentFormatter getContentFormatter(ISourceViewer sourceViewer) {
		ContentFormatter formatter = new ContentFormatter();
		// formatter.setDocumentPartitioning(AbstractPartitionScanner)
		return formatter;
	}

	@Override
	public String[] getConfiguredContentTypes(ISourceViewer aSourceViewer) {
		return new String[] { IDocument.DEFAULT_CONTENT_TYPE,
				AbstractPartitionScanner.COMMENT,
				AbstractPartitionScanner.STRING };
	}

	@Override
	public IContentAssistant getContentAssistant(ISourceViewer aSourceViewer) {
		IContentAssistProcessor processor = plugin.getUtilities()
				.getContentAssistProcessor();
		if (processor == null) {
			processor = new XTextModelContentAssist(plugin.getUtilities(),
					editor);
		}
		ContentAssistant contentAssistant = null;
		if (processor != null) {
			contentAssistant = new ContentAssistant();
			contentAssistant.setContentAssistProcessor(processor,
					IDocument.DEFAULT_CONTENT_TYPE);
			contentAssistant.enableAutoActivation(true);
			contentAssistant.setAutoActivationDelay(500);
			contentAssistant
					.setProposalPopupOrientation(IContentAssistant.PROPOSAL_OVERLAY);
			contentAssistant
					.setContextInformationPopupOrientation(IContentAssistant.CONTEXT_INFO_ABOVE);
		}
		return contentAssistant;
	}

	@Override
	public String[] getIndentPrefixes(ISourceViewer aSourceViewer,
			String aContentType) {
		return new String[] { "\t", "    " }; // see also 'getTabWidth' ...
	}

	@Override
	public IReconciler getReconciler(ISourceViewer sourceViewer) {
		return null; // we don't want spell checking
	}

	@Override
	public IPresentationReconciler getPresentationReconciler(
			ISourceViewer aSourceViewer) {
		PresentationReconciler reconciler = new PresentationReconciler();
		DefaultDamagerRepairer dr = new DefaultDamagerRepairer(this
				.getCommentScanner());
		reconciler.setDamager(dr, AbstractPartitionScanner.COMMENT);
		reconciler.setRepairer(dr, AbstractPartitionScanner.COMMENT);

		dr = new DefaultDamagerRepairer(this.getStringScanner());
		reconciler.setDamager(dr, AbstractPartitionScanner.STRING);
		reconciler.setRepairer(dr, AbstractPartitionScanner.STRING);

		dr = new DefaultDamagerRepairer(this.getContentScanner());
		reconciler.setDamager(dr, IDocument.DEFAULT_CONTENT_TYPE);
		reconciler.setRepairer(dr, IDocument.DEFAULT_CONTENT_TYPE);
		return reconciler;
	}

	private CommentScanner getCommentScanner() {
		if (commentScanner == null) {
			commentScanner = new CommentScanner(plugin);
		}
		return commentScanner;
	}

	private StringScanner getStringScanner() {
		if (stringScanner == null) {
			stringScanner = new StringScanner(plugin);
		}
		return stringScanner;
	}

	protected ITokenScanner getContentScanner() {
		if (contentScanner == null) {
			contentScanner = new ContentScanner(plugin, editor);
		}
		return contentScanner;
	}

	@Override
	public IAnnotationHover getAnnotationHover(final ISourceViewer sourceViewer) {
		return new ProblemHover(sourceViewer);
	}

	@Override
	public ITextHover getTextHover(final ISourceViewer sourceViewer,
			final String contentType) {
		return new ProblemHover(sourceViewer);
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getHyperlinkDetectors(org.eclipse.jface.text.source.ISourceViewer)
	 */
	@Override
	public IHyperlinkDetector[] getHyperlinkDetectors(ISourceViewer sourceViewer) {
		IHyperlinkDetector[] inheritedDetectors = super.getHyperlinkDetectors(sourceViewer);
		int inheritedDetectorsLength = inheritedDetectors != null ? inheritedDetectors.length : 0;
		IHyperlinkDetector[] detectors = new IHyperlinkDetector[inheritedDetectorsLength + 1];
		detectors[0] = new XtextHyperlinkDetector(editor, plugin.getUtilities());
		for (int i = 0; i < inheritedDetectorsLength; i++) {
			detectors[i + 1] = inheritedDetectors[i];
		}

		return detectors;
	}

	public IInformationPresenter getOutlinePresenter(
			XtextSourceViewer xtextSourceViewer) {
		InformationPresenter presenter;
		presenter = new InformationPresenter(
				getOutlinePresenterControlCreator(xtextSourceViewer,
						IXtextEditorActionDefinitionIds.SHOW_OUTLINE));
		// presenter= new
		// InformationPresenter(getOutlinePresenterControlCreator(sourceViewer,
		// IJavaEditorActionDefinitionIds.SHOW_OUTLINE));
		 presenter.setDocumentPartitioning(getConfiguredDocumentPartitioning(xtextSourceViewer));
		// presenter.setAnchor(AbstractInformationControlManager.ANCHOR_GLOBAL);
		 IInformationProvider provider= new XtextInfoProviderProvider(editor);
		 presenter.setInformationProvider(provider, IDocument.DEFAULT_CONTENT_TYPE);
		// presenter.setInformationProvider(provider, IJavaPartitions.JAVA_DOC);
		// presenter.setInformationProvider(provider,
		// IJavaPartitions.JAVA_MULTI_LINE_COMMENT);
		// presenter.setInformationProvider(provider,
		// IJavaPartitions.JAVA_SINGLE_LINE_COMMENT);
		// presenter.setInformationProvider(provider,
		// IJavaPartitions.JAVA_STRING);
		// presenter.setInformationProvider(provider,
		// IJavaPartitions.JAVA_CHARACTER);
		 presenter.setSizeConstraints(50, 20, true, false);
		return presenter;
	}

	private IInformationControlCreator getOutlinePresenterControlCreator(
			ISourceViewer sourceViewer, final String commandId) {
		return new IInformationControlCreator() {
			public IInformationControl createInformationControl(Shell parent) {
				int shellStyle = SWT.RESIZE;
				int treeStyle = SWT.V_SCROLL | SWT.H_SCROLL;
				return new XtextOutlineInformationControl(parent, shellStyle,
						treeStyle, commandId, editor, plugin.getUtilities());
			}
		};
	}
}