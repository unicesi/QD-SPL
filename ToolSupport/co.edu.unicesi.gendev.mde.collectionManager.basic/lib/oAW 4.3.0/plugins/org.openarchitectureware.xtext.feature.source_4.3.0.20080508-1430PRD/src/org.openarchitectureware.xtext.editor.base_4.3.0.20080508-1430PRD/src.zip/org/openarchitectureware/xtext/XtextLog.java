/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

public class XtextLog {

	public final static void logInfo(String msg, Throwable t) {
        log(IStatus.INFO, IStatus.OK, msg, t);
    }
	
    public final static void logInfo(String msg) {
        log(IStatus.INFO, IStatus.OK, msg, null);
    }

    public final static void logError(Throwable t) {
        logError(t.getMessage(), t);
    }

    public final static void logError(String msg, Throwable t) {
        log(IStatus.ERROR, IStatus.OK, msg, t);
    }
    
    public final static void logWarning(String msg, Throwable t) {
		log(IStatus.WARNING, IStatus.OK, msg, t);
	}
    
    private final static void log(int severity, int code, String message, Throwable exception) {
        log(createStatus(severity, code, message, exception));
    }

    private final static IStatus createStatus(int severity, int code, String message, Throwable exception) {
        return new Status(severity, BaseEditorPlugin.getDefault().getBundle().getSymbolicName(), code,
                message != null ? message : "", exception);
    }

    private final static void log(IStatus status) {
        BaseEditorPlugin.getDefault().getLog().log(status);
    }
}
