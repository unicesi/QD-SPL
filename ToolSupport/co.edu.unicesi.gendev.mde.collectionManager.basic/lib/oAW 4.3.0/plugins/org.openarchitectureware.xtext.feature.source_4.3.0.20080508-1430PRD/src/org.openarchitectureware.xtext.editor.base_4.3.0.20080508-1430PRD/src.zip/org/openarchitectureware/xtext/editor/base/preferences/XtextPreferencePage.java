package org.openarchitectureware.xtext.editor.base.preferences;

import org.eclipse.jface.preference.*;
import org.eclipse.ui.IWorkbenchPreferencePage;
import org.eclipse.ui.IWorkbench;
import org.openarchitectureware.xtext.BaseEditorPlugin;

public class XtextPreferencePage
	extends FieldEditorPreferencePage
	implements IWorkbenchPreferencePage {

	public XtextPreferencePage() {
		super(GRID);
		setPreferenceStore(BaseEditorPlugin.getDefault().getPreferenceStore());
	}
	
	public void createFieldEditors() {
		addField(new RadioGroupFieldEditor(
				PreferenceConstants.CHECK_STRATEGY,
			"When should Xtext validate your model against the Check file",
			1,
			new String[][] { { "On Save", PreferenceConstants.CHECK_STRATEGY_ON_SAVE_ONLY }, {
				"Always", PreferenceConstants.CHECK_STRATEGY_ON_KEYSTROKE }
		}, getFieldEditorParent()));
	}

	public void init(IWorkbench workbench) {
	}
	
}