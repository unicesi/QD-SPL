/**
 * <copyright>
 * </copyright>
 *
 * $Id: FontStyleImpl.java,v 1.1.2.1 2008/02/04 21:24:11 berndkolb Exp $
 */
package org.openarchitectureware.xtext.editor.scanning.scanning.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.openarchitectureware.xtext.editor.scanning.scanning.Color;
import org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle;
import org.openarchitectureware.xtext.editor.scanning.scanning.ScanningPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Font Style</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.impl.FontStyleImpl#isBold <em>Bold</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.impl.FontStyleImpl#isItalic <em>Italic</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.impl.FontStyleImpl#isUnderline <em>Underline</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.impl.FontStyleImpl#isStrikethrough <em>Strikethrough</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.impl.FontStyleImpl#getForgroundColor <em>Forground Color</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.impl.FontStyleImpl#getBackgroundColor <em>Background Color</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FontStyleImpl extends EObjectImpl implements FontStyle {
	/**
	 * The default value of the '{@link #isBold() <em>Bold</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBold()
	 * @generated
	 * @ordered
	 */
	protected static final boolean BOLD_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isBold() <em>Bold</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBold()
	 * @generated
	 * @ordered
	 */
	protected boolean bold = BOLD_EDEFAULT;

	/**
	 * The default value of the '{@link #isItalic() <em>Italic</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isItalic()
	 * @generated
	 * @ordered
	 */
	protected static final boolean ITALIC_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isItalic() <em>Italic</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isItalic()
	 * @generated
	 * @ordered
	 */
	protected boolean italic = ITALIC_EDEFAULT;

	/**
	 * The default value of the '{@link #isUnderline() <em>Underline</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isUnderline()
	 * @generated
	 * @ordered
	 */
	protected static final boolean UNDERLINE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isUnderline() <em>Underline</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isUnderline()
	 * @generated
	 * @ordered
	 */
	protected boolean underline = UNDERLINE_EDEFAULT;

	/**
	 * The default value of the '{@link #isStrikethrough() <em>Strikethrough</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStrikethrough()
	 * @generated
	 * @ordered
	 */
	protected static final boolean STRIKETHROUGH_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isStrikethrough() <em>Strikethrough</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStrikethrough()
	 * @generated
	 * @ordered
	 */
	protected boolean strikethrough = STRIKETHROUGH_EDEFAULT;

	/**
	 * The cached value of the '{@link #getForgroundColor() <em>Forground Color</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getForgroundColor()
	 * @generated
	 * @ordered
	 */
	protected Color forgroundColor;

	/**
	 * The cached value of the '{@link #getBackgroundColor() <em>Background Color</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBackgroundColor()
	 * @generated
	 * @ordered
	 */
	protected Color backgroundColor;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FontStyleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ScanningPackage.Literals.FONT_STYLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isBold() {
		return bold;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBold(boolean newBold) {
		boolean oldBold = bold;
		bold = newBold;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ScanningPackage.FONT_STYLE__BOLD, oldBold, bold));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isItalic() {
		return italic;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setItalic(boolean newItalic) {
		boolean oldItalic = italic;
		italic = newItalic;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ScanningPackage.FONT_STYLE__ITALIC, oldItalic, italic));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isUnderline() {
		return underline;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUnderline(boolean newUnderline) {
		boolean oldUnderline = underline;
		underline = newUnderline;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ScanningPackage.FONT_STYLE__UNDERLINE, oldUnderline, underline));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isStrikethrough() {
		return strikethrough;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStrikethrough(boolean newStrikethrough) {
		boolean oldStrikethrough = strikethrough;
		strikethrough = newStrikethrough;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ScanningPackage.FONT_STYLE__STRIKETHROUGH, oldStrikethrough, strikethrough));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Color getForgroundColor() {
		return forgroundColor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetForgroundColor(Color newForgroundColor, NotificationChain msgs) {
		Color oldForgroundColor = forgroundColor;
		forgroundColor = newForgroundColor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ScanningPackage.FONT_STYLE__FORGROUND_COLOR, oldForgroundColor, newForgroundColor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setForgroundColor(Color newForgroundColor) {
		if (newForgroundColor != forgroundColor) {
			NotificationChain msgs = null;
			if (forgroundColor != null)
				msgs = ((InternalEObject)forgroundColor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ScanningPackage.FONT_STYLE__FORGROUND_COLOR, null, msgs);
			if (newForgroundColor != null)
				msgs = ((InternalEObject)newForgroundColor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ScanningPackage.FONT_STYLE__FORGROUND_COLOR, null, msgs);
			msgs = basicSetForgroundColor(newForgroundColor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ScanningPackage.FONT_STYLE__FORGROUND_COLOR, newForgroundColor, newForgroundColor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Color getBackgroundColor() {
		return backgroundColor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBackgroundColor(Color newBackgroundColor, NotificationChain msgs) {
		Color oldBackgroundColor = backgroundColor;
		backgroundColor = newBackgroundColor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ScanningPackage.FONT_STYLE__BACKGROUND_COLOR, oldBackgroundColor, newBackgroundColor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBackgroundColor(Color newBackgroundColor) {
		if (newBackgroundColor != backgroundColor) {
			NotificationChain msgs = null;
			if (backgroundColor != null)
				msgs = ((InternalEObject)backgroundColor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ScanningPackage.FONT_STYLE__BACKGROUND_COLOR, null, msgs);
			if (newBackgroundColor != null)
				msgs = ((InternalEObject)newBackgroundColor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ScanningPackage.FONT_STYLE__BACKGROUND_COLOR, null, msgs);
			msgs = basicSetBackgroundColor(newBackgroundColor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ScanningPackage.FONT_STYLE__BACKGROUND_COLOR, newBackgroundColor, newBackgroundColor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ScanningPackage.FONT_STYLE__FORGROUND_COLOR:
				return basicSetForgroundColor(null, msgs);
			case ScanningPackage.FONT_STYLE__BACKGROUND_COLOR:
				return basicSetBackgroundColor(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ScanningPackage.FONT_STYLE__BOLD:
				return isBold() ? Boolean.TRUE : Boolean.FALSE;
			case ScanningPackage.FONT_STYLE__ITALIC:
				return isItalic() ? Boolean.TRUE : Boolean.FALSE;
			case ScanningPackage.FONT_STYLE__UNDERLINE:
				return isUnderline() ? Boolean.TRUE : Boolean.FALSE;
			case ScanningPackage.FONT_STYLE__STRIKETHROUGH:
				return isStrikethrough() ? Boolean.TRUE : Boolean.FALSE;
			case ScanningPackage.FONT_STYLE__FORGROUND_COLOR:
				return getForgroundColor();
			case ScanningPackage.FONT_STYLE__BACKGROUND_COLOR:
				return getBackgroundColor();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ScanningPackage.FONT_STYLE__BOLD:
				setBold(((Boolean)newValue).booleanValue());
				return;
			case ScanningPackage.FONT_STYLE__ITALIC:
				setItalic(((Boolean)newValue).booleanValue());
				return;
			case ScanningPackage.FONT_STYLE__UNDERLINE:
				setUnderline(((Boolean)newValue).booleanValue());
				return;
			case ScanningPackage.FONT_STYLE__STRIKETHROUGH:
				setStrikethrough(((Boolean)newValue).booleanValue());
				return;
			case ScanningPackage.FONT_STYLE__FORGROUND_COLOR:
				setForgroundColor((Color)newValue);
				return;
			case ScanningPackage.FONT_STYLE__BACKGROUND_COLOR:
				setBackgroundColor((Color)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case ScanningPackage.FONT_STYLE__BOLD:
				setBold(BOLD_EDEFAULT);
				return;
			case ScanningPackage.FONT_STYLE__ITALIC:
				setItalic(ITALIC_EDEFAULT);
				return;
			case ScanningPackage.FONT_STYLE__UNDERLINE:
				setUnderline(UNDERLINE_EDEFAULT);
				return;
			case ScanningPackage.FONT_STYLE__STRIKETHROUGH:
				setStrikethrough(STRIKETHROUGH_EDEFAULT);
				return;
			case ScanningPackage.FONT_STYLE__FORGROUND_COLOR:
				setForgroundColor((Color)null);
				return;
			case ScanningPackage.FONT_STYLE__BACKGROUND_COLOR:
				setBackgroundColor((Color)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ScanningPackage.FONT_STYLE__BOLD:
				return bold != BOLD_EDEFAULT;
			case ScanningPackage.FONT_STYLE__ITALIC:
				return italic != ITALIC_EDEFAULT;
			case ScanningPackage.FONT_STYLE__UNDERLINE:
				return underline != UNDERLINE_EDEFAULT;
			case ScanningPackage.FONT_STYLE__STRIKETHROUGH:
				return strikethrough != STRIKETHROUGH_EDEFAULT;
			case ScanningPackage.FONT_STYLE__FORGROUND_COLOR:
				return forgroundColor != null;
			case ScanningPackage.FONT_STYLE__BACKGROUND_COLOR:
				return backgroundColor != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (bold: ");
		result.append(bold);
		result.append(", italic: ");
		result.append(italic);
		result.append(", underline: ");
		result.append(underline);
		result.append(", strikethrough: ");
		result.append(strikethrough);
		result.append(')');
		return result.toString();
	}

} //FontStyleImpl
