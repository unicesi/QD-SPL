/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.wizards;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.XtextLog;

public abstract class AbstractNewProjectWizard extends Wizard implements
		INewWizard {

	protected GenericNewProjectWizardPage mainPage;
	private String langName;
	private String fileExtension;
	private String packageName;

	public String getLangName() {
		return langName;
	}

	public void setLangName(String langName) {
		this.langName = langName;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	/**
	 * Constructor for AbstractNewProjectWizard.
	 */
	public AbstractNewProjectWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	@Override
	public void addPages() {
		super.addPages();
		mainPage = createMainPage();
		addPage(mainPage);
	}

	private GenericNewProjectWizardPage createMainPage() {
		GenericNewProjectWizardPage page = new GenericNewProjectWizardPage(getLangName());
		page.setImageDescriptor(ImageDescriptor.createFromImage(getUtilities()
				.getImage("newprj_wiz.png")));
		return page;
	}
	abstract protected LanguageUtilities getUtilities();
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.wizard.Wizard#performFinish()
	 */
	@Override
	public boolean performFinish() {

		try {
			new WorkspaceModifyOperation() {

				@Override
				protected void execute(IProgressMonitor monitor) throws CoreException, InvocationTargetException,
						InterruptedException {
					try {
						IProject pr = mainPage.getProjectHandle();
						pr.create(monitor);
						pr.open(monitor);
						String modelFileName = "model." + getFileExtension();
						ProjectCreator.create(pr, new String[] { getDslProjectName(), getGeneratorProjectName() }, monitor);
						IContainer srcFolder = pr.getFolder("src");
						ProjectCreator
								.createFile(
										modelFileName,
										srcFolder,
										"//model goes here...\n",
										monitor);
						ProjectCreator
								.createFile(
										pr.getName() + ".oaw",
										srcFolder,
										"<workflow>\n\t<component file='"
												+ getPackageName()
												+ "generator.oaw'>\n\t\t<modelFile value='"
												+ modelFileName
												+ "' />\n\t\t<targetDir value='src-gen' />\n\t</component>\n</workflow>",
										monitor);
					} catch (CoreException e) {
						mainPage.setErrorMessage(e.getLocalizedMessage());
					}
				}
			}.run(null);
		} catch (InvocationTargetException e) {
			XtextLog.logError(e);
			return false;
		} catch (InterruptedException e) {
			XtextLog.logError(e);
			return false;
		}
		return true;
	}
	
	private String dslProjectName;
	
	public String getDslProjectName() {
		return dslProjectName;
	}
	
	public void setDslProjectName(String dslProjectName) {
		this.dslProjectName = dslProjectName;
	}
	
	private String generatorProjectName;

	private String getGeneratorProjectName() {
		return generatorProjectName;
	}

	public void setGeneratorProjectName(String generatorProjectName) {
		this.generatorProjectName = generatorProjectName;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.IWorkbenchWizard#init(org.eclipse.ui.IWorkbench,
	 *      org.eclipse.jface.viewers.IStructuredSelection)
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		// does nothing
	}

}
