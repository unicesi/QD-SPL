/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.search;

import org.eclipse.core.resources.IFile;
import org.eclipse.swt.graphics.Image;

public class XtextSearchMatch {
	private IFile file;
	private Image image;
	private String searchFor;
	private int line;

	public XtextSearchMatch(IFile file, Image image, String searchFor, int line) {
		super();
		this.file = file;
		this.image = image;
		this.searchFor = searchFor;
		this.line = line;
	}

	public IFile getFile() {
		return file;
	}

	public Image getImage() {
		return image;
	}

	public String getSearchString() {
		return searchFor;
	}

	public int getLine() {
		return line;
	}

}
