package org.openarchitectureware.xtext.editor;

import org.eclipse.jface.text.information.IInformationPresenter;
import org.eclipse.jface.text.source.IOverviewRuler;
import org.eclipse.jface.text.source.IVerticalRuler;
import org.eclipse.jface.text.source.SourceViewerConfiguration;
import org.eclipse.jface.text.source.projection.ProjectionViewer;
import org.eclipse.swt.widgets.Composite;
import org.openarchitectureware.xtext.editor.actions.IXtextEditorActionDefinitionIds;

public class XtextSourceViewer extends ProjectionViewer {
	
	private IInformationPresenter outlinePresenter;
	
	

	public XtextSourceViewer(Composite parent, IVerticalRuler ruler,
			IOverviewRuler overviewRuler, boolean overviewRulerVisible,
			int styles) {
		super(parent, ruler, overviewRuler, overviewRulerVisible, styles);
	}
	
	@Override
	public void configure(SourceViewerConfiguration configuration) {
		super.configure(configuration);
		outlinePresenter = ((XtextSourceViewerConfiguration)configuration).getOutlinePresenter(this);
		if (outlinePresenter != null)
			outlinePresenter.install(this);
	}
	
	public boolean canDoOperation(int operation) {
		if (operation == IXtextEditorActionDefinitionIds.SHOW_OUTLINE_ID)
			return outlinePresenter != null;
		return super.canDoOperation(operation);
	}
	
	public void doOperation(int operation) {
		if (getTextWidget() == null)
			return;

		switch (operation) {
			case IXtextEditorActionDefinitionIds.SHOW_OUTLINE_ID:
				if (outlinePresenter != null)
					outlinePresenter.showInformation();
				return;
		}

		super.doOperation(operation);
	}
	
	@Override
	public void unconfigure() {
		if (outlinePresenter != null) {
			outlinePresenter.uninstall();
			outlinePresenter= null;
		}
		super.unconfigure();
	}

}
