/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.scanning;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.rules.RuleBasedScanner;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.swt.SWT;
import org.openarchitectureware.xtext.AbstractXtextEditorPlugin;
import org.openarchitectureware.xtext.editor.PreferencesConstants;
import org.openarchitectureware.xtext.editor.color.ColorProvider;

public abstract class AbstractRuleBasedScanner extends RuleBasedScanner {

    protected Token keyword;

    protected Token string;

    protected Token comment;

    protected Token other;

    private AbstractXtextEditorPlugin plugin;

    public AbstractRuleBasedScanner(AbstractXtextEditorPlugin plugin) {
        super();
        this.plugin = plugin;
        setTokens();
        setDefaultReturnToken(other);
    }

    protected synchronized void setTokens() {
        IPreferenceStore aPreferenceStore = plugin.getPreferenceStore();
        ColorProvider provider = plugin.getColorProvider();

        keyword = new Token(new TextAttribute(provider.getColor(PreferenceConverter.getColor(aPreferenceStore,
                PreferencesConstants.HIGHLIGHT_KEYWORDS)), null, SWT.BOLD));

        string = new Token(new TextAttribute(provider.getColor(PreferenceConverter.getColor(aPreferenceStore,
                PreferencesConstants.HIGHLIGHT_STRING))));

        comment = new Token(new TextAttribute(provider.getColor(PreferenceConverter.getColor(aPreferenceStore,
                PreferencesConstants.HIGHLIGHT_COMMENT))));

        other = new Token(new TextAttribute(provider.getColor(PreferenceConverter.getColor(aPreferenceStore,
                PreferencesConstants.HIGHLIGHT_OTHER))));
    }

}
