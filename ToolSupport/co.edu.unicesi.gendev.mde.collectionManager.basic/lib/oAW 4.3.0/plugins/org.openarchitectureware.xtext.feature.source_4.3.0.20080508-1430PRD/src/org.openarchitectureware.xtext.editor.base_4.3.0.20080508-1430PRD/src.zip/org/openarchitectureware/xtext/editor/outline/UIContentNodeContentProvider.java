/**
 * 
 */
package org.openarchitectureware.xtext.editor.outline;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;
import org.openarchitectureware.xtext.editor.outline.tree.UIContentNode;

public final class UIContentNodeContentProvider implements
		ITreeContentProvider {
	public void dispose() {
	}

	public void inputChanged(Viewer viewer, Object oldInput,
			Object newInput) {
	}

	public Object[] getChildren(Object parentElement) {
		if (parentElement instanceof UIContentNode) {
			return ((UIContentNode) parentElement).getChildren()
					.toArray();
		}
		return new Object[0];
	}

	public Object getParent(Object element) {
		if (element instanceof UIContentNode) {
			return ((UIContentNode) element).getParent();
		}
		return null;
	}

	public boolean hasChildren(Object element) {
		return getChildren(element).length > 0;
	}

	public Object[] getElements(Object inputElement) {
		return getChildren(inputElement);
	}
}