/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.outline;

import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;
import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.XtextLog;
import org.openarchitectureware.xtext.editor.outline.tree.UIContentNode;

public class UIContentNodeLabelProvider extends LabelProvider {
	private LanguageUtilities languageUtils;

	public UIContentNodeLabelProvider(LanguageUtilities languageUtilities) {
		this.languageUtils = languageUtilities;
	}

	public Image getImage(Object element) {
		if (element instanceof UIContentNode) {
			Image image = getImage((UIContentNode) element);
			return image;
		} else {
			return null;
		}
	}

	public String getText(Object element) {
		if (element instanceof UIContentNode) {
			String label = ((UIContentNode) element).getLabel();
			return label;
		} else {
			return null;
		}
	}

	protected Image getImage(UIContentNode object) {
		try {
			return languageUtils.getImage(object.getImage());
		} catch (Exception e) {
			XtextLog.logInfo("Error loading image of " + object
					+ " for the outline view : " + e.getMessage());
			return null;
		}
	}
}