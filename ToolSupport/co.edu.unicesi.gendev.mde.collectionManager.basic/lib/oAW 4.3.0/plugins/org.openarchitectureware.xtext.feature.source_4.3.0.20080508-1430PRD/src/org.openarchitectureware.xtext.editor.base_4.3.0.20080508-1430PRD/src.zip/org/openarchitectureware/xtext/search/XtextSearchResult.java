/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.search;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.search.ui.ISearchQuery;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.IEditorMatchAdapter;
import org.eclipse.search.ui.text.IFileMatchAdapter;
import org.eclipse.search.ui.text.Match;
import org.eclipse.ui.IEditorPart;
import org.openarchitectureware.xtext.editor.AbstractXtextEditor;

public class XtextSearchResult extends AbstractTextSearchResult implements
		IEditorMatchAdapter {

	private ISearchQuery xtextSearchQuery;

	public XtextSearchResult(ISearchQuery xtextSearchQuery) {
		this.xtextSearchQuery = xtextSearchQuery;
	}
	
	@Override
	public IEditorMatchAdapter getEditorMatchAdapter() {
		return this;
	}

	@Override
	public IFileMatchAdapter getFileMatchAdapter() {
		return null;
	}

	public ImageDescriptor getImageDescriptor() {
		return null;
	}

	public String getLabel() {
		return xtextSearchQuery.getLabel();
	}

	public ISearchQuery getQuery() {
		return xtextSearchQuery;
	}

	public String getTooltip() {
		return getLabel();
	}

	public Match[] computeContainedMatches(AbstractTextSearchResult result,
			IEditorPart editor) {
		return null;
	}

	public boolean isShownInEditor(Match match, IEditorPart editor) {
		if (match.getElement() instanceof XtextSearchMatch
				&& editor instanceof AbstractXtextEditor) {
			XtextSearchMatch xtextMatch = (XtextSearchMatch) match.getElement();
			AbstractXtextEditor xtextEditor = (AbstractXtextEditor) editor;
			return xtextMatch.getFile().equals(xtextEditor.getFile());
		}
		return false;
	}

}
