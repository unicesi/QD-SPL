/**
 * 
 */
package org.openarchitectureware.xtext.editor.outline;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.ui.PlatformUI;
import org.openarchitectureware.xtext.BaseEditorPlugin;

public class OutlineSortingAction extends Action {

	/**
	 * 
	 */
	private XtextContentOutlinePage xtextContentOutlinePage;

	// bringed-here constants for dependencies shooting...:
	public static final String LEXICAL_SORTING_OUTLINE_ACTION = BaseEditorPlugin.getDefault().getBundle().getSymbolicName() + ".xtext_outline_sorting_action"; //$NON-NLS-1$

	private OutlineElementComparator fComparator = new OutlineElementComparator();
	private ViewerComparator fSourcePositonComparator = new ViewerComparator() {
		// this "sorter" has the role not to sort anything, so outline
		// elements are displayed in the order they appear
		public int compare(Viewer viewer, Object e1, Object e2) {
			return 0;
		}
	};

	public OutlineSortingAction(XtextContentOutlinePage xtextContentOutlinePage) {
		super();
		this.xtextContentOutlinePage = xtextContentOutlinePage;

		PlatformUI.getWorkbench().getHelpSystem().setHelp(this, LEXICAL_SORTING_OUTLINE_ACTION);
//		setText("Sort");

		this.setImageDescriptor(BaseEditorPlugin.getImageDescriptorFromBase("icons/alphab_sort_co.gif")); //$NON-NLS-1$
		setToolTipText("Sort");
		setDescription("Sort");

		boolean checked = BaseEditorPlugin.getDefault().getPreferenceStore().getBoolean("XtextSortingAction.isChecked"); //$NON-NLS-1$
		valueChanged(checked, false);
	}

	// if the action is triggered
	public void run() {
		valueChanged(isChecked(), true);
	}

	// if the user decided to change the value of the sorting method
	private void valueChanged(final boolean on, boolean store) {
		TreeViewer treeViewer = xtextContentOutlinePage.getTreeViewer();
		ISelection selection = treeViewer.getSelection();
		TreePath[] expandedTreePaths = treeViewer.getExpandedTreePaths();
		setChecked(on);

		final TreeViewer fOutlineViewer = this.xtextContentOutlinePage.getTreeViewer();

		BusyIndicator.showWhile(fOutlineViewer.getControl().getDisplay(), new Runnable() {
			public void run() {
				if (on)
					fOutlineViewer.setComparator(fComparator);
				else
					fOutlineViewer.setComparator(fSourcePositonComparator);
			}
		});

		if (store)
			BaseEditorPlugin.getDefault().getPreferenceStore().setValue("XtextSortingAction.isChecked", on); //$NON-NLS-1$
		
		treeViewer.setSelection(selection);
		treeViewer.setExpandedTreePaths(expandedTreePaths);

	}
}