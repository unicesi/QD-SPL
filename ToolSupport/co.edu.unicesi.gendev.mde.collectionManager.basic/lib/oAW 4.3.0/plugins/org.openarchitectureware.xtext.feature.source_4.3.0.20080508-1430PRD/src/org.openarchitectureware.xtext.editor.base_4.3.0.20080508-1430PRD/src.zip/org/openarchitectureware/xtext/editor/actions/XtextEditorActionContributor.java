package org.openarchitectureware.xtext.editor.actions;

import java.util.ResourceBundle;

import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.texteditor.BasicTextEditorActionContributor;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.RetargetTextEditorAction;

public class XtextEditorActionContributor extends
		BasicTextEditorActionContributor {

	private static final String BUNDLE_NAME = "org.openarchitectureware.xtext.editor.actions.Actionmessages";
	public static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(BUNDLE_NAME);
	private RetargetTextEditorAction showOutline;
	
	public XtextEditorActionContributor() {
		showOutline= new RetargetTextEditorAction(RESOURCE_BUNDLE, "ShowOutline."); //$NON-NLS-1$
		showOutline.setActionDefinitionId(IXtextEditorActionDefinitionIds.SHOW_OUTLINE);
	}
	
	@Override
	public void setActiveEditor(IEditorPart part) {
		super.setActiveEditor(part);

		ITextEditor textEditor= null;
		if (part instanceof ITextEditor)
			textEditor= (ITextEditor)part;

		showOutline.setAction(getAction(textEditor, IXtextEditorActionDefinitionIds.SHOW_OUTLINE));
	}
	
}
