/**
 * <copyright>
 * </copyright>
 *
 * $Id: Proposal.java,v 1.1.2.3 2008/04/10 10:05:55 freter Exp $
 */
package org.openarchitectureware.xtext.editor.contentassist.codeassist;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Proposal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getLabel <em>Label</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getToInsert <em>To Insert</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getImage <em>Image</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getData <em>Data</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getModelElement <em>Model Element</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getType <em>Type</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getStartReplace <em>Start Replace</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getEndReplace <em>End Replace</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#isApplyPrefixFilter <em>Apply Prefix Filter</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage#getProposal()
 * @model
 * @generated
 */
public interface Proposal extends EObject {
	/**
	 * Returns the value of the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Label</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Label</em>' attribute.
	 * @see #setLabel(String)
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage#getProposal_Label()
	 * @model
	 * @generated
	 */
	String getLabel();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getLabel <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Label</em>' attribute.
	 * @see #getLabel()
	 * @generated
	 */
	void setLabel(String value);

	/**
	 * Returns the value of the '<em><b>To Insert</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>To Insert</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>To Insert</em>' attribute.
	 * @see #setToInsert(String)
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage#getProposal_ToInsert()
	 * @model
	 * @generated
	 */
	String getToInsert();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getToInsert <em>To Insert</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>To Insert</em>' attribute.
	 * @see #getToInsert()
	 * @generated
	 */
	void setToInsert(String value);

	/**
	 * Returns the value of the '<em><b>Image</b></em>' attribute.
	 * The default value is <code>"default.gif"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Image</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Image</em>' attribute.
	 * @see #setImage(String)
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage#getProposal_Image()
	 * @model default="default.gif"
	 * @generated
	 */
	String getImage();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getImage <em>Image</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Image</em>' attribute.
	 * @see #getImage()
	 * @generated
	 */
	void setImage(String value);

	/**
	 * Returns the value of the '<em><b>Data</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.emf.ecore.EObject}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data</em>' containment reference list.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage#getProposal_Data()
	 * @model type="org.eclipse.emf.ecore.EObject" containment="true"
	 * @generated
	 */
	EList getData();

	/**
	 * Returns the value of the '<em><b>Model Element</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Model Element</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Model Element</em>' reference.
	 * @see #setModelElement(EObject)
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage#getProposal_ModelElement()
	 * @model
	 * @generated
	 */
	EObject getModelElement();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getModelElement <em>Model Element</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Model Element</em>' reference.
	 * @see #getModelElement()
	 * @generated
	 */
	void setModelElement(EObject value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Type}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Type
	 * @see #setType(Type)
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage#getProposal_Type()
	 * @model
	 * @generated
	 */
	Type getType();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Type
	 * @see #getType()
	 * @generated
	 */
	void setType(Type value);

	/**
	 * Returns the value of the '<em><b>Start Replace</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Start Replace</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start Replace</em>' attribute.
	 * @see #setStartReplace(int)
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage#getProposal_StartReplace()
	 * @model default="0"
	 * @generated
	 */
	int getStartReplace();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getStartReplace <em>Start Replace</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start Replace</em>' attribute.
	 * @see #getStartReplace()
	 * @generated
	 */
	void setStartReplace(int value);

	/**
	 * Returns the value of the '<em><b>End Replace</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>End Replace</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>End Replace</em>' attribute.
	 * @see #setEndReplace(int)
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage#getProposal_EndReplace()
	 * @model default="0"
	 * @generated
	 */
	int getEndReplace();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getEndReplace <em>End Replace</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>End Replace</em>' attribute.
	 * @see #getEndReplace()
	 * @generated
	 */
	void setEndReplace(int value);

	/**
	 * Returns the value of the '<em><b>Apply Prefix Filter</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Apply Prefix Filter</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Apply Prefix Filter</em>' attribute.
	 * @see #setApplyPrefixFilter(boolean)
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage#getProposal_ApplyPrefixFilter()
	 * @model default="false"
	 * @generated
	 */
	boolean isApplyPrefixFilter();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#isApplyPrefixFilter <em>Apply Prefix Filter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Apply Prefix Filter</em>' attribute.
	 * @see #isApplyPrefixFilter()
	 * @generated
	 */
	void setApplyPrefixFilter(boolean value);

} // Proposal
