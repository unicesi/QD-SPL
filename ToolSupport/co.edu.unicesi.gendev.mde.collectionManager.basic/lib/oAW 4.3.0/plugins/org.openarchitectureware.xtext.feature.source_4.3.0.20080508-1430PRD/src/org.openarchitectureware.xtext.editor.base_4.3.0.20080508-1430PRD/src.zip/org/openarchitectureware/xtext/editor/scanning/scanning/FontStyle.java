/**
 * <copyright>
 * </copyright>
 *
 * $Id: FontStyle.java,v 1.1.2.1 2008/02/04 21:24:05 berndkolb Exp $
 */
package org.openarchitectureware.xtext.editor.scanning.scanning;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Font Style</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isBold <em>Bold</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isItalic <em>Italic</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isUnderline <em>Underline</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isStrikethrough <em>Strikethrough</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#getForgroundColor <em>Forground Color</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#getBackgroundColor <em>Background Color</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.editor.scanning.scanning.ScanningPackage#getFontStyle()
 * @model
 * @generated
 */
public interface FontStyle extends EObject {
	/**
	 * Returns the value of the '<em><b>Bold</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bold</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bold</em>' attribute.
	 * @see #setBold(boolean)
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.ScanningPackage#getFontStyle_Bold()
	 * @model
	 * @generated
	 */
	boolean isBold();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isBold <em>Bold</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bold</em>' attribute.
	 * @see #isBold()
	 * @generated
	 */
	void setBold(boolean value);

	/**
	 * Returns the value of the '<em><b>Italic</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Italic</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Italic</em>' attribute.
	 * @see #setItalic(boolean)
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.ScanningPackage#getFontStyle_Italic()
	 * @model
	 * @generated
	 */
	boolean isItalic();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isItalic <em>Italic</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Italic</em>' attribute.
	 * @see #isItalic()
	 * @generated
	 */
	void setItalic(boolean value);

	/**
	 * Returns the value of the '<em><b>Underline</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Underline</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Underline</em>' attribute.
	 * @see #setUnderline(boolean)
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.ScanningPackage#getFontStyle_Underline()
	 * @model
	 * @generated
	 */
	boolean isUnderline();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isUnderline <em>Underline</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Underline</em>' attribute.
	 * @see #isUnderline()
	 * @generated
	 */
	void setUnderline(boolean value);

	/**
	 * Returns the value of the '<em><b>Strikethrough</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Strikethrough</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Strikethrough</em>' attribute.
	 * @see #setStrikethrough(boolean)
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.ScanningPackage#getFontStyle_Strikethrough()
	 * @model
	 * @generated
	 */
	boolean isStrikethrough();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isStrikethrough <em>Strikethrough</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Strikethrough</em>' attribute.
	 * @see #isStrikethrough()
	 * @generated
	 */
	void setStrikethrough(boolean value);

	/**
	 * Returns the value of the '<em><b>Forground Color</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Forground Color</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Forground Color</em>' containment reference.
	 * @see #setForgroundColor(Color)
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.ScanningPackage#getFontStyle_ForgroundColor()
	 * @model containment="true"
	 * @generated
	 */
	Color getForgroundColor();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#getForgroundColor <em>Forground Color</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Forground Color</em>' containment reference.
	 * @see #getForgroundColor()
	 * @generated
	 */
	void setForgroundColor(Color value);

	/**
	 * Returns the value of the '<em><b>Background Color</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Background Color</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Background Color</em>' containment reference.
	 * @see #setBackgroundColor(Color)
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.ScanningPackage#getFontStyle_BackgroundColor()
	 * @model containment="true"
	 * @generated
	 */
	Color getBackgroundColor();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#getBackgroundColor <em>Background Color</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Background Color</em>' containment reference.
	 * @see #getBackgroundColor()
	 * @generated
	 */
	void setBackgroundColor(Color value);

} // FontStyle
