/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare 
 *******************************************************************************/
package org.openarchitectureware.xtext;

public class GeneratorConfig {
	private static String languageName = null;

	private static String nsURI = null;

	private static String fileExtension = null;

	private static String basePackage = null;

	private static String coreProjectName = null;
	private static String coreSrc = null;
	private static String coreSrcGen = null;
	private static String editorSrc = null;
	private static String editorSrcGen = null;
	private static String editorProjectName = null;
	private static String generatorProjectName = null;

	private static boolean debugGrammar = false;

	public static void setDebugGrammar(Boolean debuggrammer) {
		GeneratorConfig.debugGrammar = debuggrammer;
	}

	public static boolean getDebugGrammar() {
		return debugGrammar;
	}

	public static String getCoreSrc() {
		return coreSrc;
	}

	public void setCoreSrc(String coreSrc) {
		GeneratorConfig.coreSrc = coreSrc;
	}

	public static String getCoreSrcGen() {
		return coreSrcGen;
	}

	public void setGeneratorProjectName(String generatorProjectName) {
		if (generatorProjectName == null || generatorProjectName.trim().length() == 0) {
			GeneratorConfig.generatorProjectName = null;
		} else {
			GeneratorConfig.generatorProjectName = generatorProjectName;
		}
	}

	public static String getGeneratorProjectName() {
		return generatorProjectName;
	}

	public void setCoreSrcGen(String coreSrcGen) {
		GeneratorConfig.coreSrcGen = coreSrcGen;
	}

	public static String getEditorSrc() {
		return editorSrc;
	}

	public void setEditorSrc(String editorSrc) {
		GeneratorConfig.editorSrc = editorSrc;
	}

	public static String getEditorSrcGen() {
		return editorSrcGen;
	}

	public void setEditorSrcGen(String editorSrcGen) {
		GeneratorConfig.editorSrcGen = editorSrcGen;
	}

	public void setCoreProjectName(String coreProjectName) {
		GeneratorConfig.coreProjectName = coreProjectName;
	}

	public void setEditorProjectName(String editorProjectName) {
		GeneratorConfig.editorProjectName = editorProjectName;
	}

	public static String getCoreProjectName() {
		return coreProjectName;
	}

	public static String getEditorProjectName() {
		return editorProjectName;
	}

	public static String getBasePackage() {
		if (basePackage == null)
			return "my.package";
		return basePackage;
	}

	public void setBasePath(String basePackage) {
		if (basePackage.endsWith("/") || basePackage.endsWith("\\"))
			basePackage = basePackage.substring(0, basePackage.length() - 1);
		GeneratorConfig.basePackage = basePackage.replaceAll("/", ".").replaceAll("\\\\", ".");
	}

	public static String getFileExtension() {
		if (fileExtension == null) {
			return languageName.toLowerCase();
		}
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		GeneratorConfig.fileExtension = fileExtension;
	}

	public static String getLanguageName() {
		return languageName;
	}

	public void setLanguageName(String languageName) {
		GeneratorConfig.languageName = languageName;
	}

	public static String getNsURI() {
		if (nsURI == null) {
			return "http://www.openarchitectureware.org/xtext/" + getLanguageName().toLowerCase();
		}
		return nsURI;
	}

	public void setNsURI(String nsURI) {
		GeneratorConfig.nsURI = nsURI;
	}

}
