/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare 
 *******************************************************************************/
package org.openarchitectureware.xtext.xtext2ecore;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

public class EcoreUtil3 {
	
	private static Log log = LogFactory.getLog(EcoreUtil3.class);

	@SuppressWarnings("unchecked")
	public final static String getXMI(EObject obj) {

		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getProtocolToFactoryMap().put(
				"*", new XMIResourceFactoryImpl());

		Resource resource = resourceSet.createResource(URI
				.createURI("file://c:/somewhere/somefile.extension"));

		resource.getContents().add(obj);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		try {
			resource.save(outputStream, null);
		} catch (IOException ioe) {
			log.error(ioe);
		}

		return outputStream.toString();
	}

	public final static EDataType getEString() {
		return EcorePackage.eINSTANCE.getEString();
	}

	public final static EClass getEObject() {
		return EcorePackage.eINSTANCE.getEObject();
	}

	public final static EDataType getEInt() {
		return EcorePackage.eINSTANCE.getEInt();
	}

	public final static EDataType getEBoolean() {
		return EcorePackage.eINSTANCE.getEBoolean();
	}
}
