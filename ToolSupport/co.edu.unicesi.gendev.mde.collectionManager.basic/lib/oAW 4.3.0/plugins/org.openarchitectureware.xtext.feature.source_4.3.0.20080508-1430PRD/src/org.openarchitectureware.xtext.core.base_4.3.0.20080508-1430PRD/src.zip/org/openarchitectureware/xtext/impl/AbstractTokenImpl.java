/**
 * <copyright>
 * </copyright>
 *
 * $Id: AbstractTokenImpl.java,v 1.1.2.1 2008/02/08 11:45:23 berndkolb Exp $
 */
package org.openarchitectureware.xtext.impl;

import org.eclipse.emf.ecore.EClass;

import org.openarchitectureware.xtext.AbstractToken;
import org.openarchitectureware.xtext.XtextPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Abstract Token</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class AbstractTokenImpl extends ElementImpl implements AbstractToken {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbstractTokenImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return XtextPackage.Literals.ABSTRACT_TOKEN;
	}

} //AbstractTokenImpl
