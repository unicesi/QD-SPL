/**
 * <copyright>
 * </copyright>
 *
 * $Id: FileRefImpl.java,v 1.1.2.2 2008/02/08 11:45:22 berndkolb Exp $
 */
package org.openarchitectureware.xtext.impl;

import org.eclipse.emf.ecore.EClass;

import org.openarchitectureware.xtext.FileRef;
import org.openarchitectureware.xtext.XtextPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>File Ref</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class FileRefImpl extends AbstractTokenImpl implements FileRef {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FileRefImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return XtextPackage.Literals.FILE_REF;
	}

} //FileRefImpl
