/**
 * <copyright>
 * </copyright>
 *
 * $Id: CrossReference.java,v 1.2.2.2 2008/02/08 17:11:48 berndkolb Exp $
 */
package org.openarchitectureware.xtext;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cross Reference</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.CrossReference#getFeature <em>Feature</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.CrossReference#getRuleName <em>Rule Name</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.CrossReference#getType <em>Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getCrossReference()
 * @model
 * @generated
 */
public interface CrossReference extends AbstractToken {
	/**
	 * Returns the value of the '<em><b>Feature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Feature</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Feature</em>' attribute.
	 * @see #setFeature(String)
	 * @see org.openarchitectureware.xtext.XtextPackage#getCrossReference_Feature()
	 * @model
	 * @generated
	 */
	String getFeature();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.CrossReference#getFeature <em>Feature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Feature</em>' attribute.
	 * @see #getFeature()
	 * @generated
	 */
	void setFeature(String value);

	/**
	 * Returns the value of the '<em><b>Rule Name</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rule Name</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rule Name</em>' containment reference.
	 * @see #setRuleName(RuleName)
	 * @see org.openarchitectureware.xtext.XtextPackage#getCrossReference_RuleName()
	 * @model containment="true" required="true"
	 * @generated
	 */
	RuleName getRuleName();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.CrossReference#getRuleName <em>Rule Name</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rule Name</em>' containment reference.
	 * @see #getRuleName()
	 * @generated
	 */
	void setRuleName(RuleName value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' containment reference.
	 * @see #setType(TypeName)
	 * @see org.openarchitectureware.xtext.XtextPackage#getCrossReference_Type()
	 * @model containment="true" required="true"
	 * @generated
	 */
	TypeName getType();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.CrossReference#getType <em>Type</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' containment reference.
	 * @see #getType()
	 * @generated
	 */
	void setType(TypeName value);

} // CrossReference
