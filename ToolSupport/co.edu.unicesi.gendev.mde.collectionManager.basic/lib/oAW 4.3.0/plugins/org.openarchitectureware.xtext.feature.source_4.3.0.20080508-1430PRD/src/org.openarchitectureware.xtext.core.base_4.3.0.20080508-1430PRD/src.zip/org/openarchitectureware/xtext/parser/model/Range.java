package org.openarchitectureware.xtext.parser.model;


public class Range implements Comparable<Range> {

	private final int end;
	private final int start;

	public Range(int offset) {
		end = start = offset;
	}

	public Range(int start, int end) {
		this.start = start;
		this.end = end;
	}

	public int compareTo(Range o) {
		// they are overlaying
		if ((end<=o.end && start>=o.start) || (o.end<=end && o.start>= start)) {
			return 0;
		}
		if (end < o.start) {
			return -1;
		} else {
			return 1;
		}
	}

	@Override
	// This breaks the equal/hash contract...
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + end;
		result = prime * result + start;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Range other = (Range) obj;
			return compareTo(other) == 0;
	}
	
	@Override
	public String toString() {
		return "[Range: "+ start + " - " + end+"]";
	}
	
	

}
