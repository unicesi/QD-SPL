/**
 * <copyright>
 * </copyright>
 *
 * $Id: Error.java,v 1.1.2.1 2008/02/08 11:45:35 berndkolb Exp $
 */
package org.openarchitectureware.xtext.parser.parsetree;

import org.antlr.runtime.RecognitionException;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Error</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.parser.parsetree.Error#getMessage <em>Message</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.parser.parsetree.Error#getException <em>Exception</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getError()
 * @model
 * @generated
 */
public interface Error extends EObject {
	/**
	 * Returns the value of the '<em><b>Message</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Message</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Message</em>' attribute.
	 * @see #setMessage(String)
	 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getError_Message()
	 * @model
	 * @generated
	 */
	String getMessage();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.parser.parsetree.Error#getMessage <em>Message</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Message</em>' attribute.
	 * @see #getMessage()
	 * @generated
	 */
	void setMessage(String value);

	/**
	 * Returns the value of the '<em><b>Exception</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Exception</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exception</em>' attribute.
	 * @see #setException(RecognitionException)
	 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getError_Exception()
	 * @model dataType="org.openarchitectureware.xtext.parser.parsetree.RecognitionException"
	 * @generated
	 */
	RecognitionException getException();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.parser.parsetree.Error#getException <em>Exception</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Exception</em>' attribute.
	 * @see #getException()
	 * @generated
	 */
	void setException(RecognitionException value);

} // Error
