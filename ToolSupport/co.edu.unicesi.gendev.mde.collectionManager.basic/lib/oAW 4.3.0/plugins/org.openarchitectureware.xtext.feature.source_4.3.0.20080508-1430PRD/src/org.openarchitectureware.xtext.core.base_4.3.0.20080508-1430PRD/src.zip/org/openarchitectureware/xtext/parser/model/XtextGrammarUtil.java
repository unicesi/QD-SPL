package org.openarchitectureware.xtext.parser.model;

import java.util.Set;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.openarchitectureware.xtext.AbstractToken;
import org.openarchitectureware.xtext.Alternatives;
import org.openarchitectureware.xtext.Assignment;
import org.openarchitectureware.xtext.CardinalityType;
import org.openarchitectureware.xtext.CrossReference;
import org.openarchitectureware.xtext.Element;
import org.openarchitectureware.xtext.FileRef;
import org.openarchitectureware.xtext.Group;
import org.openarchitectureware.xtext.Keyword;
import org.openarchitectureware.xtext.Rule;
import org.openarchitectureware.xtext.RuleName;
import org.openarchitectureware.xtext.XtextFile;

public class XtextGrammarUtil {

	public static Rule getContainingRule(Element ass) {
		if (ass.eContainer() instanceof Rule) {
			return (Rule) ass.eContainer();
		}
		return getContainingRule((Element) ass.eContainer());
	}

	public static Assignment getContainingAssignment(AbstractToken ele) {
		if (ele == null)
			return null;
		if (ele.eContainer() instanceof Assignment) {
			Assignment ass = (Assignment) ele.eContainer();
			if (ass.getToken() == ele)
				return ass;
		}
		return null;
	}

	public static Element getContainingElement(Element ele) {
		if (ele.eContainer() instanceof Element) {
			return (Element) ele.eContainer();
		}
		return null;
	}

	public static Element getNext(Element element) {
		Element child = element;
		Element container = getContainingElement(child);
		while (container!=null && !(container instanceof Group)) {
			child = container;
			container = getContainingElement(child);
		}
		if (container != null) {
			EList<EObject> contents = container.eContents();
			int indexOf = contents.indexOf(child);
			if (contents.size() >= indexOf) {
				EObject object = contents.get(indexOf + 1);
				return (Element) object;
			}
		}
		return null;
	}

	public static boolean isCompatible(AbstractToken at1, AbstractToken at2) {
		return getTokenName(at1).equals(getTokenName(at2));
	}

	public static String getTokenName(AbstractToken at) {
		if (at == null)
			return null;
		if (at instanceof Keyword) {
			return ((Keyword) at).getValue();
		} else if (at instanceof RuleName) {
			return ((RuleName) at).getName();
		} else if (at instanceof CrossReference) {
			CrossReference cr = (CrossReference) at;
			if (cr.getRuleName() == null) {
				return "ID";
			}
			return cr.getRuleName().getName();
		} else if (at instanceof FileRef) {
			return "STRING";
		}
		throw new IllegalArgumentException(at.getClass().getSimpleName()
				+ " not handled");
	}

	@SuppressWarnings("unchecked")
	public static Rule findRule(RuleName rn) {
		XtextFile f = getXtextFile(rn);
		EList<Rule> rules = f.getRules();
		for (Rule r : rules) {
			if (r.getName().equals(rn.getName()))
				return r;
		}
		return null;
	}

	public static XtextFile getXtextFile(EObject rn) {
		return (XtextFile) EcoreUtil.getRootContainer(rn);
	}

	public static boolean isMultiMax(Element element) {
		boolean isMulti = false;
		if (element.getCardinality() != null) {
			isMulti = element.getCardinality() == CardinalityType.ANY_LITERAL
					|| element.getCardinality() == CardinalityType.ONEORMORE_LITERAL;
		}
		Group g = getGroup(element);
		while (g != null) {
			isMulti = g.getCardinality() == CardinalityType.ANY_LITERAL
					|| g.getCardinality() == CardinalityType.ONEORMORE_LITERAL;
			g = getGroup(g);
		}
		return isMulti;
	}

	private static Group getGroup(Element element) {
		if (element==null)
			return null;
		if (element instanceof Group) 
			return (Group) element;
		return getGroup(getContainingElement(element));
	}

	public static boolean isOptional(Element element) {
		boolean isMulti = false;
		if (element.getCardinality() != null) {
			isMulti = element.getCardinality() == CardinalityType.ANY_LITERAL
					|| element.getCardinality() == CardinalityType.OPTIONAL_LITERAL;
		}
		return isMulti;
	}

	public static boolean isCompatible(Set<AbstractToken> possibleTokens,
			Set<AbstractToken> possibleTokens2) {
		for (AbstractToken at : possibleTokens) {
			for (AbstractToken at2 : possibleTokens2) {
				if (isCompatible(at, at2))
					return true;
			}
		}
		return false;
	}

	public static Element normalize(Object e) {
		if (e instanceof Element) {
			return normalize((Element)e);
		}
		throw new IllegalArgumentException();
	}
	
	public static Element normalize(Element e) {
		CardinalityType cardinalityType = e.getCardinality();
		Element result =null;
		if (e instanceof Group && ((Group)e).getChildren().size()==1) {
			result  = normalize((Element) ((Group)e).getChildren().get(0));
		} else if (e instanceof Alternatives && ((Alternatives)e).getAlternatives().size()==1) {
			result = normalize((Element) ((Alternatives)e).getAlternatives().get(0));
		}
		if (result!=null && result!=e && cardinalityType!=CardinalityType.NULL_LITERAL) {
			if (result.getCardinality()!=CardinalityType.NULL_LITERAL) {
				throw new IllegalStateException();
			}
			result.setCardinality(cardinalityType);
			return result;
		}
		return result!=null?result:e;
	}

}
