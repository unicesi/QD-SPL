package org.openarchitectureware.xtext.registry;

import org.eclipse.emf.common.util.URI;

public interface URIFactory {
	URI createURI(String s);
}
