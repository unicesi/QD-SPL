/**
 * <copyright>
 * </copyright>
 *
 * $Id: EnumRule.java,v 1.1.2.3 2008/02/08 17:46:26 berndkolb Exp $
 */
package org.openarchitectureware.xtext;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Enum Rule</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.EnumRule#getLiterals <em>Literals</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getEnumRule()
 * @model
 * @generated
 */
public interface EnumRule extends RuleWithType {
	/**
	 * Returns the value of the '<em><b>Literals</b></em>' containment reference list.
	 * The list contents are of type {@link org.openarchitectureware.xtext.EnumLiteral}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Literals</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Literals</em>' containment reference list.
	 * @see org.openarchitectureware.xtext.XtextPackage#getEnumRule_Literals()
	 * @model type="org.openarchitectureware.xtext.EnumLiteral" containment="true"
	 * @generated
	 */
	EList getLiterals();

} // EnumRule
