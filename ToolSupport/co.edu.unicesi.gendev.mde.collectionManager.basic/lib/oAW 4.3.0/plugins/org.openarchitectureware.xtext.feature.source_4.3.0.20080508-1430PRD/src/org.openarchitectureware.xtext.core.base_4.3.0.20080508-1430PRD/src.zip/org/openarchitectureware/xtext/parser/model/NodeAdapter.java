package org.openarchitectureware.xtext.parser.model;

import org.eclipse.emf.common.notify.impl.AdapterImpl;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public class NodeAdapter extends AdapterImpl {
	
	private Node node;
	
	public NodeAdapter(Node n) {
		this.node = n;
	}

	public Node getNode() {
		return node;
	}

}
