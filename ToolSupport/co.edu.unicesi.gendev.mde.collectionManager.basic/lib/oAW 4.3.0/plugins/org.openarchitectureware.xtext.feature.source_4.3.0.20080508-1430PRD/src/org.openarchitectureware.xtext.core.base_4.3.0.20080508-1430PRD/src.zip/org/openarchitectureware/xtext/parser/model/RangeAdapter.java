package org.openarchitectureware.xtext.parser.model;

import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.emf.common.notify.impl.AdapterImpl;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public class RangeAdapter extends AdapterImpl{
	
	private static Log log = LogFactory.getLog(RangeAdapter.class);

	TreeMap<Range, Node> rangeNodeMap = new TreeMap<Range, Node>();

	public void add(Node node) {
		Node old = rangeNodeMap.put(new Range(node.getStart(), node.getEnd()),node);
		if (old!= null) {
			// This happens that often, I suspect it's not considered a bug anymore
			// changed log level to debug
			log.debug("RangeAdapter.add() - Old was not null");
		}
	}

	public Node getNodeAt(int offset) {
		return rangeNodeMap.get(new Range(offset));
	}

}
