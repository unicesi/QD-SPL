/**
 * <copyright>
 * </copyright>
 *
 * $Id: Group.java,v 1.1.2.2 2008/02/13 15:44:24 sefftinge Exp $
 */
package org.openarchitectureware.xtext;

import org.eclipse.emf.common.util.EList;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Group</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.Group#getChildren <em>Children</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getGroup()
 * @model
 * @generated
 */
public interface Group extends Element {
	/**
	 * Returns the value of the '<em><b>Children</b></em>' containment reference list.
	 * The list contents are of type {@link org.openarchitectureware.xtext.Element}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Children</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Children</em>' containment reference list.
	 * @see org.openarchitectureware.xtext.XtextPackage#getGroup_Children()
	 * @model type="org.openarchitectureware.xtext.Element" containment="true"
	 * @generated
	 */
	EList getChildren();

} // Group
