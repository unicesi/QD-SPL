/**
 * <copyright>
 * </copyright>
 *
 * $Id: Alternatives.java,v 1.1.2.1 2008/02/08 11:45:28 berndkolb Exp $
 */
package org.openarchitectureware.xtext;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Alternatives</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.Alternatives#getAlternatives <em>Alternatives</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getAlternatives()
 * @model
 * @generated
 */
public interface Alternatives extends Element {
	/**
	 * Returns the value of the '<em><b>Alternatives</b></em>' containment reference list.
	 * The list contents are of type {@link org.openarchitectureware.xtext.Element}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Alternatives</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Alternatives</em>' containment reference list.
	 * @see org.openarchitectureware.xtext.XtextPackage#getAlternatives_Alternatives()
	 * @model type="org.openarchitectureware.xtext.Element" containment="true"
	 * @generated
	 */
	EList getAlternatives();

} // Alternatives
