/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.parser;


public class ErrorMsg {
	private String msg;
	private int start;
	private int length;
	private int line;
	
	public ErrorMsg(String msg, int start, int length, int line) {
		super();
		this.msg = msg;
		this.start = start;
		this.length = length;
		this.line = line;
	}
	
	public int getLength() {
		return length;
	}
	public int getLine() {
		return line;
	}
	public String getMsg() {
		return msg;
	}
	public int getStart() {
		return start;
	}
	
	@Override
	public String toString() {
		return msg+" (line:"+line+", start:"+start+", length:"+length+")";
	}
}
