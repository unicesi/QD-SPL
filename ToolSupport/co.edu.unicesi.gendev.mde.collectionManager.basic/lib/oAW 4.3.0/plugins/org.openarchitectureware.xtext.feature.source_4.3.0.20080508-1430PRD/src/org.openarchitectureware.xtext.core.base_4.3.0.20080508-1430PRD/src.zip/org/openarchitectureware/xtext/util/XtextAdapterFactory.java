/**
 * <copyright>
 * </copyright>
 *
 * $Id: XtextAdapterFactory.java,v 1.2.2.5 2008/02/08 17:46:26 berndkolb Exp $
 */
package org.openarchitectureware.xtext.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import org.openarchitectureware.xtext.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.XtextPackage
 * @generated
 */
public class XtextAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static XtextPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public XtextAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = XtextPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch the delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected XtextSwitch modelSwitch =
		new XtextSwitch() {
			public Object caseXtextFile(XtextFile object) {
				return createXtextFileAdapter();
			}
			public Object caseRule(Rule object) {
				return createRuleAdapter();
			}
			public Object caseNativeLexerRule(NativeLexerRule object) {
				return createNativeLexerRuleAdapter();
			}
			public Object caseTypeRule(TypeRule object) {
				return createTypeRuleAdapter();
			}
			public Object caseTypeName(TypeName object) {
				return createTypeNameAdapter();
			}
			public Object caseStringRule(StringRule object) {
				return createStringRuleAdapter();
			}
			public Object caseEnumRule(EnumRule object) {
				return createEnumRuleAdapter();
			}
			public Object caseEnumLiteral(EnumLiteral object) {
				return createEnumLiteralAdapter();
			}
			public Object caseElement(Element object) {
				return createElementAdapter();
			}
			public Object caseGroup(Group object) {
				return createGroupAdapter();
			}
			public Object caseAlternatives(Alternatives object) {
				return createAlternativesAdapter();
			}
			public Object caseAssignment(Assignment object) {
				return createAssignmentAdapter();
			}
			public Object caseAbstractToken(AbstractToken object) {
				return createAbstractTokenAdapter();
			}
			public Object caseRuleName(RuleName object) {
				return createRuleNameAdapter();
			}
			public Object caseKeyword(Keyword object) {
				return createKeywordAdapter();
			}
			public Object caseCrossReference(CrossReference object) {
				return createCrossReferenceAdapter();
			}
			public Object caseFileRef(FileRef object) {
				return createFileRefAdapter();
			}
			public Object caseImport(Import object) {
				return createImportAdapter();
			}
			public Object caseMetamodelImport(MetamodelImport object) {
				return createMetamodelImportAdapter();
			}
			public Object caseRuleWithType(RuleWithType object) {
				return createRuleWithTypeAdapter();
			}
			public Object defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	public Adapter createAdapter(Notifier target) {
		return (Adapter)modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.XtextFile <em>File</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.XtextFile
	 * @generated
	 */
	public Adapter createXtextFileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.Rule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.Rule
	 * @generated
	 */
	public Adapter createRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.NativeLexerRule <em>Native Lexer Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.NativeLexerRule
	 * @generated
	 */
	public Adapter createNativeLexerRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.TypeRule <em>Type Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.TypeRule
	 * @generated
	 */
	public Adapter createTypeRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.TypeName <em>Type Name</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.TypeName
	 * @generated
	 */
	public Adapter createTypeNameAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.StringRule <em>String Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.StringRule
	 * @generated
	 */
	public Adapter createStringRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.EnumRule <em>Enum Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.EnumRule
	 * @generated
	 */
	public Adapter createEnumRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.EnumLiteral <em>Enum Literal</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.EnumLiteral
	 * @generated
	 */
	public Adapter createEnumLiteralAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.Element <em>Element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.Element
	 * @generated
	 */
	public Adapter createElementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.Group <em>Group</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.Group
	 * @generated
	 */
	public Adapter createGroupAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.Alternatives <em>Alternatives</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.Alternatives
	 * @generated
	 */
	public Adapter createAlternativesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.Assignment <em>Assignment</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.Assignment
	 * @generated
	 */
	public Adapter createAssignmentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.AbstractToken <em>Abstract Token</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.AbstractToken
	 * @generated
	 */
	public Adapter createAbstractTokenAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.RuleName <em>Rule Name</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.RuleName
	 * @generated
	 */
	public Adapter createRuleNameAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.Keyword <em>Keyword</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.Keyword
	 * @generated
	 */
	public Adapter createKeywordAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.CrossReference <em>Cross Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.CrossReference
	 * @generated
	 */
	public Adapter createCrossReferenceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.FileRef <em>File Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.FileRef
	 * @generated
	 */
	public Adapter createFileRefAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.Import <em>Import</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.Import
	 * @generated
	 */
	public Adapter createImportAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.MetamodelImport <em>Metamodel Import</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.MetamodelImport
	 * @generated
	 */
	public Adapter createMetamodelImportAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.openarchitectureware.xtext.RuleWithType <em>Rule With Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.openarchitectureware.xtext.RuleWithType
	 * @generated
	 */
	public Adapter createRuleWithTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //XtextAdapterFactory
