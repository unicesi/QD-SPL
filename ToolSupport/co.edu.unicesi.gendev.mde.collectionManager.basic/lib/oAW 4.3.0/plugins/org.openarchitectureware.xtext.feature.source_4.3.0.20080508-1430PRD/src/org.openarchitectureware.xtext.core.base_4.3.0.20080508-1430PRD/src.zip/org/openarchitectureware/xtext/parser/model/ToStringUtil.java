package org.openarchitectureware.xtext.parser.model;

import java.util.List;

import org.openarchitectureware.xtext.Assignment;
import org.openarchitectureware.xtext.Element;
import org.openarchitectureware.xtext.EnumLiteral;
import org.openarchitectureware.xtext.Keyword;
import org.openarchitectureware.xtext.Rule;
import org.openarchitectureware.xtext.RuleName;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public class ToStringUtil {
	@SuppressWarnings("unchecked")
	public static String toString(org.eclipse.emf.ecore.EObject x) {
		if (x == null)
			return "null";
		String suffix = "";
		String main = "";
		String prefix = x.eClass().getName();
		if (x instanceof Element) {
			String literal = ((Element) x).getCardinality().getLiteral();
			suffix = !literal.equals("NULL")?literal:"";
		}
		if (x instanceof Assignment) {
			Assignment a = (Assignment) x;
			main = XtextGrammarUtil.getContainingRule(a).getName() + "."
					+ a.getFeature();
		} else if (x instanceof RuleName) {
			RuleName new_name = (RuleName) x;
			main = new_name.getName();
		} else if (x instanceof Keyword) {
			Keyword kw = (Keyword) x;
			main = "'"+kw.getValue()+"'";
		} else if (x instanceof Rule) {
			Rule kw = (Rule) x;
			main = kw.getName();
		} else if (x instanceof EnumLiteral) {
			EnumLiteral new_name = (EnumLiteral) x;
			main = new_name.getKeyword();
		} else if (x instanceof Node) {
			Node n = (Node) x;
			String s = indent(n);
			s += "l:" + n.getLine() + ",s:" + n.getStart() + ",e:" + n.getEnd();
			if (n.getGrammarElement() != null) {
				s += " Grammar:" + toString(n.getGrammarElement());
			}
			if (n.getModelElement() != null) {
				s += " Model:" + n.getModelElement().eClass().getName();
			}
			s += "\n";
			for (Node node : (List<Node>) n.getChildren()) {
				s += toString(node);
			}
			return s;
		}
		return prefix+":"+main+" "+suffix;
	}

	private static String indent(Node n) {
		if (n == null)
			return "";
		return indent(n.getParent()) + "\t";
	}
}
