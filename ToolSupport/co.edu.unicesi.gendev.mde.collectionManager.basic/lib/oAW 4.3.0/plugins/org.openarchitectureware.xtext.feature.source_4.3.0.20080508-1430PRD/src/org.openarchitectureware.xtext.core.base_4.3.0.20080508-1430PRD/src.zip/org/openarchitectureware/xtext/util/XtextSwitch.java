/**
 * <copyright>
 * </copyright>
 *
 * $Id: XtextSwitch.java,v 1.2.2.7 2008/02/13 15:44:25 sefftinge Exp $
 */
package org.openarchitectureware.xtext.util;

import java.util.List;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.openarchitectureware.xtext.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.XtextPackage
 * @generated
 */
public class XtextSwitch {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static XtextPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public XtextSwitch() {
		if (modelPackage == null) {
			modelPackage = XtextPackage.eINSTANCE;
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	public Object doSwitch(EObject theEObject) {
		return doSwitch(theEObject.eClass(), theEObject);
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	protected Object doSwitch(EClass theEClass, EObject theEObject) {
		if (theEClass.eContainer() == modelPackage) {
			return doSwitch(theEClass.getClassifierID(), theEObject);
		}
		else {
			List eSuperTypes = theEClass.getESuperTypes();
			return
				eSuperTypes.isEmpty() ?
					defaultCase(theEObject) :
					doSwitch((EClass)eSuperTypes.get(0), theEObject);
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	protected Object doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case XtextPackage.XTEXT_FILE: {
				XtextFile xtextFile = (XtextFile)theEObject;
				Object result = caseXtextFile(xtextFile);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.RULE: {
				Rule rule = (Rule)theEObject;
				Object result = caseRule(rule);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.NATIVE_LEXER_RULE: {
				NativeLexerRule nativeLexerRule = (NativeLexerRule)theEObject;
				Object result = caseNativeLexerRule(nativeLexerRule);
				if (result == null) result = caseRule(nativeLexerRule);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.TYPE_RULE: {
				TypeRule typeRule = (TypeRule)theEObject;
				Object result = caseTypeRule(typeRule);
				if (result == null) result = caseRuleWithType(typeRule);
				if (result == null) result = caseRule(typeRule);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.TYPE_NAME: {
				TypeName typeName = (TypeName)theEObject;
				Object result = caseTypeName(typeName);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.STRING_RULE: {
				StringRule stringRule = (StringRule)theEObject;
				Object result = caseStringRule(stringRule);
				if (result == null) result = caseRule(stringRule);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.ENUM_RULE: {
				EnumRule enumRule = (EnumRule)theEObject;
				Object result = caseEnumRule(enumRule);
				if (result == null) result = caseRuleWithType(enumRule);
				if (result == null) result = caseRule(enumRule);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.ENUM_LITERAL: {
				EnumLiteral enumLiteral = (EnumLiteral)theEObject;
				Object result = caseEnumLiteral(enumLiteral);
				if (result == null) result = caseAbstractToken(enumLiteral);
				if (result == null) result = caseElement(enumLiteral);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.ELEMENT: {
				Element element = (Element)theEObject;
				Object result = caseElement(element);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.GROUP: {
				Group group = (Group)theEObject;
				Object result = caseGroup(group);
				if (result == null) result = caseElement(group);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.ALTERNATIVES: {
				Alternatives alternatives = (Alternatives)theEObject;
				Object result = caseAlternatives(alternatives);
				if (result == null) result = caseElement(alternatives);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.ASSIGNMENT: {
				Assignment assignment = (Assignment)theEObject;
				Object result = caseAssignment(assignment);
				if (result == null) result = caseElement(assignment);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.ABSTRACT_TOKEN: {
				AbstractToken abstractToken = (AbstractToken)theEObject;
				Object result = caseAbstractToken(abstractToken);
				if (result == null) result = caseElement(abstractToken);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.RULE_NAME: {
				RuleName ruleName = (RuleName)theEObject;
				Object result = caseRuleName(ruleName);
				if (result == null) result = caseAbstractToken(ruleName);
				if (result == null) result = caseElement(ruleName);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.KEYWORD: {
				Keyword keyword = (Keyword)theEObject;
				Object result = caseKeyword(keyword);
				if (result == null) result = caseAbstractToken(keyword);
				if (result == null) result = caseElement(keyword);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.CROSS_REFERENCE: {
				CrossReference crossReference = (CrossReference)theEObject;
				Object result = caseCrossReference(crossReference);
				if (result == null) result = caseAbstractToken(crossReference);
				if (result == null) result = caseElement(crossReference);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.FILE_REF: {
				FileRef fileRef = (FileRef)theEObject;
				Object result = caseFileRef(fileRef);
				if (result == null) result = caseAbstractToken(fileRef);
				if (result == null) result = caseElement(fileRef);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.IMPORT: {
				Import import_ = (Import)theEObject;
				Object result = caseImport(import_);
				if (result == null) result = caseAbstractToken(import_);
				if (result == null) result = caseElement(import_);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.METAMODEL_IMPORT: {
				MetamodelImport metamodelImport = (MetamodelImport)theEObject;
				Object result = caseMetamodelImport(metamodelImport);
				if (result == null) result = caseAbstractToken(metamodelImport);
				if (result == null) result = caseElement(metamodelImport);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case XtextPackage.RULE_WITH_TYPE: {
				RuleWithType ruleWithType = (RuleWithType)theEObject;
				Object result = caseRuleWithType(ruleWithType);
				if (result == null) result = caseRule(ruleWithType);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>File</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>File</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseXtextFile(XtextFile object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Rule</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Rule</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseRule(Rule object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Native Lexer Rule</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Native Lexer Rule</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseNativeLexerRule(NativeLexerRule object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Type Rule</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Type Rule</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseTypeRule(TypeRule object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Type Name</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Type Name</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseTypeName(TypeName object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>String Rule</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>String Rule</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseStringRule(StringRule object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Enum Rule</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Enum Rule</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseEnumRule(EnumRule object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Enum Literal</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Enum Literal</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseEnumLiteral(EnumLiteral object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseElement(Element object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Group</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Group</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseGroup(Group object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Alternatives</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Alternatives</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseAlternatives(Alternatives object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Assignment</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Assignment</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseAssignment(Assignment object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Abstract Token</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Abstract Token</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseAbstractToken(AbstractToken object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Rule Name</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Rule Name</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseRuleName(RuleName object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Keyword</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Keyword</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseKeyword(Keyword object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Cross Reference</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Cross Reference</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseCrossReference(CrossReference object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>File Ref</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>File Ref</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseFileRef(FileRef object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Import</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Import</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseImport(Import object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Metamodel Import</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Metamodel Import</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseMetamodelImport(MetamodelImport object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Rule With Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Rule With Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseRuleWithType(RuleWithType object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	public Object defaultCase(EObject object) {
		return null;
	}

} //XtextSwitch
