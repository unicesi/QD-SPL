package org.openarchitectureware.xtext.parser.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.impl.AdapterImpl;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.ecore.EObject;

public class ParseStringAdapter extends AdapterImpl {
	
	public static String findString(EObject o, String s) {
		for (Adapter a : o.eAdapters()) {
			if (a instanceof ParseStringAdapter) {
				ParseStringAdapter psa = (ParseStringAdapter) a;
				return psa.getAsString(s);
			}
		}
		return null;
	}
	
	public static Collection find(EObject o, String s) {
		for (Adapter a : o.eAdapters()) {
			if (a instanceof ParseStringAdapter) {
				ParseStringAdapter psa = (ParseStringAdapter) a;
				return psa.get(s);
			}
		}
		return Collections.EMPTY_LIST;
	}
	

	public static ParseStringAdapter getAdapter(EObject o) {
		for (Adapter a : o.eAdapters()) {
			if (a instanceof ParseStringAdapter) {
				return (ParseStringAdapter) a;
			}
		}
		ParseStringAdapter parseStringAdapter = new ParseStringAdapter();
		o.eAdapters().add(parseStringAdapter);
		return parseStringAdapter;
	}
	
	private String getAsString(String s) {
		return properties.get(s).toString();
	}

	private Collection get(String s) {
		return (Collection) properties.get(s);
	}

	private Map<String, Object> properties = new HashMap<String, Object>();
	
	public void put(String propertyName, Object arg) {
		properties.put(propertyName, arg);
	}

	public void add(String featureName, Object arg) {
		List l = (List) properties.get(featureName);
		if (l == null) {
			l = new BasicEList();
			properties.put(featureName, l);
		}
		l.add(arg);
	}

}
