/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.parser.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.antlr.runtime.Token;
import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EEnumLiteral;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.openarchitectureware.xtext.AbstractToken;
import org.openarchitectureware.xtext.Alternatives;
import org.openarchitectureware.xtext.AssignOperator;
import org.openarchitectureware.xtext.Assignment;
import org.openarchitectureware.xtext.CardinalityType;
import org.openarchitectureware.xtext.CrossReference;
import org.openarchitectureware.xtext.Element;
import org.openarchitectureware.xtext.EnumRule;
import org.openarchitectureware.xtext.Group;
import org.openarchitectureware.xtext.Keyword;
import org.openarchitectureware.xtext.NativeLexerRule;
import org.openarchitectureware.xtext.Rule;
import org.openarchitectureware.xtext.RuleName;
import org.openarchitectureware.xtext.StringRule;
import org.openarchitectureware.xtext.TypeRule;
import org.openarchitectureware.xtext.XtextFile;
import org.openarchitectureware.xtext.parser.parsetree.Node;
import org.openarchitectureware.xtext.parser.parsetree.ParsetreeFactory;

public class NodeUtil {

	public static Node getRoot(Node n) {
		return (Node) EcoreUtil.getRootContainer(n);
	}

	public static Node getNodeBeforeOffset(Node n, int offset) {
		return internalFindNodeBeforeOffset(getRoot(n), offset);
	}

	@SuppressWarnings("unchecked")
	private static Node internalFindNodeBeforeOffset(Node n, int offset) {
		if (n == null)
			return null;
		EList<Node> list = n.getChildren();
		Node last = null;
		for (Node node : list) {
			if ((node.getErrors().isEmpty() || !node.getChildren().isEmpty()) && node.getLine() > 0) {
				if (node.getStart() >= offset) {
					return internalFindNodeBeforeOffset(last, offset);
				}
				last = node;
			}
		}
		if (last != null) {
			return internalFindNodeBeforeOffset(last, offset);
		}
		return n;
	}

	public static Node findNodeUnderOffset(Node n, int offset) {
		return internalFindNodeUnderOffset(getRoot(n), offset);
	}

	/*
	 * Binary tree search using a Treemap. Adapter is used as index
	 */
	private static Node internalFindNodeUnderOffset(Node n, int offset) {
		if (n == null)
			return null;
		if (!n.getErrors().isEmpty() && n.getLine() <= 0) {
			return n;
		}
		Node nodeAtOffset = getRangeAdapter(n).getNodeAt(offset);
		if (nodeAtOffset == null) {
			return n;
		}
		return internalFindNodeUnderOffset(nodeAtOffset, offset);
	}

	private static RangeAdapter getRangeAdapter(Node parent) {
		for (Adapter a : parent.eAdapters()) {
			if (a instanceof RangeAdapter) {
				return (RangeAdapter) a;

			}
		}
		return new RangeAdapter();
	}

	public static String getText(String document, Node n) {
		int end = n.getEnd();
		if (document.length() <= end) {
			end = document.length();
		}
		int start = n.getStart();
		if (start < 0)
			start = 0;
		if (start >= end)
			start = end - 1;
		return document.substring(start, end);
	}

	public static EObject getModelElement(Node n) {
		if (n == null)
			return null;
		EObject modelElement = n.getModelElement();
		if (modelElement != null && !(modelElement instanceof EEnumLiteral))
			return modelElement;
		return getModelElement(n.getParent());
	}

	public static Set<Element> getPossibleFollows(Node last) {
		if (last.getGrammarElement() instanceof XtextFile) {
			return getPossibleTokens((Rule) ((XtextFile) last
					.getGrammarElement()).getRules().get(0));
		} else if (last.getGrammarElement() instanceof Rule) {
			return getPossibleTokens((Rule) last.getGrammarElement());
		} else if (last.getGrammarElement() instanceof Element) {
			// traceback
			Set<Element> branches = getPossibleNexts(last, (Element) last
					.getGrammarElement());
			Set<Element> result = new LinkedHashSet<Element>();
			for (Element element : branches) {
				result.addAll(getPossibleTokens(element));
			}
			return result;
		}
		throw new IllegalArgumentException();
	}

	private static Set<Element> getPossibleNexts(Node trace, Element e) {
		Set<Element> result = new LinkedHashSet<Element>();
		if (e.eContainer() instanceof Element) {
			Element parent = (Element) e.eContainer();
			if (parent instanceof Group) {
				Group g = (Group) parent;
				int indexOf = g.getChildren().indexOf(e) + 1;
				int size = g.getChildren().size();
		
				// the current one if has an oneOrMore cardinality
				if  (CardinalityType.ONEORMORE_LITERAL.equals(e.getCardinality())) {
						result.addAll(getPossibleTokens(e));
				}

				/**
				 * start at the current (maybe the last) or at the next one with 
				 * optional cardinality and add all following with optional cardinality
				 */
				Element last = CardinalityType.ANY_LITERAL.equals(e.getCardinality()) || indexOf == size ? 
						e : (Element) g.getChildren().get(indexOf);
				
				while (XtextGrammarUtil.isOptional(last) && indexOf < size) {
					result.addAll(getPossibleTokens(last));
				    last = indexOf<size ? (Element) g.getChildren().get(indexOf++):last;
				}

				// always add the following if available or the last one if has an any cardinality
				if (last!=e || CardinalityType.ANY_LITERAL.equals(last.getCardinality())) {
					result.addAll(getPossibleTokens(last));
				}
				
				// ask parent groups only if we've completed the whole group
				if (indexOf == size && (last == e || XtextGrammarUtil.isOptional(last))) {
					result.addAll(getPossibleNexts(trace, parent));
				}
			} else {
				result.addAll(getPossibleNexts(trace, parent));
			}
		} else {
			trace = trace.getParent();
			while (trace != null && trace.getGrammarElement() == null)
				trace = trace.getParent();
			if (trace != null) {
				result.addAll(getPossibleNexts(trace, (Element) trace
						.getGrammarElement()));
			}  else if (e instanceof Assignment && e.eContainer()
					instanceof TypeRule) {
	            /** 
	             * handle special case if a typerule consists only 
	             * of one assignment (in contrast to a group of assignments)
	             * @see https://bugs.eclipse.org/bugs/show_bug.cgi?id=219245
	             */
	            if (CardinalityType.ONEORMORE_LITERAL.equals(e.getCardinality()) || XtextGrammarUtil.isOptional(e)) {
	                    result.addAll(getPossibleTokens(e));
	            }
			}
				
		}
		return result;
	}

	public static Set<Element> getPossibleFollows(XtextFile file, Node last) {
		if (last == null || last.getGrammarElement() == null) {
			last = ParsetreeFactory.eINSTANCE.createNode();
			last.setGrammarElement(file);
		}
		return getPossibleFollows(last);
	}

	private static Set<Element> getPossibleTokens(Element next) {
		Set<Element> eles = new LinkedHashSet<Element>();
		if (next instanceof Alternatives) {
			Alternatives alt = (Alternatives) next;
			eles.addAll(getPossibleTokens(alt));
		} else if (next instanceof Assignment) {
			Assignment ass = (Assignment) next;
			eles.addAll(getPossibleTokens(ass));
		} else if (next instanceof Group) {
			Group g = (Group) next;
			eles.addAll(getPossibleTokens(g));
		} else if (next instanceof Keyword) {
			Keyword kw = (Keyword) next;
			eles.add(kw);
		} else if (next instanceof RuleName) {
			RuleName rn = (RuleName) next;
			eles.addAll(getPossibleTokens(rn));
		} else if (next instanceof CrossReference) {
			eles.add(next);
		}
		return eles;
	}

	/**
	 * @param modelElement
	 * @return the corresponding Node
	 */
	@SuppressWarnings("unchecked")
	public static Node getNode(EObject modelElement) {
		EList<Adapter> adapters = modelElement.eAdapters();
		for (Adapter adapter : adapters) {
			if (adapter instanceof NodeAdapter)
				return ((NodeAdapter) adapter).getNode();
		}
		return null;
	}

	private static Set<Element> getPossibleTokens(RuleName rn) {
		Rule r = findRule(rn);
		if (r instanceof NativeLexerRule) {
			return Collections.<Element> singleton(rn);
		} else {
			return getPossibleTokens(r);
		}
	}

	@SuppressWarnings("unchecked")
	private static Rule findRule(RuleName name) {
		XtextFile f = (XtextFile) EcoreUtil.getRootContainer(name);
		List<Rule> rules = f.getRules();
		for (Rule rule : rules) {
			if (rule.getName().equals(name.getName()))
				return rule;
		}
		return null;
	}

	private static Set<Element> getPossibleTokens(Assignment ass) {
		Set<Element> result = new LinkedHashSet<Element>();
		result.add(ass);
		if (ass.getOperator().getValue() == AssignOperator.BOOLASSIGN)
			return result;
		result.addAll(getPossibleTokens(ass.getToken()));
		return result;
	}

	@SuppressWarnings("unchecked")
	private static Set<Element> getPossibleTokens(Group g) {
		Iterator<Element> iter = g.getChildren().iterator();
		boolean includeNext = true;
		Set<Element> result = new LinkedHashSet<Element>();
		while (iter.hasNext() && includeNext) {
			Element next = iter.next();
			result.addAll(getPossibleTokens(next));
			includeNext = XtextGrammarUtil.isOptional(next);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	private static Set<Element> getPossibleTokens(Alternatives alt) {
		Set<Element> result = new LinkedHashSet<Element>();
		List<Element> eles = alt.getAlternatives();
		for (Element element : eles) {
			result.addAll(getPossibleTokens(element));
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	private static Set<Element> getPossibleTokens(Rule rule) {
		if (rule instanceof TypeRule) {
			TypeRule tr = (TypeRule) rule;
			return getPossibleTokens(tr.getContent());
		} else if (rule instanceof StringRule) {
			StringRule sr = (StringRule) rule;
			return getPossibleTokens(sr.getContent());
		} else if (rule instanceof EnumRule) {
			return new LinkedHashSet<Element>(((EnumRule) rule).getLiterals());
		}
		throw new IllegalStateException(rule.toString());
	}

	public static Rule getContainingRule(Element ass) {
		if (ass.eContainer() instanceof Rule) {
			return (Rule) ass.eContainer();
		}
		return getContainingRule((Element) ass.eContainer());
	}

	@SuppressWarnings("unchecked")
	public static Node getNode(Node root, EObject modelElement) {
		if (modelElement.equals(root.getModelElement()))
			return root;
		Iterator allContents = root.eAllContents();
		while (allContents.hasNext()) {
			EObject obj = (EObject) allContents.next();
			if (obj instanceof Node) {
				Node n = (Node) obj;
				if (modelElement.equals(n.getModelElement()))
					return n;
			}
		}
		return null;
	}

	public static boolean isIdentifier(Token token) {
		if (token == null || token.getText() == null
				|| token.getText().length() == 0)
			return false;
		char[] charArray = token.getText().toCharArray();
		for (char c : charArray) {
			if (!Character.isJavaIdentifierPart(c))
				return false;
		}
		return true;
	}

	public static Assignment getContainingAssignment(Element ele) {
		if (ele instanceof AbstractToken) {
			if (ele.eContainer() instanceof Assignment) {
				Assignment ass = (Assignment) ele.eContainer();
				if (ass.getToken() == ele)
					return ass;
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public static List<Node> getAllChildren(Node trace, Filter filter) {
		if (trace == null)
			return null;
		List<Node> result = new ArrayList<Node>();
		if (!filter.isFiltered(trace))
			result.add(trace);
		for (Node node : (List<Node>) trace.getChildren()) {
			if (!filter.isFiltered(node))
				result.add(node);
			result.addAll(getAllChildren(node, filter));
		}
		return result;
	}

	public static List<?> getGrammarElements(List<Node> elements) {
		ArrayList<Object> result = new ArrayList<Object>();
		for (Node traceNode : elements) {
			result.add(traceNode.getGrammarElement());
		}
		return result;
	}

	public interface Filter {
		boolean isFiltered(Node n);
	}
}
