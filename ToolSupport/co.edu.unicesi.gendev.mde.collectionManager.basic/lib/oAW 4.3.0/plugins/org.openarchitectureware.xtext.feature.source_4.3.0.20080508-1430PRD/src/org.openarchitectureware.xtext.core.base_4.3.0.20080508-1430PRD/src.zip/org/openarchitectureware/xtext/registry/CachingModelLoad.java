package org.openarchitectureware.xtext.registry;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.openarchitectureware.emf.EcoreUtil2;

public class CachingModelLoad {
	
	private static Log log = LogFactory.getLog(CachingModelLoad.class);

	private static Map<String, WeakReference<Resource>> resources = new HashMap<String, WeakReference<Resource>>();

	private static URIFactory uriFactory = new URIFactory() {

		public URI createURI(String uri) {
			return EcoreUtil2.getURI(uri);
		}

	};
	
	public static Set<String> getRegisteredURIs() {
		return new HashSet<String>(resources.keySet());
	}

	public static Resource loadResource(String uri) {
		return loadResource(uri, false);
	}

	public static Resource loadResource(String uri, boolean forceReload) {
		Resource res = internalLoad(uri, null, forceReload);
		return res;
	}

	public static Resource loadResource(URI uri, boolean forceReload) {
		Resource res = internalLoad(uri.toString(), null, forceReload);
		return res;
	}

	public static Resource loadResource(URI uri, InputStream in) {
		Resource res = internalLoad(uri.toString(), in, true);
		return res;
	}

	private static synchronized Resource internalLoad(String uri,
			InputStream in, boolean forceReload) {
		WeakReference<Resource> cached = resources.get(uri);
		Resource res = null;
		if (cached != null) {
			res = cached.get();
		}
		if (res == null) {
			URI uri2 = uriFactory.createURI(uri);
			// URI uri2 = URI.createURI(uri);
			if (uri2 == null)
				return null;
			res = new ResourceSetImpl().createResource(uri2);
			try {
				log.debug("parsing..." + uri);
				if (in != null) {
					res.load(in, null);
				} else {
					res.load(null);
				}
			} catch (IOException e) {
				// ignore - null indicates that there is a problem with the uri
				return null;
			}
			resources.put(uri, new WeakReference<Resource>(res));
		} else {
			if (forceReload) {
				try {
					log.debug("reloading..." + uri);
					res.unload();
					if (in != null) {
						res.load(in, null);
					} else {
						res.load(null);
					}
				} catch (IOException e) {
					log.error(e);
					resources.remove(uri);
					return null;
				}
			}
		}
		return res;
	}

	public static List<EObject> load(String uri) {
		Resource loadResource = loadResource(uri);
		if (loadResource == null || loadResource.getContents() == null) {
			log.error("Couldn't resolve resource for URI : '" + uri
					+ "'");
			return Collections.<EObject> emptyList();
		}
		return loadResource.getContents();
	}

	public static void setURIFactory(URIFactory factory) {
		uriFactory = factory;
	}
}
