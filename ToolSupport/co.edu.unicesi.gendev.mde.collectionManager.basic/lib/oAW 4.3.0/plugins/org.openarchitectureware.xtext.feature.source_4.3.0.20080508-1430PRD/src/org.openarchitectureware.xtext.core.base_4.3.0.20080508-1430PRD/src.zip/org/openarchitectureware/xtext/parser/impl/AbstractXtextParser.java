package org.openarchitectureware.xtext.parser.impl;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.m2t.type.emf.EmfRegistryMetaModel;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.ExecutionContextImpl;
import org.openarchitectureware.workflow.util.ResourceLoader;
import org.openarchitectureware.workflow.util.ResourceLoaderFactory;
import org.openarchitectureware.workflow.util.ResourceLoaderImpl;
import org.openarchitectureware.xtend.XtendFacade;
import org.openarchitectureware.xtext.parser.ErrorMsg;
import org.openarchitectureware.xtext.parser.IXtextParser;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public abstract class AbstractXtextParser implements IXtextParser {
	
	protected Node result;

	protected List<ErrorMsg> internalErrors = new ArrayList<ErrorMsg>();
	
	public static ExecutionContext getExecutionContext() {
		ExecutionContextImpl ctx = new ExecutionContextImpl();
		ctx.registerMetaModel(new EmfRegistryMetaModel() {
			@Override
			protected EPackage[] allPackages() {
				return super.allPackages();
			}
		});
		return ctx;
	}

	public Object invokeExtension(String extensionFile, String name, Object... params) {
		if (!getParseErrors().isEmpty())
			return null;
		ResourceLoader cl = ResourceLoaderFactory.createResourceLoader();
		try {
			ResourceLoaderFactory.setCurrentThreadResourceLoader(new ResourceLoaderImpl(getClass().getClassLoader()));
			ExecutionContext ctx = getExecutionContext();
			XtendFacade facade = XtendFacade.create(ctx, extensionFile);
			return facade.call(name, params);
		} catch (Exception e) {
			internalErrors.add(new ErrorMsg("Error during linking phase : "+e.getMessage(),0,1,1));
		} finally {
			ResourceLoaderFactory.setCurrentThreadResourceLoader(cl);
		}
		return null;
	}
	

	private boolean preLinked=false;

	public final void preLinking() {
		if (!preLinked && getParseErrors().isEmpty()) {
			preLinked = true;
			internalPreLink();
		}
	}
	
	protected abstract void internalPreLink();

	private boolean linked=false;

	public final void doLinking() {
		if (!linked) {
			linked = true;
			internalLink();
		}
	}
	
	private boolean postLinked=false;
	public final void postLinking() {
		if (!postLinked && getParseErrors().isEmpty()) {
			postLinked = true;
			internalPostLink();
		}
	}
	protected abstract void internalPostLink();
		
	protected abstract void internalLink();
	
	protected void handleError(Exception e) {
		throw new RuntimeException(e);
	}
}
