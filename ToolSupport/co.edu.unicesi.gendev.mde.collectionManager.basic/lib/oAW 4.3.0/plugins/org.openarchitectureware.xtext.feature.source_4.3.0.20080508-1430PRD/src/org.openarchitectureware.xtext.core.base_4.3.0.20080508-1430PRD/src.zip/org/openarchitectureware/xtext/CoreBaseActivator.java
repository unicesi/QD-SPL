package org.openarchitectureware.xtext;

import java.io.InputStream;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Plugin;
import org.eclipse.core.runtime.Status;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.common.util.WrappedException;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.osgi.framework.BundleContext;

public class CoreBaseActivator extends Plugin {

	public final static String DYNAMIC_PACKAGE_EP = "org.openarchitectureware.xtext.core.base.dynamic_package";
	public static CoreBaseActivator INSTANCE;

	public CoreBaseActivator() {
		INSTANCE = this;
	}

	@Override
	public void start(BundleContext context) throws Exception {
		super.start(context);
		registerEcorePackages();
	}

	private void registerEcorePackages() {
		final IExtensionRegistry registry = Platform.getExtensionRegistry();
		final IExtensionPoint point = registry
				.getExtensionPoint(DYNAMIC_PACKAGE_EP);
		if (point != null) {
			final IExtension[] extensions = point.getExtensions();
			for (int i = 0; i < extensions.length; i++) {
				final IExtension extension = extensions[i];
				final IConfigurationElement[] configs = extension
						.getConfigurationElements();
				for (int j = 0; j < configs.length; j++) {
					final IConfigurationElement element = configs[j];
					register(element);
				}
			}
		}

	}

	static final String TAG_RESOURCE = "resource";
	static final String ATT_URI = "uri";
	static final String ATT_LOCATION = "location";
	private static final String ID = "org.openarchitectureware.xtext.core.base";

	private void register(IConfigurationElement element) {
		if (element.getName().equals(TAG_RESOURCE)) {
			String packageURI = element.getAttribute(ATT_URI);
			if (packageURI != null
					&& element.getAttribute(ATT_LOCATION) != null) {
				DynamicDescriptor dynamicDescriptor = new DynamicDescriptor(
						element, ATT_LOCATION);
				Throwable cause = dynamicDescriptor.isAccessible();
				if (cause == null) {
					EPackage.Registry.INSTANCE.put(packageURI,
							dynamicDescriptor);
				} else {
					String message = "Could'n initialize extension for URI '"
							+ packageURI + "' location '"
							+ dynamicDescriptor.getLocationAttribute() + "'";
					logWarning(cause, message);
				}
			}
		}
	}

	private void logWarning(Throwable cause, String message) {
		getLog().log(new Status(IStatus.WARNING, ID, message, cause));
	}

	public static boolean isEclipseRunning() {
		return INSTANCE != null;
	}

	static class DynamicDescriptor implements EPackage.Descriptor {
		protected static ResourceSet resourceSet = new ResourceSetImpl();
		private IConfigurationElement element;
		private String attributeName;

		public DynamicDescriptor(IConfigurationElement element,
				String attributeName) {
			this.element = element;
			this.attributeName = attributeName;
		}

		public EPackage getEPackage() {
			try {
				String location = getLocationAttribute();
				if (location != null) {
					URI locationURI = createLocationURI(location);
					return (EPackage) resourceSet.getEObject(locationURI, true);
				} else {
					throw new RuntimeException(
							"No location attribute was specified.");
				}
			} catch (Exception e) {
				throw new WrappedException(e);
			}
		}

		private String getLocationAttribute() {
			return element.getAttribute(attributeName);
		}

		private URI createLocationURI(String location) {
			URI locationURI = URI.createURI(location);
			if (locationURI.isRelative()) {
				locationURI = URI.createPlatformPluginURI(element
						.getDeclaringExtension().getContributor().getName()
						+ "/" + location, true);
			}
			if (!locationURI.hasFragment()) {
				locationURI = locationURI.appendFragment("/");
			}
			return locationURI;
		}

		public EFactory getEFactory() {
			return getEPackage().getEFactoryInstance();
		}

		/**
		 * @return null if URI is accessible or cause exception otherwise
		 */
		public Exception isAccessible() {
			try {
				URI createLocationURI = createLocationURI(getLocationAttribute());
				InputStream inputStream = resourceSet.getURIConverter()
						.createInputStream(createLocationURI);
				if (inputStream != null) {
					inputStream.close();
					return null;
				}
				throw new Exception("Could not open stream to URI "
						+ createLocationURI);
			} catch (Exception e) {
				return e;
			}
		}
	}

}
