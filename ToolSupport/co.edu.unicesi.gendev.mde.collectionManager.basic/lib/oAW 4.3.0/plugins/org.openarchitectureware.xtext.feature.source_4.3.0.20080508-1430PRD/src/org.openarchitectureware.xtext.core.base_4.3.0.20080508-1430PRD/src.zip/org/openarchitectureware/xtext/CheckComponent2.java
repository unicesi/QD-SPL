/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/


package org.openarchitectureware.xtext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openarchitectureware.check.CheckComponent;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issue;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.issues.IssuesImpl;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;
import org.openarchitectureware.xtend.XtendFacade;

public class CheckComponent2 extends CheckComponent {
	private Log log = LogFactory.getLog(getClass());

	private String extensionFileForIssueLogging = "org::openarchitectureware::xtext::CheckComponent2";

	private String extensionForIssueLogging = "printContext";

	public void setExtension(String extension) {
		this.extensionForIssueLogging = extension;
	}

	public void setExtensionFile(String extensionFile) {
		this.extensionFileForIssueLogging = extensionFile;
	}

	@Override
	protected void invokeInternal(WorkflowContext ctx, ProgressMonitor monitor,
			Issues issues) {
		Issues issues2 = new IssuesImpl();
		try {
			super.invokeInternal(ctx, monitor, issues2);
		} finally {
			for (Issue issue : issues2.getWarnings()) {
				log.warn(issue.getMessage()
								+ toString(issue.getElement(), ctx));
			}
			for (Issue issue : issues2.getErrors()) {
				log.error(issue.getMessage()
						+ toString(issue.getElement(), ctx));
			}
		}
	}

	private String toString(Object element, WorkflowContext ctx) {
		try {
			XtendFacade f = XtendFacade.create(getExecutionContext(ctx),
					extensionFileForIssueLogging);
			return (String) f.call(extensionForIssueLogging,
					new Object[] { element });
		} catch (Exception e) {
			return "Error evaluating '" + extensionFileForIssueLogging + "::"
					+ extensionForIssueLogging + "' on '" + element + " : "
					+ e.getClass().getName() + " - " + e.getMessage();
		}
	}
}
