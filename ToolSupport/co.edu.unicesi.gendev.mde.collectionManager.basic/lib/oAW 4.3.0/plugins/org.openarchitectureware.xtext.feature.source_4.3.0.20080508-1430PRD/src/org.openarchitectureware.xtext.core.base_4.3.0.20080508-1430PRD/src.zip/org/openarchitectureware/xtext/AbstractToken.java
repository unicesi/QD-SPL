/**
 * <copyright>
 * </copyright>
 *
 * $Id: AbstractToken.java,v 1.1.2.1 2008/02/08 11:45:33 berndkolb Exp $
 */
package org.openarchitectureware.xtext;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Token</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getAbstractToken()
 * @model
 * @generated
 */
public interface AbstractToken extends Element {
} // AbstractToken
