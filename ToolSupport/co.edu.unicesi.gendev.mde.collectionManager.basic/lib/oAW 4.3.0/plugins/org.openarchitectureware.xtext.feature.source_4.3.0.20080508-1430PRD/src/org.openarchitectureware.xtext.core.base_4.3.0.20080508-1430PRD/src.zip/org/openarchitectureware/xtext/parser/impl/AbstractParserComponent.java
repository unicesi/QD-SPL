/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.parser.impl;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.m2t.type.emf.EmfRegistryMetaModel;
import org.openarchitectureware.emf.EcoreUtil2;
import org.openarchitectureware.expression.AbstractExpressionsUsingWorkflowComponent;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.WorkflowInterruptedException;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;
import org.openarchitectureware.xtext.parser.ErrorMsg;
import org.openarchitectureware.xtext.resource.IXtextResource;

public abstract class AbstractParserComponent extends
		AbstractExpressionsUsingWorkflowComponent {
	
	public AbstractParserComponent() {
		addMetaModel(new EmfRegistryMetaModel());
	}

	
	@Override
	protected void invokeInternal(WorkflowContext ctx, ProgressMonitor monitor,
			Issues issues) {
		try {
			URI uri = EcoreUtil2.getURI(modelFile);
			ResourceSet rs = new ResourceSetImpl();
			Resource r = rs.createResource(uri);
			r.load(null);
			if (!(r instanceof IXtextResource)) {
				throw new WorkflowInterruptedException(
						"Resource is not an instance of 'IXtextResource'.");
			}
			for (ErrorMsg err : ((IXtextResource) r).getParser()
					.getParseErrors()) {
				issues.addError(err.getMsg() + " on line " + err.getLine()
						+ " in " + modelFile);
			}
			if (!r.getContents().isEmpty())
				ctx.set(outputSlot, r.getContents().get(0));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	protected void checkConfigurationInternal(Issues issues) {
		URI uri = EcoreUtil2.getURI(modelFile);
		if (!getFileExtension().equals(uri.fileExtension()))
			issues
					.addError("The uri to the model file must have the extension '"
							+ getFileExtension()
							+ "' but it has '"
							+ uri.fileExtension() + "' (uri was '" + uri + "')");
	}

	protected abstract String getFileExtension();

	protected String modelFile = null;

	public void setModelFile(String modelFile) {
		this.modelFile = modelFile;
	}

	private String outputSlot = WorkflowContext.DEFAULT_SLOT;

	public void setOutputSlot(String outputSlot) {
		this.outputSlot = outputSlot;
	};

}
