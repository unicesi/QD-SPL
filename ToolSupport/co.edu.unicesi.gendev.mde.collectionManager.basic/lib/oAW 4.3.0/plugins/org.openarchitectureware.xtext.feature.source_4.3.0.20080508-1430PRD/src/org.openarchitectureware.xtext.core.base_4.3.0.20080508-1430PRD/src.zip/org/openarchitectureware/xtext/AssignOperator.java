/**
 * <copyright>
 * </copyright>
 *
 * $Id: AssignOperator.java,v 1.1.2.1 2008/02/08 11:45:33 berndkolb Exp $
 */
package org.openarchitectureware.xtext;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Assign Operator</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.XtextPackage#getAssignOperator()
 * @model
 * @generated
 */
public final class AssignOperator extends AbstractEnumerator {
	/**
	 * The '<em><b>NULL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>NULL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NULL_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int NULL = 1;

	/**
	 * The '<em><b>ASSIGN</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ASSIGN</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ASSIGN_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int ASSIGN = 1;

	/**
	 * The '<em><b>BOOLASSIGN</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>BOOLASSIGN</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #BOOLASSIGN_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int BOOLASSIGN = 2;

	/**
	 * The '<em><b>ADD</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ADD</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ADD_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int ADD = 3;

	/**
	 * The '<em><b>NULL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NULL
	 * @generated
	 * @ordered
	 */
	public static final AssignOperator NULL_LITERAL = new AssignOperator(NULL, "NULL", "NULL");

	/**
	 * The '<em><b>ASSIGN</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ASSIGN
	 * @generated
	 * @ordered
	 */
	public static final AssignOperator ASSIGN_LITERAL = new AssignOperator(ASSIGN, "ASSIGN", "ASSIGN");

	/**
	 * The '<em><b>BOOLASSIGN</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BOOLASSIGN
	 * @generated
	 * @ordered
	 */
	public static final AssignOperator BOOLASSIGN_LITERAL = new AssignOperator(BOOLASSIGN, "BOOLASSIGN", "BOOLASSIGN");

	/**
	 * The '<em><b>ADD</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ADD
	 * @generated
	 * @ordered
	 */
	public static final AssignOperator ADD_LITERAL = new AssignOperator(ADD, "ADD", "ADD");

	/**
	 * An array of all the '<em><b>Assign Operator</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final AssignOperator[] VALUES_ARRAY =
		new AssignOperator[] {
			NULL_LITERAL,
			ASSIGN_LITERAL,
			BOOLASSIGN_LITERAL,
			ADD_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>Assign Operator</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Assign Operator</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static AssignOperator get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			AssignOperator result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Assign Operator</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static AssignOperator getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			AssignOperator result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Assign Operator</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static AssignOperator get(int value) {
		switch (value) {
			case NULL: return NULL_LITERAL;
			case BOOLASSIGN: return BOOLASSIGN_LITERAL;
			case ADD: return ADD_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private AssignOperator(int value, String name, String literal) {
		super(value, name, literal);
	}

} //AssignOperator
