package org.openarchitectureware.xtext.parser;

import java.io.InputStream;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.openarchitectureware.xtext.Element;
import org.openarchitectureware.xtext.parser.model.ToStringUtil;
import org.openarchitectureware.xtext.parser.model.XtextGrammarUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public class XtextParser extends GenParser {

	private Log log = LogFactory.getLog(getClass());

	public XtextParser(InputStream in) {
		super(in);
	}

	@Override
	protected void internalPreLink() {
		normalize(getRootNode());
		super.internalPreLink();
	}

	@SuppressWarnings("unchecked")
	private void normalize(Node n) {
		EObject m = n.getModelElement();
		if (m != null) {
			EObject newOne = replace(m);
			if (newOne != m) {
				n.setModelElement(null);
				EObject container = m.eContainer();
				EStructuralFeature containingFeature = m.eContainingFeature();
				if (containingFeature != null) {
					log.debug("Replacing " + m + ToStringUtil.toString(m)
							+ " with " + ToStringUtil.toString(newOne));
					if (containingFeature.getUpperBound() == 1) {
						container.eSet(containingFeature, newOne);
					} else {
						List<Object> get = (List<Object>) container
								.eGet(containingFeature);
						int indexOf = get.indexOf(m);
						get.add(indexOf, newOne);
						get.remove(m);
					}
				}
			}
			for (Node child : (List<Node>) n.getChildren()) {
				normalize(child);
			}
		}
	}

	private EObject replace(EObject m) {
		if (m instanceof Element) {
			return XtextGrammarUtil.normalize(m);
		}
		return m;
	}

	@Override
	protected void internalPostLink() {
		invokeExtension("org::openarchitectureware::xtext::parser::Imports",
				"handleImports", getRootNode().getModelElement());
	}

	@Override
	protected void internalLink() {
		// DO NOTHING!
	}
}
