/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext;

import org.openarchitectureware.xtext.AbstractXtextEditorPlugin;
import org.openarchitectureware.xtext.LanguageUtilities;
import org.osgi.framework.BundleContext;

public class XTextEditorPlugin extends AbstractXtextEditorPlugin {
    private static XTextEditorPlugin plugin;

    public static XTextEditorPlugin getDefault() {
        return plugin;
    }

    private XTextUtilities utilities = new XTextUtilities();

    @Override
    public LanguageUtilities getUtilities() {
        return utilities;
    }

    public XTextEditorPlugin() {
        plugin = this;
    }

    @Override
    public void stop(BundleContext context) throws Exception {
        super.stop(context);
        plugin = null;
    }
}
