/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.xpand2.core.internal;

import java.util.Set;

import org.eclipse.core.resources.IStorage;
import org.eclipse.jdt.core.IJavaProject;
import org.openarchitectureware.core.AbstractOawResource;
import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.Resource;
import org.openarchitectureware.xpand2.XpandEditorPlugin;
import org.openarchitectureware.xpand2.XpandExecutionContext;
import org.openarchitectureware.xpand2.core.IXpandResource;
import org.openarchitectureware.xpand2.core.internal.builder.XpandResourceParser;
import org.openarchitectureware.xpand2.model.XpandAdvice;
import org.openarchitectureware.xpand2.model.XpandDefinition;
import org.openarchitectureware.xpand2.model.XpandResource;

public class XpandResourceImpl extends AbstractOawResource implements IXpandResource {

	private XpandResourceParser parser;

	public XpandResourceImpl(final XpandResource tpl, final IStorage source, XpandResourceParser parser) {
		super(source);
		setOawResource(tpl);
		this.parser = parser;
	}

	private XpandResource resource() {
		return (XpandResource) getOawResource();
	}

	public void analyze(final ExecutionContext ctx, final Set<AnalysationIssue> issues) {
		try {
			resource().analyze((XpandExecutionContext) ctx, issues);
		} catch (Exception e) {
			// ignore
		}
	}

	public void analyze(final XpandExecutionContext ctx, final Set<AnalysationIssue> issues) {
		try {
			resource().analyze(ctx, issues);
		} catch (Exception e) {
			// ignore
		}
	}

	public XpandDefinition[] getDefinitions() {
		return resource().getDefinitions();
	}

	public XpandDefinition[] getDefinitionsByName(final String name) {
		return resource().getDefinitionsByName(name);
	}

	protected ExecutionContext getExecutionContext(final IJavaProject p) {
		return XpandEditorPlugin.getExecutionContext(p);
	}

	public XpandAdvice[] getAdvices() {
		return resource().getAdvices();
	}

	public String getFileExtension() {
		return parser.getFileExtension();
	}

	public boolean internalRefresh() {
		Resource r = parser.parse(getUnderlyingStorage(), getFullyQualifiedName());
		if (r == null)
			return false;
		setOawResource(r);
		return true;
	}

}
