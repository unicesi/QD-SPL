package org.openarchitectureware.workflow.editors.outline;

import java.net.URL;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.swt.graphics.Image;
import org.openarchitectureware.workflow.Activator;
import org.openarchitectureware.workflow.editors.parser.XMLElement;
import org.osgi.framework.Bundle;

public class OutlineLabelProvider implements ILabelProvider {

	private static final String XML_TAG = "XML_TAG";
	private static final String PROPERTY = "PROPERTY";
	private static final String COMPONENT = "COMPONENT";
	private static final String ASSIGNMENT = "ASSIGNMENT";
	private static ImageRegistry imageRegistry;

	public OutlineLabelProvider() {
		super();
		initializeImages();
	}

	private void initializeImages() {
		imageRegistry = new ImageRegistry();
		declareRegistryImage(XML_TAG, "icons/xmltag.gif");
		declareRegistryImage(PROPERTY, "icons/property.gif");
		declareRegistryImage(COMPONENT, "icons/component.gif");
		declareRegistryImage(ASSIGNMENT, "icons/assignment.gif");
	}

	/**
	 * Declare an Image in the registry table.
	 * 
	 * @param key
	 *            The key to use when registering the image
	 * @param path
	 *            The path where the image can be found. This path is relative
	 *            to where this plugin class is found (i.e. typically the
	 *            packages directory)
	 */
	private final static void declareRegistryImage(String key, String path) {
		ImageDescriptor desc = ImageDescriptor.getMissingImageDescriptor();
		Bundle bundle = Platform.getBundle(Activator.PLUGIN_ID);
		URL url = null;
		if (bundle != null) {
			url = FileLocator.find(bundle, new Path(path), null);
			desc = ImageDescriptor.createFromURL(url);
		}
		imageRegistry.put(key, desc);
	}

	public Image getImage(Object element) {
		if (element instanceof XMLElement) {
			XMLElement node = (XMLElement) element;
			String name = node.getName();
			if ("property".equalsIgnoreCase(name)) {
				return imageRegistry.get(PROPERTY);
			} else if ("component".equalsIgnoreCase(name)) {
				return imageRegistry.get(COMPONENT);
			}
		}
		return imageRegistry.get(XML_TAG);
	}

	public String getText(Object element) {
		if (element instanceof XMLElement) {
			XMLElement node = (XMLElement) element;
			String textToShow = "";
			String name = node.getName();

			if ("component".equalsIgnoreCase(name)) {
				String className = node.getAttributeValue("class");
				textToShow = className;
			} else if ("property".equalsIgnoreCase(name)) {
				textToShow = "";
			} else {
				textToShow = name;
			}

			String nameAttribute = node.getAttributeValue("name");
			if (nameAttribute != null) {
				textToShow += " " + nameAttribute;
			}
			String valueAttribute = node.getAttributeValue("value");
			if (valueAttribute != null) {
				textToShow += " = " + valueAttribute;
			}

			return textToShow;
		}
		return null;
	}

	public void addListener(ILabelProviderListener listener) {
	}

	public void dispose() {
	}

	public boolean isLabelProperty(Object element, String property) {
		return false;
	}

	public void removeListener(ILabelProviderListener listener) {
	}

}