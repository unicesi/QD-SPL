/*******************************************************************************
 * Copyright (c) 2005 - 2007 committers of openArchitectureWare and others. All
 * rights reserved. This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License v1.0 which
 * accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: committers of openArchitectureWare - initial API and
 * implementation
 ******************************************************************************/
package org.openarchitectureware.core.search;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.openarchitectureware.OawPlugin;
import org.openarchitectureware.core.IOawProject;
import org.openarchitectureware.core.IOawResource;
import org.openarchitectureware.expression.ast.Identifier;
import org.openarchitectureware.expression.ast.OperationCall;
import org.openarchitectureware.expression.ast.SyntaxElement;
import org.openarchitectureware.internal.OawLog;
import org.openarchitectureware.xpand2.ast.Definition;
import org.openarchitectureware.xpand2.ast.ExpandStatement;
import org.openarchitectureware.xpand2.ast.Template;
import org.openarchitectureware.xpand2.model.XpandDefinition;
import org.openarchitectureware.xtend.ast.AbstractExtension;
import org.openarchitectureware.xtend.ast.Extension;
import org.openarchitectureware.xtend.ast.ExtensionFile;

/**
 * Search engine for oAW.
 * 
 * @author Sven Efftinge (http://www.efftinge.de)
 * @author Peter Friese
 */
public class OawSearchEngine {

	public static List<Definition> findAllDefines(IOawProject project) {
		List<Definition> matches = new ArrayList<Definition>();
		IOawResource[] resources = project.getRegisteredResources();
		for (IOawResource res : resources) {

			if (res.getOawResource() instanceof Template) {
				Template tpl = (Template) res.getOawResource();
				for (XpandDefinition xdef : tpl.getDefinitions()) {
					if (xdef instanceof Definition) {
						Definition def = (Definition) xdef;
						matches.add(def);
					}
				}
			}
		}
		return matches;
	}

	public static List<SearchMatch> findAllOccurrences(IOawProject project, String identifier) {
		List<SearchMatch> matches = new ArrayList<SearchMatch>();
		IOawResource[] resources = project.getRegisteredResources();
		for (IOawResource res : resources) {

			if (res.getOawResource() instanceof Template) {
				Template tpl = (Template) res.getOawResource();
				for (XpandDefinition xdef : tpl.getDefinitions()) {
					if (xdef instanceof Definition) {
						Definition def = (Definition) xdef;
						if (def.getName().equals(identifier)) {
							int startOfDefnitionName = def.getDefName().getStart() - 1;
							int lengthOfDefinitionName = def.getDefName().getEnd() - def.getDefName().getStart();
							matches.add(new SearchMatch(startOfDefnitionName, lengthOfDefinitionName, res
									.getUnderlyingStorage()));
						}
					}
				}
				;
			}

			// there is no visitor api or something similar so far, so we have
			// to use a reflective mechanism...
			Set<ExpandStatement> ops = findRec(res.getOawResource(), ExpandStatement.class, new HashSet<Object>());
			for (ExpandStatement expr : ops) {
				Identifier definition = expr.getDefinition();
				String definitionFQN = definition.getValue();

				int lastIndexOf = definitionFQN.lastIndexOf(identifier);
				if (lastIndexOf > -1) {
					int startOfDefinition = definition.getStart() + lastIndexOf - 1;
					int lengthOfDefinition = identifier.length();
					matches.add(new SearchMatch(startOfDefinition, lengthOfDefinition, res.getUnderlyingStorage()));

				}

			}

		}
		for (IProject p : project.getProject().getProject().getReferencingProjects()) {
			IOawProject oawp = OawPlugin.getOawModelManager().findProject(p);
			if (oawp != null) {
				matches.addAll(findAllOccurrences(oawp, identifier));
			}
		}
		return sort(matches);
	}

	/**
	 * finds all operation invocations for the given identifier. Ignores
	 * parameters and types as well as resource references (i.e. imports)
	 */
	public static List<SearchMatch> findReferences(IOawProject project, String identifier) {
		List<SearchMatch> matches = new ArrayList<SearchMatch>();
		IOawResource[] resources = project.getRegisteredResources();
		for (IOawResource res : resources) {
			// there is no visitor api or something similar so far, so we have
			// to use a reflective mechanism...
			Set<OperationCall> ops = findRec(res.getOawResource(), OperationCall.class, new HashSet<Object>());
			for (OperationCall expr : ops) {
				if (expr.getName().getValue().equals(identifier)) {
					matches.add(new SearchMatch(expr.getName().getStart(), expr.getName().getEnd() - expr.getStart()
							- 1, res.getUnderlyingStorage()));
				}
			}
		}
		for (IProject p : project.getProject().getProject().getReferencingProjects()) {
			IOawProject oawp = OawPlugin.getOawModelManager().findProject(p);
			if (oawp != null) {
				matches.addAll(findReferences(oawp, identifier));
			}
		}
		return sort(matches);
	}

	/**
	 * finds all extension declarations for the given identifier. Ignores
	 * parameters and types as well as resource references (i.e. imports)
	 */
	public static List<SearchMatch> findDeclarations(IOawProject project, String identifier) {
		List<SearchMatch> matches = new ArrayList<SearchMatch>();
		IOawResource[] resources = project.getRegisteredResources();
		for (IOawResource res : resources) {
			if (res.getOawResource() instanceof ExtensionFile) {
				ExtensionFile ef = (ExtensionFile) res.getOawResource();
				for (Extension ext : ef.getExtensions()) {
					if (ext instanceof AbstractExtension) {
						AbstractExtension ae = (AbstractExtension) ext;
						if (ext.getName().equals(identifier)) {
							Identifier id = ae.getNameIdentifier();
							matches.add(new SearchMatch(id.getStart(), id.getEnd() - id.getStart() + 1 /*
																										 * sorry
																										 * for
																										 * the
																										 * "+1"-hack
																										 */, res.getUnderlyingStorage()));
						}
					}
				}
				;
			}
			if (res.getOawResource() instanceof Template) {
				Template tpl = (Template) res.getOawResource();
				for (XpandDefinition xdef : tpl.getDefinitions()) {
					if (xdef instanceof Definition) {
						Definition def = (Definition) xdef;
						if (def.getName().equals(identifier)) {
							matches.add(new SearchMatch(def.getDefName().getStart(), def.getDefName().getEnd()
									- def.getDefName().getStart(), res.getUnderlyingStorage()));
						}
					}
				}
				;
			}
		}
		try {
			for (IProject p : project.getProject().getProject().getReferencedProjects()) {
				IOawProject oawp = OawPlugin.getOawModelManager().findProject(p);
				if (oawp != null) {
					matches.addAll(findDeclarations(oawp, identifier));
				}
			}
		} catch (CoreException e) {
			OawLog.logError(e);
		}
		return sort(matches);
	}

	private static List<SearchMatch> sort(List<SearchMatch> searchmatches) {
		Collections.sort(searchmatches, new Comparator<SearchMatch>() {

			public int compare(SearchMatch o1, SearchMatch o2) {
				if (o1.getFile() == null) {
					return -1;
				}
				if (o2.getFile() == null) {
					return 1;
				}
				int fileCompare = o1.getFile().getName().compareTo(o2.getFile().getName());
				if (fileCompare == 0) {
					return ((Integer) o1.getOffSet()).compareTo(o2.getOffSet());
				}
				return fileCompare;
			}
		});
		return searchmatches;
	}

	@SuppressWarnings("unchecked")
	private static <T extends SyntaxElement> Set<T> findRec(Object res, Class<T> clazz, Set<Object> visitedNodes) {
		if (visitedNodes.contains(res)) {
			return Collections.emptySet();
		}
		visitedNodes.add(res);
		Set<T> result = new HashSet<T>();
		if (clazz.isInstance(res)) {
			result.add((T) res);
		}

		Class instanceClass = res.getClass();
		Method[] methods = instanceClass.getMethods();
		for (Method method : methods) {
			int mod = method.getModifiers();
			if (Modifier.isPublic(mod) && !Modifier.isStatic(mod) && method.getName().startsWith("get")
					&& method.getParameterTypes().length == 0) {
				Class<?> pType = method.getReturnType();
				// if it's a SyntaxElement navigate it
				if (Collection.class.isAssignableFrom(pType) || SyntaxElement.class.isAssignableFrom(pType)) {
					Object invRes;
					try {
						invRes = method.invoke(res, new Object[] {});
						if (invRes instanceof Collection) {
							for (Object o : (Collection<?>) invRes) {
								result.addAll(findRec(o, clazz, visitedNodes));
							}
						} else if (invRes != null) {
							result.addAll(findRec(invRes, clazz, visitedNodes));
						}
					} catch (Exception e) {
						OawLog.logError(e);
					}
				}
			}
		}
		return result;
	}
}
