/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.core;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IStorage;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.openarchitectureware.OawPlugin;
import org.openarchitectureware.core.builder.OawMarkerManager;
import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.Resource;

public abstract class AbstractOawResource implements IOawResource {
	private class StubResource implements Resource {
		private String fullyQualifiedName;

		public String getFullyQualifiedName() {
			return fullyQualifiedName;
		}

		public String[] getImportedExtensions() {
			return new String[0];
		}

		public String[] getImportedNamespaces() {
			return new String[0];
		}

		public void setFullyQualifiedName(String fqn) {
			this.fullyQualifiedName = fqn;
		}

	}

	private IStorage underlyingFile;

	private Resource resource;

	protected AbstractOawResource(final IStorage res) {
		underlyingFile = res;
	}

	public void setOawResource(final Resource res) {
		resource = res;
	}

	public Resource getOawResource() {
		if (resource == null)
			resource = new StubResource();
		return resource;
	}

	public IStorage getUnderlyingStorage() {
		return underlyingFile;
	}

	public String getFullyQualifiedName() {
		return getOawResource().getFullyQualifiedName();
	}

	public String[] getImportedNamespaces() {
		return getOawResource().getImportedNamespaces();
	}

	public void setFullyQualifiedName(final String fqn) {
		getOawResource().setFullyQualifiedName(fqn);
	}

	public String[] getImportedExtensions() {
		return getOawResource().getImportedExtensions();
	}

	private boolean hasSemanticErrors = false;

	public final void analyze() {
		if (getUnderlyingStorage() instanceof IFile) {
			IFile f = (IFile) getUnderlyingStorage();
			final IJavaProject p = JavaCore.create(f.getProject());
			final ExecutionContext ctx = getExecutionContext(p);
			final Set<AnalysationIssue> issues = new HashSet<AnalysationIssue>();
			analyze(ctx, issues);
			if (hasSemanticErrors) {
				OawMarkerManager.deleteMarkers(f);
			}
			hasSemanticErrors = !issues.isEmpty();
			for (final Iterator<AnalysationIssue> iterator = issues.iterator(); iterator.hasNext();) {
				OawMarkerManager.addMarker(f, iterator.next());
			}
		}
	}

	protected ExecutionContext getExecutionContext(final IJavaProject p) {
		return OawPlugin.getExecutionContext(p);
	}

	protected abstract void analyze(ExecutionContext ctx, Set<AnalysationIssue> issues);

	public final boolean refresh() {
		return internalRefresh();
	}

	protected abstract boolean internalRefresh();

}
