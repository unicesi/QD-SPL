/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.core.internal;

import java.util.Iterator;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IStorage;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.openarchitectureware.core.IOawModelManager;
import org.openarchitectureware.core.IOawProject;
import org.openarchitectureware.core.IOawResource;
import org.openarchitectureware.core.builder.OawNature;
import org.openarchitectureware.internal.OawLog;
import org.openarchitectureware.workflow.util.Cache;

public class OawModelManager implements IOawModelManager {

    public OawModelManager() {

    }

    public final Cache<IJavaProject, OawProject> projects = new Cache<IJavaProject, OawProject>() {
        @Override
        protected OawProject createNew(IJavaProject ele) {
            return new OawProject(ele);
        }
    };

    /*
     * (non-Javadoc)
     * 
     * @see org.openarchitectureware.core.IXpandModelManager#findProject(org.eclipse.core.runtime.IPath)
     */
    public IOawProject findProject(final IPath path) {
        return findProject(ResourcesPlugin.getWorkspace().getRoot().findMember(path));
    }

    public IOawProject findProject(final IResource res) {
        if (res == null)
            return null;
        final IJavaProject ele = JavaCore.create(res.getProject());
        try {
            if (ele != null && res.getProject().isAccessible() && res.getProject().isNatureEnabled(OawNature.NATURE_ID))
                return (IOawProject) projects.get(ele);
        } catch (final CoreException e) {
            OawLog.logError(e);
        }
        return null;
    }

    public void analyze(final IProgressMonitor monitor) {
        monitor.beginTask("Analyzing oAW4 projects...", computeAmoutOfWork());
        for (final Iterator<?> iter = projects.getValues().iterator(); iter.hasNext();) {
            if (monitor.isCanceled())
                return;
            ((IOawProject) iter.next()).analyze(monitor);
        }
        monitor.done();
    }

    /**
     * Computes the amount of work that has to be done during a build.
     * @return the number of resources registered within all oAW projects.
     */
    private int computeAmoutOfWork() {
        int i = 0;
        for (final Iterator<?> iter = projects.getValues().iterator(); iter.hasNext();) {
            final IOawProject element = (IOawProject) iter.next();
            i += element.getRegisteredResources().length;
        }
        return i;
    }

    /**
     * Tries to locate an oAW resource by its underlying file.
     * @param underlying IStorage
     */
    public IOawResource findOawResource(IStorage file) {
    	// it can be that the resource is located within a jar, than scan the projects for the resource
    	if (!(file instanceof IFile)) {
    		for (Iterator<?> it=projects.getValues().iterator(); it.hasNext(); ) {
    			IOawProject p = (IOawProject) it.next();
    			IOawResource res = p.findOawResource(file);
    			if (res!=null) {
    				return res;
    			}
    		}
    	} else {
	        final IOawProject project = findProject((IFile)file);
	        if (project != null) {
	            return project.findOawResource(file);
	        }
        }
        return null;
    }

	public IOawResource findOawResource(String oawNamespace, String extension) {
		for (IOawProject p : projects.getValues()) {
			IOawResource res = p.findOawResource(oawNamespace, extension);
			if (res!=null)
				return res;
		}
		return null;
	}

}
