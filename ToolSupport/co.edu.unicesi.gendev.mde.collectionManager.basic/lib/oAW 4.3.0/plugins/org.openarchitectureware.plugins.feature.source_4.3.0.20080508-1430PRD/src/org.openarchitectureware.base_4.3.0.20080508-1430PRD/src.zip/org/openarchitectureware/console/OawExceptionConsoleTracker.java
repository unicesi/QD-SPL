/*******************************************************************************
 * Copyright (c) 2005 - 2007 committers of openArchitectureWare and others. All
 * rights reserved. This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License v1.0 which
 * accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: committers of openArchitectureWare - initial API and
 * implementation
 ******************************************************************************/
package org.openarchitectureware.console;

import java.util.regex.Matcher;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.ui.console.IHyperlink;
import org.eclipse.ui.console.IPatternMatchListenerDelegate;
import org.eclipse.ui.console.PatternMatchEvent;
import org.eclipse.ui.console.TextConsole;
import org.openarchitectureware.OawPlugin;
import org.openarchitectureware.core.IOawResource;
import org.openarchitectureware.expression.EvaluationException;

/**
 * OawExceptionConsoleTracker tracks down exception links in oAW console output.
 * 
 * @author Sven Efftinge (http://www.efftinge.de)
 */
public class OawExceptionConsoleTracker implements IPatternMatchListenerDelegate {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.console.IPatternMatchListenerDelegate#matchFound(org.eclipse.ui.console.PatternMatchEvent)
	 */
	public void matchFound(PatternMatchEvent event) {
		try {
			int offset = event.getOffset();
			int length = event.getLength();
			TextConsole console = getConsole();
			String oawFileId = console.getDocument().get(offset, length);
			// Don't know why the framework returns wrong locations...
			Matcher m = EvaluationException.P.matcher(oawFileId);
			if (m.find()) {
				offset = offset + m.start();
				length = m.end() - m.start();
				IOawResource res = OawPlugin.getOawModelManager().findOawResource(m.group(1), m.group(2));
				if (res != null) {
					IHyperlink link = new OawConsoleHyperLink(res, Integer.valueOf(m.group(3)), Integer.valueOf(m
							.group(4)));
					getConsole().addHyperlink(link, offset, length - 1);
				}
			}
		} catch (BadLocationException e) {
		} catch (RuntimeException e) {
		}
	}

	/**
	 * The console associated with this line tracker
	 */
	private TextConsole fConsole;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.console.IPatternMatchListenerDelegate#connect(org.eclipse.ui.console.IConsole)
	 */
	public void connect(TextConsole console) {
		fConsole = console;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.console.IPatternMatchListenerDelegate#disconnect()
	 */
	public void disconnect() {
		fConsole = null;
	}

	protected TextConsole getConsole() {
		return fConsole;
	}

}