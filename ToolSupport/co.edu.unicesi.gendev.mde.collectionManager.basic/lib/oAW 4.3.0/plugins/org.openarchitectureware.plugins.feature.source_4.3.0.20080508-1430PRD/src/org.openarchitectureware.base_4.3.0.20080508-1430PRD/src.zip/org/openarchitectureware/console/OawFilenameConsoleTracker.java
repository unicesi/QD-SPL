/*******************************************************************************
 * Copyright (c) 2005 - 2007 committers of openArchitectureWare and others. All
 * rights reserved. This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License v1.0 which
 * accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: committers of openArchitectureWare - initial API and
 * implementation
 ******************************************************************************/
package org.openarchitectureware.console;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.ui.console.IHyperlink;
import org.eclipse.ui.console.IPatternMatchListenerDelegate;
import org.eclipse.ui.console.PatternMatchEvent;
import org.eclipse.ui.console.TextConsole;

/**
 * OawFilenameConsoleTracker tracks down filename in console output.
 * 
 * @author Peter Friese
 */
public class OawFilenameConsoleTracker implements IPatternMatchListenerDelegate {

	Pattern fileNamePattern = Pattern.compile("\\S*[/\\.]\\S*(:\\d+)*");

	Pattern lineNumber = Pattern.compile(":(\\d+)");

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.console.IPatternMatchListenerDelegate#matchFound(org.eclipse.ui.console.PatternMatchEvent)
	 */
	public void matchFound(PatternMatchEvent event) {
		try {
			int offset = event.getOffset();
			int length = event.getLength();
			TextConsole console = getConsole();
			String oawFileId = console.getDocument().get(offset, length);
			// Don't know why the framework returns wrong locations...
			Matcher m = fileNamePattern.matcher(oawFileId);
			if (m.find()) {

				String fileName = m.group();
				String linenumberString = "";
				int linenumber = -1;

				Matcher ml = lineNumber.matcher(m.group());
				if (ml.find()) {
					linenumberString = ml.group(1);
					linenumber = Integer.parseInt(linenumberString);
					fileName = ml.replaceAll("");
				} else {
					linenumber = 1;
				}

				offset = offset + m.start();
				length = m.end() - m.start();

				IPath location = ResourcesPlugin.getWorkspace().getRoot().getLocation();

				IPath path = new Path(fileName);
				int matchingFirstSegments = path.matchingFirstSegments(location);
				IPath removeFirstSegments = path.removeFirstSegments(matchingFirstSegments);

				IResource res = ResourcesPlugin.getWorkspace().getRoot().findMember(removeFirstSegments);
				if (res != null) {
					IHyperlink link = new OawConsoleHyperLink(res, linenumber);
					getConsole().addHyperlink(link, offset, length);
				}
			}
		} catch (BadLocationException e) {
		} catch (RuntimeException e) {
		}
	}

	/**
	 * The console associated with this line tracker
	 */
	private TextConsole fConsole;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.console.IPatternMatchListenerDelegate#connect(org.eclipse.ui.console.IConsole)
	 */
	public void connect(TextConsole console) {
		fConsole = console;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.console.IPatternMatchListenerDelegate#disconnect()
	 */
	public void disconnect() {
		fConsole = null;
	}

	protected TextConsole getConsole() {
		return fConsole;
	}

}