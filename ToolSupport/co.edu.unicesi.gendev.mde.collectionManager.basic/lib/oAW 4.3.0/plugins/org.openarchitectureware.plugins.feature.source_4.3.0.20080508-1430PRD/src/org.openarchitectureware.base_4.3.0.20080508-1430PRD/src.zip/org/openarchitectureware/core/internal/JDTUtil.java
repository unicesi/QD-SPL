package org.openarchitectureware.core.internal;

import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IStorage;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.debug.core.sourcelookup.containers.ZipEntryStorage;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.internal.core.JarPackageFragmentRoot;
import org.openarchitectureware.internal.OawLog;

public class JDTUtil {
	
	private static final Pattern patternNamespace = Pattern.compile("::");
	private static final Pattern patternSlash = Pattern.compile("/");

	/**
	 * find the path for the oaw name space and extension
	 * 
	 * @param project -
	 *            the javaproject
	 * @param oawns -
	 *            oaw name space (i.e. 'my::xtend::File')
	 * @param ext -
	 *            file extension (i.e. 'ext')
	 * @return
	 */
	public static IStorage findStorage(IJavaProject project, OawResourceID id, boolean searchJars) {
		IPath p = path(id);
		try {
			IPackageFragmentRoot[] roots = project.getPackageFragmentRoots();
			for (int i = 0; i < roots.length; i++) {
				IPackageFragmentRoot root = roots[i];
				if (!root.isArchive()) {
					IResource r = project.getProject().findMember(
							root.getUnderlyingResource()
									.getProjectRelativePath().append(p));
					if (r instanceof IFile)
						return (IFile) r;
				} else if (searchJars) {
					IStorage storage = loadFromJar(id, root);
					if (storage!=null)
						return storage;
				}
			}
		} catch (JavaModelException e) {
			OawLog.logInfo(e);
		}
		return null;
	}

	@SuppressWarnings("restriction")
	public static IStorage loadFromJar(OawResourceID id, IPackageFragmentRoot root) throws JavaModelException {
		if (root instanceof JarPackageFragmentRoot) {
			JarPackageFragmentRoot jar = (JarPackageFragmentRoot) root;
			ZipFile zipFile;
			try {
				zipFile = jar.getJar();
			} catch (CoreException e) {
				OawLog.logError(e);
				return null;
			}
			ZipEntry entry = zipFile.getEntry(id.toFileName());
			if (entry!=null && zipFile!=null) {
				return new ZipEntryStorage(zipFile,entry);
			}
		}
		return null;
	}

	public static OawResourceID findOawResourceID(IJavaProject project,
			IStorage file) {
		if (file == null)
			return null;
		try {
			IPackageFragmentRoot[] roots = project.getPackageFragmentRoots();
			for (int i = 0; i < roots.length; i++) {
				IPackageFragmentRoot root = roots[i];
				if (root.getPath().isPrefixOf(file.getFullPath())) {
					IPath shortOne = file.getFullPath().removeFirstSegments(
							root.getPath().segmentCount()).setDevice(null);
					String ns = shortOne.removeFileExtension().toString();
					ns = patternSlash.matcher(ns).replaceAll("::");
					return new OawResourceID(ns, shortOne.getFileExtension());
				}
			}
		} catch (JavaModelException e1) {
			OawLog.logInfo(e1);
		}
		return null;
	}

	public static IJavaProject getJProject(IStorage s) {
		if (s instanceof IFile) {
			return JavaCore.create(((IFile) s).getProject());
		} else {
			IProject[] projects = ResourcesPlugin.getWorkspace().getRoot()
					.getProjects();
			for (int i = 0; i < projects.length; i++) {
				IProject project = projects[i];
				IJavaProject p = JavaCore.create(project);
				if (p.exists()) {
					IPackageFragmentRoot[] roots;
					try {
						roots = p.getPackageFragmentRoots();
						for (int j = 0; j < roots.length; j++) {
							IPackageFragmentRoot root = roots[j];
							if (root.getPath().isPrefixOf(s.getFullPath()))
								return p;
						}
					} catch (JavaModelException e) {
						OawLog.logError(e);
					}
				}
			}
		}
		return null;
	}

	private static IPath path(OawResourceID id) {
		return new Path(patternNamespace.matcher(id.name).replaceAll("/") + "." + id.extension);
	}

	public static String getQualifiedName(IStorage source) {
		OawResourceID id = findOawResourceID(getJProject(source), source);
		if (id != null)
			return id.name;
		return null;
	}

}
