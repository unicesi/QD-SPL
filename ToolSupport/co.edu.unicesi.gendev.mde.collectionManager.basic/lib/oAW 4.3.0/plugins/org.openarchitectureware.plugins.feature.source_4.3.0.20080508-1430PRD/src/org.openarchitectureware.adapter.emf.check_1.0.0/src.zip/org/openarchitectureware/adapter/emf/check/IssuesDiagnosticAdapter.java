/*******************************************************************************
 * <copyright>
 * Copyright (c) 2008 itemis AG and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * committers of openArchitectureWare - initial API and implementation
 * </copyright>
 *******************************************************************************/

package org.openarchitectureware.adapter.emf.check;

import org.eclipse.emf.common.util.BasicDiagnostic;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.openarchitectureware.workflow.issues.Issue;
import org.openarchitectureware.workflow.issues.Issues;

/**
 * 
 * @author Jan K�hnlein, Dennis H�bner
 */
public class IssuesDiagnosticAdapter {

	public static final void addDiagnosticFromIssues(
			DiagnosticChain allDiagnostics, Issues issues) {
		Issue[] errors = issues.getErrors();
		addDiagnostics(allDiagnostics, Diagnostic.ERROR, errors);
		Issue[] warnings = issues.getWarnings();
		addDiagnostics(allDiagnostics, Diagnostic.WARNING, warnings);
	}

	private static void addDiagnostics(DiagnosticChain allDiagnostics,
			int severity, Issue[] errors) {
		for (Issue issue : errors) {
			Object element = issue.getElement();
			String message = issue.getMessage();
			Object[] objects = new Object[] { element, null };
			String cleanedMessage = extractFeatureFromMessageAndStoreIt(
					message, objects);
			if (cleanedMessage != null)
				message = cleanedMessage;
			BasicDiagnostic diagnostic = new BasicDiagnostic(severity,
					"Oaw Check", 0, message, objects);

			allDiagnostics.add(diagnostic);
		}
	}

	/**
	 * Extracts feature name from given massage. If such a feature exists for
	 * object stored in object store as first element it will be stored in the
	 * object store with index 1. Delimiter '#'. <br>
	 * Exp.: message "name#Name must be set" will cause that EStructuralFeature<br>
	 * named 'name' will be stored in given store under index 1 and this method<br>
	 * returns "Name must be set"<br>
	 * 
	 * @param message
	 *            string to parse for feature name
	 * @param store
	 *            object store to store feature under index 1 if found. Object
	 *            store must have an EObject as first element
	 * @return cleaned message if cleaning was necessary null otherwise
	 */
	static private String extractFeatureFromMessageAndStoreIt(String message,
			Object[] store) {
		int i = message.indexOf('#');
		if (i > 0 && i < message.length() - 1) {
			Object o = store[0];
			if (o != null && o instanceof EObject) {
				EObject eObject = (EObject) o;
				String featureName = message.substring(0, i);
				message = message.substring(i + 1);
				EStructuralFeature feature = eObject.eClass()
						.getEStructuralFeature(featureName);
				if (feature != null) {
					store[1] = feature;
					return message;
				}
			}
		}
		return null;
	}
}
