/*******************************************************************************
 * <copyright>
 * Copyright (c) 2008 itemis AG and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * committers of openArchitectureWare - initial API and implementation
 * </copyright>
 *******************************************************************************/
package org.openarchitectureware.adapter.emf.check;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EValidator;
import org.openarchitectureware.check.CheckUtils;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.ExecutionContextImpl;
import org.openarchitectureware.expression.ResourceManager;
import org.openarchitectureware.expression.ResourceManagerDefaultImpl;
import org.openarchitectureware.expression.TypeSystemImpl;
import org.openarchitectureware.type.emf.EmfMetaModel;
import org.openarchitectureware.workflow.ConfigurationException;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.issues.IssuesImpl;
import org.openarchitectureware.xtend.ast.ExtensionFile;

/**
 * An implementation of {@link org.eclipse.emf.ecore.EValidator} that executes
 * oAW checks. Further EValidators can be nested.
 * 
 * Check files can be added with reparse option. If true, the check files are
 * reparse on each validation.
 * 
 * @author Jan K�hnlein
 */
public class CheckEValidatorAdapter implements EValidator {

	private List<String> _checkFiles;

	private List<ExtensionFile> _parsedChecks;

	private EValidator _nestedValidator;

	private EPackage _ePackage;

	private ResourceManager _resourceManager;

	public CheckEValidatorAdapter(EPackage ePackage) {
		_ePackage = ePackage;
		_checkFiles = new ArrayList<String>();
		_parsedChecks = new ArrayList<ExtensionFile>();
	}

	public CheckEValidatorAdapter(EPackage ePackage,
			EValidator existingValidator) {
		this(ePackage);
		if (existingValidator != null) {
			_nestedValidator = existingValidator;
		}
	}

	public ResourceManager getResourceManager() {
		if(_resourceManager == null) {
			_resourceManager = new ResourceManagerDefaultImpl();
		}
		return _resourceManager;
	}

	public void setResourceManager(ResourceManager manager) {
		_resourceManager = manager;
	}

	/**
	 * Adds a checkFile that is reparsed on each validation.
	 * 
	 * @param checkFile
	 */
	public void addCheckFile(String checkFile) {
		addCheckFile(checkFile, true);
	}

	/**
	 * Adds a check file.
	 * 
	 * @param checkFile
	 * @param isReparseOnValidation
	 *            if true, the check file is reparsed on each validation.
	 */
	public void addCheckFile(String checkFile, boolean isReparseOnValidation) {
		if(checkFile.toLowerCase().endsWith(CheckUtils.FILE_EXTENSION)) {
			checkFile = checkFile.substring(0, checkFile.length() - CheckUtils.FILE_EXTENSION.length() - 1);
		}
		final ExtensionFile parsedCheckFile = (ExtensionFile) getResourceManager().loadResource(checkFile, CheckUtils.FILE_EXTENSION);
		if (parsedCheckFile == null) {
			throw new ConfigurationException("Cannot find check file "
					+ checkFile);
		}
		if (isReparseOnValidation) {
			_checkFiles.add(checkFile);
		} else {
			addCheckFile(parsedCheckFile);
		}
	}

	/**
	 * Adds an already parsed check file that is never reparsed.
	 * 
	 * @param checkFile
	 */
	public void addCheckFile(ExtensionFile checkFile) {
		_parsedChecks.add(checkFile);
	}

	public void removeCheckFile(String checkFile) {
		_checkFiles.remove(checkFile);
	}

	public void removeCheckFile(ExtensionFile checkFile) {
		_parsedChecks.remove(checkFile);
	}

	public void removeAllCheckFiles() {
		_checkFiles.clear();
		_parsedChecks.clear();
	}

	public boolean validate(EObject eObject, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(eObject.eClass(), eObject, diagnostics, context);
	}

	public boolean validate(EClass eClass, EObject eObject,
			DiagnosticChain diagnostics, Map<Object, Object> context) {
		List<EObject> allElements = Collections.singletonList(eObject);
		boolean isValid = runOawCheck(diagnostics, allElements);
		if (_nestedValidator != null) {
			isValid &= _nestedValidator.validate(eClass, eObject, diagnostics,
					context);
		}
		return isValid;
	}

	public boolean validate(EDataType dataType, Object value,
			DiagnosticChain diagnostics, Map<Object, Object> context) {
		List<?> allElements = Collections.singletonList(dataType);
		boolean isValid = runOawCheck(diagnostics, allElements);
		if (_nestedValidator != null) {
			isValid &= _nestedValidator.validate(dataType, value, diagnostics,
					context);
		}
		return isValid;
	}

	private ExecutionContext createExecutionContext(final EPackage ePackage) {
		TypeSystemImpl typeSystem = new TypeSystemImpl();
		typeSystem.registerMetaModel(new EmfMetaModel() {
			// TODO : find out if oAW recursively adds referenced EMF metamodels
			private EPackage[] _ePackages = new EPackage[] { ePackage };

			@Override
			protected EPackage[] allPackages() {
				return _ePackages;
			}
		});
		ExecutionContext executionContext = new ExecutionContextImpl(getResourceManager(), typeSystem, null);
		return executionContext;
	}

	private boolean runOawCheck(DiagnosticChain diagnostics, List<?> allElements) {
		ExecutionContext executionContext = createExecutionContext(_ePackage);
		boolean isValid = true;
		for (String checkFile : _checkFiles) {
			Issues issues = new IssuesImpl();
			ExtensionFile parsedCheckFile = (ExtensionFile) getResourceManager().loadResource(checkFile, CheckUtils.FILE_EXTENSION);
			runOawCheck(parsedCheckFile, allElements, diagnostics,
					executionContext);
			isValid &= issues.hasErrors();
		}
		for (ExtensionFile parsedCheckFile : _parsedChecks) {
			Issues issues = runOawCheck(parsedCheckFile, allElements,
					diagnostics, executionContext);
			isValid &= issues.hasErrors();
		}
		return isValid;
	}

	private Issues runOawCheck(ExtensionFile parsedCheckFile,
			List<?> allElements, DiagnosticChain diagnostics,
			ExecutionContext executionContext) {
		Issues issues = new IssuesImpl();
		parsedCheckFile.check(executionContext, allElements, issues, false);
		IssuesDiagnosticAdapter.addDiagnosticFromIssues(diagnostics, issues);
		return issues;
	}

}
