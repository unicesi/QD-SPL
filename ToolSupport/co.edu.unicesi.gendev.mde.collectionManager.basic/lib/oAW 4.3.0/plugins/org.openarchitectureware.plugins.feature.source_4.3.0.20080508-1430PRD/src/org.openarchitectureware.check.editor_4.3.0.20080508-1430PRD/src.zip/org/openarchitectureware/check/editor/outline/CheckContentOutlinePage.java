/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *	   Jeremie Ratomposon <jratomposon@sdmda.com> SD-mdA - Outline Sorting feature
 * </copyright>
 */
package org.openarchitectureware.check.editor.outline;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IActionBars;
import org.openarchitectureware.core.IOawResource;
import org.openarchitectureware.editor.AbstractOawEditor;
import org.openarchitectureware.editor.outlineview.AbstractOawContentOutlinePage;
import org.openarchitectureware.editor.outlineview.OutlineElement;
import org.openarchitectureware.expression.editor.EditorImages;
import org.openarchitectureware.xtend.ast.Check;
import org.openarchitectureware.xtend.ast.ExtensionFile;


public class CheckContentOutlinePage extends AbstractOawContentOutlinePage {

	public static final int WARNING = 3, ERROR = 4;

	public CheckContentOutlinePage(AbstractOawEditor editor) {
		super(editor);
	}

	@Override
	protected OutlineElement[] getChildren(Object parentElement) {
		if (parentElement instanceof IOawResource) {
			ExtensionFile check = (ExtensionFile) ((IOawResource) parentElement)
					.getOawResource();
			if (check==null)
				return new OutlineElement[0];
			List<OutlineElement> result = new ArrayList<OutlineElement>();
			result.addAll(toOutlineElementsForNamespaceImports(check
					.getNsImports()));
			result.addAll(toOutlineElementsForExtensionImports(check
					.getExtImports()));
			result.addAll(toOutlineElements(check.getChecks()));
			return result.toArray(new OutlineElement[result.size()]);
		}
		return new OutlineElement[0];
	}
	//import
	//Since ImportStatements are used above, we can just use the superclass' methods
	//toOutlineElementsForNamespaceImports and toOutlineElementsForExtensionImports

	private List<OutlineElement> toOutlineElements(List<Check> checks) {
		List<OutlineElement> l = new ArrayList<OutlineElement>();
		for (Check check : checks) {

			Image img = EditorImages.getImage(EditorImages.ERROR_CHECK);
			int type = ERROR;
			if (!check.isErrorCheck()) {
				img = EditorImages.getImage(EditorImages.WARNING_CHECK);
				type = WARNING;
			}
			l.add(new OutlineElement(check.toString(), check.getStart(), check
					.getEnd()
					- check.getStart(), img, type));
		}
		return l;
	}

	// let's add a sort feature to this outline...
	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);
		// register global actions
		registerToolbarActions(getSite().getActionBars());
	}
	private void registerToolbarActions(IActionBars actionBars) {
		actionBars.getToolBarManager().add(new LexicalSortingAction());
	}

}
