/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.check.core.internal;

import java.util.Set;

import org.eclipse.core.resources.IStorage;
import org.openarchitectureware.check.core.internal.builder.CheckResourceParser;
import org.openarchitectureware.core.AbstractOawResource;
import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.Resource;
import org.openarchitectureware.xtend.XtendFile;

public class CheckResourceImpl extends AbstractOawResource {

    private CheckResourceParser parser;

	public CheckResourceImpl(final XtendFile res, final IStorage source, final CheckResourceParser parser) {
        super(source);
        setOawResource(res);
        this.parser = parser;
    }

    private XtendFile resource() {
        return (XtendFile) getOawResource();
    }

    public void analyze(final ExecutionContext ctx, final Set<AnalysationIssue> issues) {
        try {
        	resource().analyze(ctx, issues);
        } catch (Exception e) {
        	// ignore
        }
    }

	public String getFileExtension() {
		return parser.getFileExtension();
	}

	public boolean internalRefresh() {
		Resource o = parser.parse(getUnderlyingStorage(),getFullyQualifiedName());
		if (o==null)
			return false;
		setOawResource(o);
		return true;
	}

}
