package org.openarchitectureware.util.stdlib;

import org.eclipse.emf.ecore.EObject;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent2;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public class DanglingRefFinderComponent extends AbstractWorkflowComponent2 {
	
	private String modelSlot;

	public void setModelSlot( String slot ) {
		this.modelSlot = slot;
	}
	
	@Override
	protected void checkConfigurationInternal(Issues issues) {
		if (modelSlot == null ) issues.addError(this, "'modelSlot' not specified,");
	}
	
	@Override
	protected void invokeInternal(WorkflowContext ctx, ProgressMonitor monitor,
			Issues issues) {
		EObject root = (EObject)ctx.get(modelSlot);
		DanglingRefFinder finder = new DanglingRefFinder();
		finder.handle(root, issues);
	}

	
}
