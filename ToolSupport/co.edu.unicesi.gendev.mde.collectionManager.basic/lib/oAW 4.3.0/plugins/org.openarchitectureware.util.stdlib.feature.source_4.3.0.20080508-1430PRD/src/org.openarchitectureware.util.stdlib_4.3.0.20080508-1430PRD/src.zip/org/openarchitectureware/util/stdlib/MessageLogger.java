package org.openarchitectureware.util.stdlib;

import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent2;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public class MessageLogger extends AbstractWorkflowComponent2 {
	
	private String message;

	public void setMessage( String m ) {
		message = m;
	}
	
	@Override
	protected void checkConfigurationInternal(Issues issues) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	protected void invokeInternal(WorkflowContext ctx, ProgressMonitor monitor, Issues issues) {
		System.err.println(message);
	}
	

}
