package org.openarchitectureware.util.stdlib;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent2;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public class PropertiesReader extends AbstractWorkflowComponent2{

	
	
	private String propertiesFile;

	@Override
	protected void checkConfigurationInternal(Issues issues) {
		if (propertiesFile==null || ! new File(propertiesFile).exists()){
			issues.addError("Propertiesfile not set or file does not exist: " + propertiesFile);
		}
	}

	@Override
	protected void invokeInternal(WorkflowContext ctx, ProgressMonitor monitor, Issues issues) {
		try {
			Properties p = new Properties();
			p.load(new FileInputStream(propertiesFile));
			PropertiesExtension.setProperties(p);
			
		} catch (Exception e) {
			issues.addError(e.getMessage(), e);
		}
		
	}
	
	public final void setPropertiesFile( String propertiesFile ) {
		this.propertiesFile = propertiesFile;
	}

}
