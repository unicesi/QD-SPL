package org.openarchitectureware.util.stdlib;

import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent2;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public class SlotPrinter extends AbstractWorkflowComponent2 {
	
	private String slotName;
	private String message;
	
	public void setMessage( String m ) {
		this.message = m;
	}
	
	public void setSlotName( String name ) {
		this.slotName = name;
	}
	
	@Override
	protected void checkConfigurationInternal(Issues issues) {
		if ( slotName == null ) {
			issues.addError(this, "slotName not specified");
		}
	}
	
	@Override
	protected void invokeInternal(WorkflowContext ctx, ProgressMonitor monitor, Issues issues) {
		StringBuffer b = new StringBuffer();
		if ( message != null ) b.append(message+": ");
		b.append("(slot: "+slotName+")");
		b.append( ctx.get(slotName) );
		System.err.println(b.toString());
	}
	

}
