package org.openarchitectureware.util.stdlib.tracing;

import org.openarchitectureware.expression.ast.SyntaxElement;
import org.openarchitectureware.util.stdlib.TraceComponent;
import org.openarchitectureware.xpand2.XpandExecutionContext;
import org.openarchitectureware.xpand2.output.OutputImpl;

public class TracingOutput extends OutputImpl {
	
	@Override
	public void pushStatement(SyntaxElement stmt, XpandExecutionContext ctx) {
		super.pushStatement(stmt, ctx);
	}
	
	@Override
	public void openFile(String path, String outletName) {
		super.openFile(path, outletName);
		TraceComponent.reportFileOpen( path );
	}
	
	@Override
	public void closeFile() {
		super.closeFile();
		TraceComponent.reportFileClose();
	}

}
