/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.workflow.lib;

import org.openarchitectureware.workflow.WorkflowComponentWithID;
import org.openarchitectureware.workflow.ast.parser.Location;
import org.openarchitectureware.workflow.container.CompositeComponent;
import org.openarchitectureware.workflow.issues.Issues;

/**
 * Base class useful for implementing custom WorkflowComponents.
 * 
 * @author Markus Voelter (impl)
 * @author Karsten Thoms (doc)
 * @since 4.0
 */
public abstract class AbstractWorkflowComponent implements WorkflowComponentWithID {
	/** The component's id */
	private String componentID;

	/** Container component */
	private CompositeComponent container;

	private Location location;

	/**
	 * @return The component's id
	 */
	public String getId() {
		return componentID;
	}

	/**
	 * @param id
	 *            The component's id
	 */
	public void setId(final String id) {
		componentID = id;
	}

	/**
	 * @return The containing component if any
	 */
	public CompositeComponent getContainer() {
		return container;
	}

	/**
	 * @param container
	 *            The containing component
	 */
	public void setContainer(CompositeComponent container) {
		this.container = container;
	}

	public String getLogMessage() {
		return null;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(final Location location) {
		this.location = location;
	}

	/**
	 * Utility method that can be used in method <code>checkConfiguration</code>
	 * to check required properties. If <code>configPropertyValue</code> is
	 * <code>null</code> or a blank string then this method will add an error
	 * issue.
	 * 
	 * @param configPropertyName
	 *            Name of the checked config property.
	 * @param configPropertyValue
	 *            The config property value.
	 * @param issues
	 *            The Issues instance.
	 */
	public void checkRequiredConfigProperty(String configPropertyName, Object configPropertyValue, Issues issues) {
		boolean isError = false;
		if (configPropertyValue == null) {
			isError = true;
		} else if ((configPropertyValue instanceof String) && isBlank(configPropertyValue.toString())) {
			isError = true;
		}

		if (isError)
			issues.addError("'" + configPropertyName + "' not specified.");
	}

	private boolean isBlank(String string) {
		if (string == null || string.trim().equals("")) {
			return true;
		}
		return false;
	}
}
