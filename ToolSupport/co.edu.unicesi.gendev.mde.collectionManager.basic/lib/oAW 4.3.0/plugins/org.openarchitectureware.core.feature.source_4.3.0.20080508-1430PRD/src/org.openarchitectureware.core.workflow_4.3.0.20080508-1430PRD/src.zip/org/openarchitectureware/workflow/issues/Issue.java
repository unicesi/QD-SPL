/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.workflow.issues;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.openarchitectureware.workflow.WorkflowComponent;
import org.openarchitectureware.workflow.WorkflowComponentWithID;
import org.openarchitectureware.workflow.util.ComponentPrinter;

public class Issue {

	private WorkflowComponent context;

	private Object element;

	private String message;

	public Issue(final WorkflowComponent ctx, final String msg,
			final Object element) {
		context = ctx;
		message = msg;
		this.element = element;
		;
	}

	public Issue(final String msg, final Object element) {
		message = msg;
		this.element = element;
	}

	public Object getElement() {
		return element;
	}

	public WorkflowComponent getContext() {
		return context;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		final StringBuffer bf = new StringBuffer();
		if (context != null) {
			bf.append("ERROR in Component ");
			if (context instanceof WorkflowComponentWithID) {
				WorkflowComponentWithID wfcId = (WorkflowComponentWithID) context;
				if (wfcId.getId() != null)
					bf.append(wfcId.getId()).append(" ");
			}
			bf.append("of type ").append(context.getClass().getName()).append("\n\t");
		}
		bf.append(getMessage());
		if (getElement() != null) {
			if (getElement() instanceof Throwable) {
				Throwable t = (Throwable) getElement();
				StringWriter stringWriter = new StringWriter();
				t.printStackTrace(new PrintWriter(stringWriter));
				bf.append("[" + stringWriter.toString() + "]");
			} else {
				bf.append(" [" + getElement().toString() + "] ");
			}
		}
		if (getContext() != null) {
			bf.append(" in workflow: "
					+ ComponentPrinter.getString(getContext()));
		}

		return bf.toString();
	}
}