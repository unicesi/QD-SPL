package org.openarchitectureware.workflow.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

//todo: also provide ReaderToString

/**
 * This is a convenience class that completely reads an InputStream and dumps it to a byte array.
 *
 * @author Arno Haase
 */
public class InputStreamToByteArray {
    public static final int DEFAULT_BUFFER_SIZE = 4096;

    private final int _bufSize;

    public InputStreamToByteArray () {
        this (DEFAULT_BUFFER_SIZE);
    }

    public InputStreamToByteArray (int bufSize) {
        _bufSize = bufSize;
    }


    public byte[] read (InputStream is) throws IOException {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream ();

        final byte[] buf = new byte[_bufSize];
        int numRead = 0;
        while ((numRead = (is.read(buf))) > 0) {
            baos.write(buf, 0, numRead);
        }

        return baos.toByteArray();
    }
}
