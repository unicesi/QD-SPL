/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.workflow.util;

/**
 * Factory for
 * {@link org.openarchitectureware.workflow.util.ResourceLoader ResourceLoaders}.
 * By default this factory creates instances of
 * {@link org.openarchitectureware.workflow.util.ResourceLoaderDefaultImpl ResourceLoaderDefaultImpl}.
 * <p>
 * The factory evaluates the <tt>org.openarchitectureware.resourceimpl</tt>
 * system property to get the <tt>ResourceLoader</tt> implementation class
 * name. Set this property to specify an alternative implementation.
 * 
 * @author Sven Efftinge (http://www.efftinge.de)
 * @since 4.0
 */
public class ResourceLoaderFactory {
    public final static String PARAM_RESOURCELOADER_CLASS = "org.openarchitectureware.resourceimpl";

    private static Class<?> resourceLoaderImpl;

    private static final ThreadLocal<ResourceLoader> current = new ThreadLocal<ResourceLoader>();

    public static void setCurrentThreadResourceLoader(final ResourceLoader rl) {
        current.set(rl);
    }

    private static void initResourceLoaderClass() {
        final String name = System.getProperty(PARAM_RESOURCELOADER_CLASS, ResourceLoaderDefaultImpl.class.getName());
        // enable changing implementations at runtime.
        // preliminary implemented for the unittest of this class
        if (resourceLoaderImpl == null || (name != null && !name.equals(resourceLoaderImpl.getName()))) {
            try {
                resourceLoaderImpl = Class.forName(name);
            } catch (final ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * Creates an instance of ResourceLoader.
     * 
     * @return The newly created object
     * @throws RuntimeException
     *             In any case that an instance could not be created.
     */
    public static ResourceLoader createResourceLoader() throws RuntimeException {
        if (current.get() != null)
            return current.get();
        initResourceLoaderClass();
        try {
            return (ResourceLoader) resourceLoaderImpl.newInstance();
        } catch (final InstantiationException e) {
            throw new RuntimeException(e);
        } catch (final IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
