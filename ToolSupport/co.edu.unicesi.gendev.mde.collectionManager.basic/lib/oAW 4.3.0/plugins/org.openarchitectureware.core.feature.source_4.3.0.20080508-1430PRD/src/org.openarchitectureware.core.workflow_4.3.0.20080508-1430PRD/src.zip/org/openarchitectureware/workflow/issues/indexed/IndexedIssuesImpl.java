/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.workflow.issues.indexed;

import java.util.Set;

import org.openarchitectureware.workflow.WorkflowComponent;
import org.openarchitectureware.workflow.issues.Issue;
import org.openarchitectureware.workflow.issues.IssuesImpl;

public class IndexedIssuesImpl extends IssuesImpl implements IndexedIssues {

    private final MapSet<Object,Issue> indexedErrors = new MapSet<Object, Issue>();

    private final MapSet<Object,Issue> indexedWarnings = new MapSet<Object,Issue>();

    @Override
    public void addError(final WorkflowComponent ctx, final String msg, final Object element) {
        super.addError(ctx, msg, element);
        indexedErrors.put(element, new Issue(ctx, msg, element));
    }

    @Override
    public void addWarning(final WorkflowComponent ctx, final String msg, final Object element) {
        super.addWarning(ctx, msg, element);
        indexedWarnings.put(element, new Issue(ctx, msg, element));
    }

    @Override
    public void addError(final String msg, final Object element) {
        super.addError(msg, element);
        indexedErrors.put(element, new Issue(msg, element));
    }

    @Override
    public void addWarning(final String msg, final Object element) {
        super.addWarning(msg, element);
        indexedWarnings.put(element, new Issue(msg, element));
    }

    public Set<Issue> getErrorsFor(final Object element) {
        return indexedErrors.get(element);
    }

    public Set<Issue> getWarningsFor(final Object element) {
        return indexedWarnings.get(element);
    }

    public void cleanFor(final Object element) {
        indexedWarnings.remove(element);
        indexedErrors.remove(element);
    }

}
