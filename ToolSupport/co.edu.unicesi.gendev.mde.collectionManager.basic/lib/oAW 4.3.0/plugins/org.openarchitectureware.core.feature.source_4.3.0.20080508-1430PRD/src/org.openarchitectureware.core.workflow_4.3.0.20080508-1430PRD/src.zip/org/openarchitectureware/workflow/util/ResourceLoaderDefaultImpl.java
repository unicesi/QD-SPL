/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *     Bernd Kolb (http://www.kolbware.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.workflow.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.impl.URIConverterImpl;

public class ResourceLoaderDefaultImpl implements ResourceLoader {

	private static final String FILE_PREFIX = "file:";

	public final InputStream getResourceAsStream(String path) {
		InputStream in = internalGetResourceAsStream(path);
		if (in == null) {
			try {
				return new URIConverterImpl().createInputStream(URI
						.createURI(path));
			} catch (Exception e1) {
			}
			try {
				in = new FileInputStream(path);
			} catch (final FileNotFoundException e) {
				if (!path.startsWith(FILE_PREFIX)) {
					path = FILE_PREFIX + path;
				}
				try {
					in = new FileInputStream(path);
				} catch (final Exception ex) {
					return null;
				}
			}
		}
		return in;
	}

	protected InputStream internalGetResourceAsStream(final String path) {
		return Thread.currentThread().getContextClassLoader()
				.getResourceAsStream(path);
	}

	public final Class<?> loadClass(final String clazzName) {
		try {
			return internalLoadClass(clazzName);
		} catch (final Exception e) {
			if (clazzName.startsWith("oaw"))
				return loadClass(clazzName.replaceFirst("oaw",
						"org.openarchitectureware"));
			return null;
		}
	}

	protected Class<?> internalLoadClass(final String clazzName)
			throws ClassNotFoundException {
		return Class.forName(clazzName, true, Thread.currentThread()
				.getContextClassLoader());
	}

	public final URL getResource(String path) {
		URL url = internalGetResource(path);
		if (url == null) {
			try {
				File file = new File(path);
				if (file.exists())
					return file.getAbsoluteFile().toURI().toURL();

				if (!path.startsWith(FILE_PREFIX))
					path = FILE_PREFIX + path;

				url = new URL(path);
				if (url.getContent() == null)
					return null;
			} catch (final MalformedURLException e) {
				return null;
			} catch (final IOException e) {
				return null;
			}
		}
		return url;
	}

	protected URL internalGetResource(final String path) {
		return Thread.currentThread().getContextClassLoader().getResource(path);
	}

}
