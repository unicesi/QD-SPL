/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.workflow.ast.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openarchitectureware.workflow.ast.AbstractASTBase;
import org.openarchitectureware.workflow.ast.ComponentAST;
import org.openarchitectureware.workflow.ast.DeclaredPropertyAST;
import org.openarchitectureware.workflow.ast.DeclaredPropertyFileAST;
import org.openarchitectureware.workflow.ast.InclusionAST;
import org.openarchitectureware.workflow.ast.ReferenceAST;
import org.openarchitectureware.workflow.ast.SimpleParamAST;
import org.openarchitectureware.workflow.util.ResourceLoader;
import org.openarchitectureware.workflow.util.ResourceLoaderFactory;

public abstract class VisitorBase {

    protected Log log = LogFactory.getLog(getClass());

    protected ResourceLoader loader = ResourceLoaderFactory.createResourceLoader();

    public final Object visit(final AbstractASTBase ele) {
        Object result = visitAbstractASTBase(ele);
        if (result == null && ele instanceof InclusionAST) {
            result = visitInclusionAST((InclusionAST) ele);
        }
        if (result == null && ele instanceof ComponentAST) {
            result = visitComponentAST((ComponentAST) ele);
        }
        if (result == null && ele instanceof DeclaredPropertyAST) {
            result = visitDeclaredPropertyAST((DeclaredPropertyAST) ele);
        }
        if (result == null && ele instanceof DeclaredPropertyFileAST) {
            result = visitDeclaredPropertyFileAST((DeclaredPropertyFileAST) ele);
        }
        if (result == null && ele instanceof ReferenceAST) {
            result = visitReferenceAST((ReferenceAST) ele);
        }
        if (result == null && ele instanceof SimpleParamAST) {
            result = visitSimpleParamAST((SimpleParamAST) ele);
        }
        return result;
    }

    public Object visitAbstractASTBase(final AbstractASTBase ele) {
        return null;
    }

    public Object visitComponentAST(final ComponentAST ele) {
        return null;
    }

    public Object visitInclusionAST(final InclusionAST ele) {
        return null;
    }

    public Object visitDeclaredPropertyAST(final DeclaredPropertyAST ele) {
        return null;
    }

    public Object visitDeclaredPropertyFileAST(final DeclaredPropertyFileAST ele) {
        return null;
    }

    public Object visitReferenceAST(final ReferenceAST ele) {
        return null;
    }

    public Object visitSimpleParamAST(final SimpleParamAST ele) {
        return null;
    }

}
