package org.openarchitectureware.workflow.lib;

import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public class PassiveWorkflowComponent extends AbstractWorkflowComponent {

	public void checkConfiguration(Issues issues) {
		// do nothing intentionally
	}

	public void invoke(WorkflowContext ctx, ProgressMonitor monitor,
			Issues issues) {
		// do nothing intentionally
	}

}
