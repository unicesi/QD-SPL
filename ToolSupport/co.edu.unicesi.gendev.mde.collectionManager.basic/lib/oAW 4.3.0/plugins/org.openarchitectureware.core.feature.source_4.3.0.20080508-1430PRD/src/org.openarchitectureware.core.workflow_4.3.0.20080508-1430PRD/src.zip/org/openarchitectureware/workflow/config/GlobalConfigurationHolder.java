package org.openarchitectureware.workflow.config;

import org.openarchitectureware.workflow.issues.Issues;

public class GlobalConfigurationHolder {

	private static ConfigurationModel configModel = null;

	public static void setConfigurationModel( ConfigurationModel cm, Issues issues ) {
		if ( configModel != null ) {
			if ( !configModel.equals(cm)) {
				issues.addError("configuration model already set!");
			}
		} else {
			configModel = cm;
		}
	}
	
	public static ConfigurationModel getConfiguration() {
		return configModel;
	}

	
}
