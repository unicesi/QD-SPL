package org.openarchitectureware.compiler.helpers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openarchitectureware.expression.parser.SyntaxConstants;
import org.openarchitectureware.xpand2.ast.AbstractDefinition;
import org.openarchitectureware.xpand2.ast.ExpandStatement;
import org.openarchitectureware.xpand2.ast.ImportDeclaration;
import org.openarchitectureware.xpand2.ast.Statement;
import org.openarchitectureware.xpand2.ast.StatementWithBody;
import org.openarchitectureware.xpand2.ast.Template;


/**
 * This class iterates over the nodes of a parsed template and extracts a collection of all referenced 
 *  other templates and extensions.
 * 
 * @author arno
 */
class TemplateIncludesVisitor {
    private final Set<String> _result = new HashSet<String>();
    private final List<String> _importedNsWithSlash = new ArrayList<String>();
    private final Template _template;
    
    public TemplateIncludesVisitor (Template template) {
        _template = template;
        
        // remember imports
        for (String ns: template.getImportedNamespaces()) {
            _importedNsWithSlash.add (ns.replace(SyntaxConstants.NS_DELIM, "/"));
        }
        
        // extensions are available from the declarations in the header
        for (ImportDeclaration imp: template.getExtensions()) {
            _result.add (imp.getImportString().getValue().replace (SyntaxConstants.NS_DELIM, "/"));
        }        
        
        for (AbstractDefinition def: template.getAllDefinitions()) {
            for (Statement stmt: def.getBody())
                visit (stmt);
        }
    }
    
    public Set<String> getReferencedTemplateFqns () {
        return _result;
    }
    
    private void visit (Statement stmt) {
        if (stmt instanceof ExpandStatement) {
            final ExpandStatement expand = (ExpandStatement) stmt;
            final String referenced = expand.getDefinition().getValue();
            if (! referenced.contains(SyntaxConstants.NS_DELIM))
                return;

            final String templateName = referenced.substring(0, referenced.lastIndexOf(SyntaxConstants.NS_DELIM));
            
            final String referencedFqn = TemplateHelper.getTemplateFqn (templateName, _template);
            if (referencedFqn == null)
                throw new RuntimeException ("could not resolve template definition " + referenced + " in file " + _template.getFileName() + " at line " + stmt.getLine());
            
            _result.add (referencedFqn);
        }
        else if (stmt instanceof StatementWithBody) {
            for (Statement substmt: ((StatementWithBody) stmt).getBody())
                visit (substmt);
        }
    }
}



















