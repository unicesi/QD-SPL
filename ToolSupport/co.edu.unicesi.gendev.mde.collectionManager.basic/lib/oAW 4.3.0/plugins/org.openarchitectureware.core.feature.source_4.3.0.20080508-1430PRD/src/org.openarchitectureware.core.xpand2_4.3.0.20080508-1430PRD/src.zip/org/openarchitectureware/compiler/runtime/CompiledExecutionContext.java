package org.openarchitectureware.compiler.runtime;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openarchitectureware.expression.TypeSystem;
import org.openarchitectureware.workflow.util.Pair;
import org.openarchitectureware.xpand2.output.Outlet;
import org.openarchitectureware.xpand2.pr.ProtectedRegionResolver;

/**
 * This class contains a ThreadLocal with all data relevant at runtime, e.g. cached values and
 *  global vars.
 *  
 * @author arno
 */
public class CompiledExecutionContext {
    private static final ThreadLocal<CompiledExecutionContext> _theInstance = new ThreadLocal<CompiledExecutionContext> () {
        @Override
        protected CompiledExecutionContext initialValue() {
            return new CompiledExecutionContext();
        }
    };
    
    private CompiledExecutionContext () {}
    
    public static CompiledExecutionContext getInstance () {
        return _theInstance.get();
    }

    
    private final Map<String, Object> _globalVars = new HashMap<String, Object>();
    private final Map<Pair<Method, List<Object>>, Object> _cachedResults = new HashMap<Pair<Method, List<Object>>, Object>();
    private final Map<String, Outlet> _outlets = new HashMap<String, Outlet>();
    private ProtectedRegionResolver _prResolver;
    private TypeSystem _typeSystem;
    
    /**
     * This method serves to clear all data stored for this thread.
     */
    public void reInit () {
        _globalVars.clear ();
        _cachedResults.clear ();
        _outlets.clear();
        _prResolver = null;
        _typeSystem = null;
    }
    
    public void setGlobalVar (String name, Object value) {
        _globalVars.put(name, value);
    }
    
    public Object getGlobalVar (String name) {
        return _globalVars.get(name);
    }
    
    public Map<String, Object> getGlobalVars () {
        return Collections.unmodifiableMap (_globalVars);
    }

    private Pair<Method, List<Object>> createKey (Method mtd, Object[] params) {
        return new Pair<Method, List<Object>> (mtd, Arrays.asList(params));
    }
    
    public boolean hasCachedValue (Method mtd, Object[] params) {
        return _cachedResults.containsKey(createKey(mtd, params));
    }
    
    public Object getCachedValue (Method mtd, Object[] params) {
        return _cachedResults.get(createKey(mtd, params));
    }
    
    public void storeCachedValue (Method mtd, Object[] params, Object result) {
        _cachedResults.put (createKey(mtd, params), result);
    }
    
    public ProtectedRegionResolver getProtectedRegionResolver () {
        return _prResolver;
    }
    
    public void setProtectedRegionResolver (ProtectedRegionResolver resolver) {
        _prResolver = resolver;
    }
    
    public Map<String, Outlet> getAllOutlets () {
        return _outlets;
    }
    
    public void registerOutlet (String name, Outlet outlet) {
        _outlets.put(name, outlet);
    }
    
    public Outlet getOutlet (String name) {
        return _outlets.get (name);
    }
    
    public void setTypeSystem (TypeSystem typeSystem) {
        _typeSystem = typeSystem;
    }
    
    public TypeSystem getTypeSystem () {
        return _typeSystem;
    }
}


