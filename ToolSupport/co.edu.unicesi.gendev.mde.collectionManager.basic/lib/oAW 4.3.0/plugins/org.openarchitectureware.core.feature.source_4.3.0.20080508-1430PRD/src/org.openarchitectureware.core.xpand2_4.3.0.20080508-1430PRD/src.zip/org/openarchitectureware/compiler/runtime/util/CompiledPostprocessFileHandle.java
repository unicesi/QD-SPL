package org.openarchitectureware.compiler.runtime.util;

import java.io.File;

import org.openarchitectureware.xpand2.output.FileHandle;
import org.openarchitectureware.xpand2.output.Outlet;


public class CompiledPostprocessFileHandle implements FileHandle {
    private final Outlet _outlet;
    private EfficientLazyString _content;
    private final File _targetFile;

    public CompiledPostprocessFileHandle (Outlet outlet, EfficientLazyString content, File targetFile) {
        _outlet = outlet;
        _content = content;
        _targetFile = targetFile;
    }
    
    public EfficientLazyString getContent () {
        return _content;
    }
    
    public CharSequence getBuffer() {
        return _content;
    }

    public String getFileEncoding() {
        return _outlet.getFileEncoding();
    }

    public Outlet getOutlet() {
        return _outlet;
    }

    public File getTargetFile() {
        return _targetFile;
    }

    public boolean isAppend() {
        return _outlet.isAppend();
    }

    public boolean isOverwrite() {
        return _outlet.isOverwrite();
    }

    public void setBuffer (CharSequence buffer) {
        if (buffer instanceof EfficientLazyString){
            _content = (EfficientLazyString) buffer;
        }
        else {
            _content = new EfficientLazyString ();
            _content.append (buffer);
        }
    }

    public void writeAndClose() {
        throw new UnsupportedOperationException ("The FileHandle must not be closed by a PostProcessor.");
    }
}

