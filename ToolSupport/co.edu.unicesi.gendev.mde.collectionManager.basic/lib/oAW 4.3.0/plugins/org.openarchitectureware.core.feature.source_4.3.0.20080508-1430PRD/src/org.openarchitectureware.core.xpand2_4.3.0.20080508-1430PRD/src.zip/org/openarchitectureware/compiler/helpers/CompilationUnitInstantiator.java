package org.openarchitectureware.compiler.helpers;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent2;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;
import org.openarchitectureware.workflow.util.ResourceLoaderFactory;
import org.openarchitectureware.workflow.util.ResourceLoaderImpl;
import org.openarchitectureware.xpand2.ast.Template;
import org.openarchitectureware.xpand2.parser.XpandParseFacade;
import org.openarchitectureware.xtend.XtendResourceParser;
import org.openarchitectureware.xtend.ast.ExtensionFile;
import org.openarchitectureware.xtend.ast.ImportStatement;



public class CompilationUnitInstantiator extends AbstractWorkflowComponent2 {
    public static final String FILE_SEPARATOR = System.getProperty ("file.separator");
    public static final String EXTENSION_EXT = ".ext";
    public static final String TEMPLATE_EXT = ".xpt";
    
    
    private final Collection<String> _sourceNames = new HashSet<String>();
    private final List<String> _classpath = new ArrayList<String>();

    private String _sourceEncoding;
    
    private String _outputSlot;

    public void addSourceName(String filename) {
        _sourceNames.add (filename);
    }

    public void addResourceRoot (String cpElement) {
        _classpath.add(cpElement);
    }
    
    public void setOutputSlot(String outputSlot) {
        _outputSlot = outputSlot;
    }

    public void setSourceEncoding (String encoding) {
        _sourceEncoding = encoding;
    }
    
    @Override
    protected void checkConfigurationInternal(Issues issues) {
        if (_sourceNames.isEmpty())
            issues.addError("extensionFilename must be set");
        
        if (_outputSlot == null)
            issues.addError("outputSlot must be set");
    }

    @SuppressWarnings("unused")
	private void println (String s, int indent) {
        System.err.print ("                                                                ".substring (0, 2*indent));
        System.err.println (s);
    }
        
    private InputStream readResource (String name) throws MalformedURLException {
        if (_classpath.isEmpty())
            return getClass().getResourceAsStream(name);
        
        final URL[] urls = new URL[_classpath.size()];
        for (int i=0; i<_classpath.size(); i++) {
            //TODO handle JAR entries to the classpath
            String urlRaw = "file:" + _classpath.get(i);
            if (! urlRaw.endsWith("/"))
                urlRaw += "/";
            
            urls[i] = new URL (urlRaw);
            System.err.println (name + ": " + urlRaw);
        }
        
        final URLClassLoader urlCl = new URLClassLoader (urls);
        System.err.println(urlCl);
        ResourceLoaderFactory.setCurrentThreadResourceLoader(new ResourceLoaderImpl (urlCl));
        return urlCl.getResourceAsStream(name);
    }
    
    private Reader getResourceReader (String name) throws MalformedURLException, UnsupportedEncodingException {
        final InputStream is = readResource(name);
        if (is == null)
            return null;
        
        if (_sourceEncoding == null)
            return new InputStreamReader (is);
        
        return new InputStreamReader (is, _sourceEncoding);
    }
    
    private void parseResource (CompilableApp theApp, String nameWithoutExtension) throws IOException {
        if (theApp.getCompilationUnits().contains(nameWithoutExtension))
            return;
        
        if (getResourceReader(nameWithoutExtension + EXTENSION_EXT) != null)
            parseExtension (theApp, nameWithoutExtension);
        else
            parseTemplate (theApp, nameWithoutExtension);
    }
    
    private void parseExtension (CompilableApp theApp, String nameWithoutExtension) throws IOException {
        final XtendResourceParser parser = new XtendResourceParser();
        final ExtensionFile r = (ExtensionFile) parser.parse(getResourceReader(nameWithoutExtension + EXTENSION_EXT), nameWithoutExtension + EXTENSION_EXT);
        
        theApp.registerCompilationUnit(nameWithoutExtension, r);
        
        for (ImportStatement imp: r.getExtImports()) {
            final String importedExtension = imp.getImportedId().getValue().replace('.', '/');
            parseResource (theApp, importedExtension);
        }        
    }
    
    private void parseTemplate (CompilableApp theApp, String nameWithoutExtension) throws IOException {
    	final String fileName = nameWithoutExtension + TEMPLATE_EXT;
        final Reader r = getResourceReader (fileName);
        if (r == null)
            throw new IllegalArgumentException ("resource not found: " + fileName);
        
        final Template template = XpandParseFacade.file(r, fileName);
        
        theApp.registerCompilationUnit (nameWithoutExtension, template);
        
        for (String referenced: new TemplateIncludesVisitor (template).getReferencedTemplateFqns())
            parseResource (theApp, referenced);
    }

    
    private void addResourcesRecursively (Collection<String> resolvedSourceNames, File cpRoot, File includeRoot) {
        if (!includeRoot.getAbsolutePath().startsWith (cpRoot.getAbsolutePath()))
            throw new IllegalArgumentException ("'" + includeRoot.getAbsolutePath() + "' is not a subdirectory of '" + cpRoot.getAbsolutePath() + "'.");
        
        for (File f: includeRoot.listFiles()) {
            if (f.isDirectory()) {
                addResourcesRecursively (resolvedSourceNames, cpRoot, f);
            }
            else if (f.getName().endsWith(TEMPLATE_EXT) || f.getName().endsWith(EXTENSION_EXT)) {
                final int prefixlength = cpRoot.getAbsolutePath().length();
                
                String filename = includeRoot.getAbsolutePath().substring(prefixlength); 
                if (filename.startsWith (FILE_SEPARATOR))
                    filename = filename.substring (FILE_SEPARATOR.length());
                
                //strip the extension
                filename = filename.substring (0, filename.length() - EXTENSION_EXT.length());
                
                filename = filename.replace (FILE_SEPARATOR, "/");
                
                resolvedSourceNames.add (filename);
            }
        }
    }
    
    
    @Override
    protected void invokeInternal(WorkflowContext ctx, ProgressMonitor monitor, Issues issues) {
        try {
            final Collection<String> resolvedSourceNames = new HashSet<String>();
            for (String rawSourceName: _sourceNames) {
                boolean isFolder = false;
                
                for (String root: _classpath) {
                    final File fileFolder = new File (root, rawSourceName);
                    if (fileFolder.isDirectory()) {
                        addResourcesRecursively (resolvedSourceNames, new File (root), fileFolder);
                        isFolder = true;
                    }
                }
                
                if (!isFolder)
                    resolvedSourceNames.add (rawSourceName);
            }
            
            final CompilableApp result = new CompilableApp (_sourceEncoding);
            
            for (String filename: resolvedSourceNames) {
                parseResource(result, filename);
            }

            ctx.set(_outputSlot, result);
        } catch (Exception exc) {
            throw new RuntimeException(exc);
        }
    }
}






