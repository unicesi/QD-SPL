/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.xpand2.ast;

import java.util.Set;

import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.expression.EvaluationException;
import org.openarchitectureware.expression.ast.Expression;
import org.openarchitectureware.type.Type;
import org.openarchitectureware.xpand2.XpandExecutionContext;

/**
 * *
 * 
 * @author Sven Efftinge (http://www.efftinge.de) *
 */
public class IfStatement extends StatementWithBody {

    private Expression condition;

    private IfStatement upperIf;

    private IfStatement elseIf;

    public IfStatement(final Expression condition,
            final Statement[] body) {
        super(body);
        this.condition = condition;
    }

    public Expression getCondition() {
        return condition;
    }

    public IfStatement getElseIf() {
        return elseIf;
    }

    public void setElseIf(final IfStatement elseIf) {
        this.elseIf = elseIf;
        elseIf.setUpperIf(this);
    }

    private void setUpperIf(final IfStatement upperIf) {
		this.upperIf = upperIf;
    }

    public boolean isElseIf() {
    	return upperIf != null && elseIf != null;
    }

    public boolean isElse() {
    	return upperIf != null && elseIf == null;
    }

    @Override
	public void analyzeInternal(final XpandExecutionContext ctx, final Set<AnalysationIssue> issues) {
        if (condition != null) {
            final Type conType = getCondition().analyze(ctx, issues);
            if (conType != null && !ctx.getBooleanType().isAssignableFrom(conType)) {
                issues.add(new AnalysationIssue(AnalysationIssue.INCOMPATIBLE_TYPES, "Boolean expected!",
                        getCondition()));
            }
        }
        for (int i = 0; i < body.length; i++) {
            body[i].analyze(ctx, issues);
        }
        if (getElseIf() != null) {
            getElseIf().analyze(ctx, issues);
        }
    }

    @Override
    public void evaluateInternal(final XpandExecutionContext ctx) {
        if (condition != null) {
            final Object result = getCondition().evaluate(ctx);
            if (result == null)
                throw new EvaluationException("Nullevaluation!", getCondition(), ctx);
            if (!(result instanceof Boolean))
                throw new EvaluationException("Boolean expected!", getCondition(), ctx);
            if (((Boolean) result).booleanValue()) {
                for (int i = 0; i < body.length; i++) {
                    body[i].evaluate(ctx);
                }
            } else if (getElseIf() != null) {
                getElseIf().evaluate(ctx);
            }
        } else {
        	// the else portion is an IfStatement with a null condition
            for (int i = 0; i < body.length; i++) {
                body[i].evaluate(ctx);
            }
        }
    }

}
