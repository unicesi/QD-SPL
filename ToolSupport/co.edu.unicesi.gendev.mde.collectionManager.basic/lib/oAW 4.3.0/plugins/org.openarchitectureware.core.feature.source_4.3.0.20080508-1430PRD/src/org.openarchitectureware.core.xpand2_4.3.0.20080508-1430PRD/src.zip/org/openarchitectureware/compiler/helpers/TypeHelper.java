package org.openarchitectureware.compiler.helpers;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.ExecutionContextImpl;
import org.openarchitectureware.expression.TypeSystemImpl;
import org.openarchitectureware.expression.Variable;
import org.openarchitectureware.expression.ast.DeclaredParameter;
import org.openarchitectureware.type.Type;
import org.openarchitectureware.type.impl.java.JavaMetaModel;
import org.openarchitectureware.type.impl.java.beans.JavaBeansStrategy;
import org.openarchitectureware.xtend.ast.ExpressionExtensionStatement;
import org.openarchitectureware.xtend.ast.ExtensionFile;

public class TypeHelper {
    public static Type getExtensionType (ExtensionFile extFile, ExpressionExtensionStatement extension) {
        if (extension.getReturnTypeIdentifier() != null)
            return getTypeForIdentifier(extFile.getImportedNamespacesAsList(), extension.getReturnTypeIdentifier().getValue());

        final TypeSystemImpl typeSystem = new TypeSystemImpl();
        typeSystem.registerMetaModel(new JavaMetaModel("mm", new JavaBeansStrategy()));

        ExecutionContext ctx = new ExecutionContextImpl (typeSystem);
        for (DeclaredParameter p: (List<DeclaredParameter>) extension.getFormalParameters()) {
            final Type t = getTypeForIdentifier(extFile.getImportedNamespacesAsList(), p.getType().getValue());
            ctx = ctx.cloneWithVariable(new Variable (p.getName().getValue(), t));
        }
        
        final Type result = extension.getExpression().analyze(ctx, new HashSet<AnalysationIssue>());
        
        if (result == null)
            return typeSystem.getObjectType();
        if ("Void".equals(result.getName()))
            return typeSystem.getObjectType();
        
        return result;
    }
    
    public static Type getTypeForIdentifier(List<String> importedNs, String typeIdentifier) {
        final TypeSystemImpl typeSystem = new TypeSystemImpl();
        typeSystem.registerMetaModel(new JavaMetaModel("mm", new JavaBeansStrategy()));

        return typeSystem.getTypeForName(typeIdentifier, importedNs.toArray(new String[0]));
    }
    

    public static Collection<String> withAddedVarName (Collection<String> varNames, String newVarName) {
        final Set<String> result = new HashSet<String>(varNames);
        result.add (newVarName);
        return result;
    }
    
    public static Object dump(Object o) {
        if (o == null)
            System.err.println("<null>");
        else
            System.err.println(o + ": " + o.getClass().getName());
        return o;
    }
}
