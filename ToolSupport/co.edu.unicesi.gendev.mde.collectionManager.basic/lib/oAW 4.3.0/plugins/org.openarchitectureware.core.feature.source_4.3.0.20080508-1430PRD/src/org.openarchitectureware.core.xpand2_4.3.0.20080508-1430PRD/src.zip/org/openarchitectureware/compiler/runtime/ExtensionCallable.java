package org.openarchitectureware.compiler.runtime;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


public class ExtensionCallable implements Callable {
    private final Method _mtd;
    private final boolean _isCached;
    
    public ExtensionCallable (Method mtd, boolean isCached) {
        _mtd = mtd;
        _isCached = isCached;
    }
    
    public String getName() {
        return _mtd.getName();
    }

    @SuppressWarnings("unchecked")
	public Class[] getParamTypes() {
        return _mtd.getParameterTypes();
    }

    public Object invoke(Object[] params) throws Throwable {
        final CompiledExecutionContext ctx = CompiledExecutionContext.getInstance();
        if (_isCached && ctx.hasCachedValue(_mtd, params))
            return ctx.getCachedValue(_mtd, params);
        
        //TODO invocation target from the execution context
        final Object o = _mtd.getDeclaringClass().newInstance();
        
        try {
            final Object result = _mtd.invoke(o, params);
            if (_isCached)
                ctx.storeCachedValue(_mtd, params, result);
            return result;
        }
        catch (InvocationTargetException exc) {
            throw exc.getCause();
        }
    }

    public Object invoke(Object first, Object[] params) throws Throwable {
        final Object[] actualParams = new Object[params.length + 1];
        actualParams[0] = first;
        System.arraycopy(params, 0, actualParams, 1, params.length);
        
        return invoke (actualParams);
    }
}
