package org.openarchitectureware.compiler.helpers;

import java.util.ArrayList;
import java.util.List;

import org.openarchitectureware.expression.parser.SyntaxConstants;
import org.openarchitectureware.workflow.util.ResourceLoader;
import org.openarchitectureware.workflow.util.ResourceLoaderFactory;
import org.openarchitectureware.xpand2.ast.Template;


/**
 * Helper methods used as JAVA extensions for the processing of template definition calls
 */
public class TemplateHelper {
    public static String templateClassName (String definition, TemplateContext tctx) {
        System.err.println ("**********************************************************");

        final int indDef = definition.lastIndexOf(SyntaxConstants.NS_DELIM);

        if (indDef == -1)
            return tctx.getFqnWithPackagePrefix();
        definition = definition.substring (0, indDef);


        final String fqn = getTemplateFqn(definition, tctx.getTemplate());
        if (fqn == null)
            throw new IllegalArgumentException ("no template found for definition '" + definition + "'");

        return tctx.getPackagePrefix() + "." + fqn.replace("/", ".");
    }

    public static String getTemplateFqn (String templateName, Template curTemplate) {
        final ResourceLoader rl = ResourceLoaderFactory.createResourceLoader();
        
        for (String candidate: getCandidateFqns (templateName, curTemplate)) {
            if (rl.getResourceAsStream(candidate + CompilationUnitInstantiator.TEMPLATE_EXT) != null)
                return candidate;
        }
        
        return null;
    }
    
    public static List<String> getCandidateFqns (String name, Template curTemplate) {
        final List<String> result = new ArrayList<String>();
        
        name = name.replace (SyntaxConstants.NS_DELIM, "/");
        result.add (name);
        
        if (curTemplate.getFullyQualifiedName().contains("/")) {
            String prefix = curTemplate.getFullyQualifiedName();
            prefix = prefix.substring (0, prefix.lastIndexOf('/'));
            
            result.add (prefix + "/" + name);
        }
        
        final List<String> importedNsWithSlash = new ArrayList<String>();
        for (String ns: curTemplate.getImportedNamespaces()) {
            importedNsWithSlash.add (ns.replace(SyntaxConstants.NS_DELIM, "/"));
        }
        
        for (String ns: importedNsWithSlash)
            result.add (ns + "/" + name);
        
        System.err.println ("candidates: " + result);
        
        return result;
    }

    
    public static String definitionName (String definition) {
        final int index = definition.lastIndexOf(SyntaxConstants.NS_DELIM);
        if (index == -1)
            return definition;
        
        return definition.substring(index + SyntaxConstants.NS_DELIM.length());
    }
}
