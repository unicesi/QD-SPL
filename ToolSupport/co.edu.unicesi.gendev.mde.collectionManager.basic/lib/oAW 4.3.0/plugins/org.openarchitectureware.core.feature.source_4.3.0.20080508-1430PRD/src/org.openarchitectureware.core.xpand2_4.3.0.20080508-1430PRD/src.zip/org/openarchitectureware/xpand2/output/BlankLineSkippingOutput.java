package org.openarchitectureware.xpand2.output;

import org.openarchitectureware.expression.ast.SyntaxElement;
import org.openarchitectureware.xpand2.XpandExecutionContext;
import org.openarchitectureware.xpand2.ast.TextStatement;


/**
 * This output implementation avoids writing of unnecessary blank lines.  
 * @author Karsten Thoms
 * @since 4.1.2
 */
public class BlankLineSkippingOutput extends OutputImpl {
    private final static char NEWLINE = '\n';
    private StringBuffer buffer = null;
    private boolean evaluateLine = false;
    public void write(final String bytes) {
        if (current() != null) {
        	int idxNL = bytes.indexOf(NEWLINE);
        	if (buffer==null && idxNL>=0) {
        		buffer = new StringBuffer();
        		((StringBuffer) current().getBuffer()).append(bytes.substring(0, idxNL));
        		if (idxNL<bytes.length()) buffer.append(bytes.substring(idxNL));
        	} else if (buffer!=null && idxNL>=0) {
        		buffer.append(bytes.substring(0, idxNL));
        		if (evaluateLine && !buffer.toString().trim().equals("")) {
        		    ((StringBuffer) current().getBuffer()).append (buffer.toString());
        		}
        		buffer = null;
        		evaluateLine = false;
        		if (idxNL<bytes.length()) write(bytes.substring(idxNL));
        	} else if (buffer!=null) {
        		buffer.append(bytes);
        	} else {
        	    ((StringBuffer) current().getBuffer()).append(bytes);
            }
        }
    }

    public void closeFile() {
    	if (buffer!=null && current()!=null) {
    	    ((StringBuffer) current().getBuffer()).append(buffer);
    		buffer=null;
    	}
        super.closeFile();
    }

	@Override
	public void pushStatement(SyntaxElement stmt, XpandExecutionContext ctx) {
		if (buffer!=null && !(stmt instanceof TextStatement)) {
			evaluateLine = true;
		}
		super.pushStatement(stmt, ctx);
	}
    
    
}
