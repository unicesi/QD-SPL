package org.openarchitectureware.compiler.runtime;


/**
 * This interface serves as a common abstraction for built-in operations and extensions. Parameters
 *  always include the "this" object, even for built-in methods - this is done as a normalization
 *  so that both ways of calling a Callable share a common interface.
 * 
 * @author arno
 */
public interface Callable {
    Object invoke (Object[] params) throws Throwable;
    Object invoke (Object first, Object[] params) throws Throwable;

    String getName ();
    Class<?>[] getParamTypes ();
}
