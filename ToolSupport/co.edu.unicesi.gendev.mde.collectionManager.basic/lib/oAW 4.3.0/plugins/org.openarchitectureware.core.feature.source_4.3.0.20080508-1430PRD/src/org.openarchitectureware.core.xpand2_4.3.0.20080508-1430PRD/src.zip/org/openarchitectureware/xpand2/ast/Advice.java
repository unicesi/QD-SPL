/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.xpand2.ast;

import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.Variable;
import org.openarchitectureware.expression.ast.DeclaredParameter;
import org.openarchitectureware.expression.ast.Identifier;
import org.openarchitectureware.type.Type;
import org.openarchitectureware.xpand2.XpandExecutionContext;
import org.openarchitectureware.xpand2.model.XpandAdvice;
import org.openarchitectureware.xpand2.model.XpandDefinition;
import org.openarchitectureware.xpand2.type.DefinitionType;

/**
 * @author Sven Efftinge (http://www.efftinge.de) *
 */
public class Advice extends AbstractDefinition implements XpandAdvice {

	public final static String DEF_VAR_NAME = "targetDef";

	public Advice(final Identifier pointCut, final Identifier type, final DeclaredParameter[] params, final boolean wildParams, final Statement[] body) {
		super(pointCut, type, params, body);
		this.wildParams = wildParams;
	}

	public Identifier getPointCut() {
		return getDefName();
	}

	@Override
	public void analyze(XpandExecutionContext ctx, final Set<AnalysationIssue> issues) {
		ctx = (XpandExecutionContext) ctx.cloneWithVariable(new Variable(DEF_VAR_NAME, ctx.getTypeForName(DefinitionType.TYPE_NAME)));
		super.analyze(ctx, issues);
	}

	private Pattern p = null;

	public boolean matches(final XpandDefinition def, XpandExecutionContext ctx) {
		if (p == null) {
			p = Pattern.compile(getName().replaceAll("\\*", ".*"));
		}
		final Matcher m = p.matcher(def.getQualifiedName());
		if (m.matches()) {
			ctx = (XpandExecutionContext) ctx.cloneWithResource(def.getOwner());
			final Type t = ctx.getTypeForName(def.getTargetType());
			final Type[] paramTypes = new Type[def.getParams().length];
			for (int i = 0; i < paramTypes.length; i++) {
				paramTypes[i] = ctx.getTypeForName(def.getParams()[i].getType().getValue());
			}
			if (getParams().length == paramTypes.length || (wildParams && getParams().length <= paramTypes.length)) {

				ctx = (XpandExecutionContext) ctx.cloneWithResource(def.getOwner());
				final Type at = ctx.getTypeForName(getTargetType());
				if (at.isAssignableFrom(t)) {
					for (int i = 0; i < getParams().length; i++) {
						final Type pt = ctx.getTypeForName(getParams()[i].getType().getValue());
						if (!pt.isAssignableFrom(paramTypes[i]))
							return false;
					}
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public String getNameString(ExecutionContext context) {
		return "AROUND";
	}

}
