package org.openarchitectureware.compiler.runtime;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;


public class MethodCallable implements Callable {
    private final Method _mtd;
    private final Class<?>[] _paramTypes;

    public MethodCallable (Method mtd) {
        _mtd = mtd;
        _paramTypes = new Class[mtd.getParameterTypes().length + 1];
        _paramTypes[0] = mtd.getDeclaringClass();
        System.arraycopy(mtd.getParameterTypes(), 0, _paramTypes, 1, _paramTypes.length - 1);
        for (int i=0; i<mtd.getParameterTypes().length; i++)
            _paramTypes[i+1] = mtd.getParameterTypes()[i];
    }
    
    
    public String getName() {
        return _mtd.getName();
    }

    public Class<?>[] getParamTypes() {
        return _paramTypes;
    }

    public Object invoke(Object[] params) throws Throwable {
        final Object[] actualParams = new Object[params.length - 1];
        System.arraycopy(params, 1, actualParams, 0, actualParams.length);

        return invoke (params[0], actualParams);
    }


    public Object invoke(Object first, Object[] params) throws Throwable {
        if (first == null)
            return null;
        
        try {
            _mtd.setAccessible(true);
            
            // convert return values of type Integer to the oAW internal Integer representation: java.lang.Long
            final Object result = _mtd.invoke(first, params);
            if (result != null && result.getClass().equals (Integer.class))
                return new Long (((Integer) result).intValue());
            return result;
        }
        catch (InvocationTargetException exc) {
            throw exc.getCause();
        }
    }
    
    @Override
    public String toString() {
        return "Method: " + _mtd.getName() + "(" + Arrays.asList(_paramTypes) + ")";
    }
}

