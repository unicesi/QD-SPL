package org.openarchitectureware.compiler.runtime.util;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

/**
 * This class is a "String" implementation that is optimized for efficient concatenation of arbitrary objects. It
 *  has the specialty of converting its contents to Strings lazyly, i.e. only when the toString method is called.
 *  That allows slot-like behavior where an element that was added to the string can be modified later so that
 *  the modified version actually gets into the resulting string.
 * <p>
 * Another specialty is that this class can stream its contents to a Writer without the necessity of creating an
 *  intermediate string in memory.
 * <p>
 * One non-obvious benefit of consistent usage of this class is that mostly string constants from classes are stored
 *  here, and they are "interned". This can significantly decrease memory footprint and improve performance.
 * 
 * @author arno
 */
public class EfficientLazyString implements CharSequence {
    private boolean _isDirty = false;
    private String _asString = "";
    private final List<Object> _contents = new ArrayList<Object>();

    public void append (Object o) {
        if (o != null) {
            _isDirty = true;
            _contents.add(o);
        }
    }

    /**
     * This method is inefficient and breaks the core ideas of this class, not least because it forces the contained 
     *  string to be instantiated. It is however necessary to reproduce the behavior of the "nonl" feature of Xpand. 
     */
    public void appendWithNoNl (Object o) {
        final String trimmedOld = removeWSAfterLastNewline (toString ());
        final String toBeAppended = trimUntilNewline (o == null ? "" : o.toString());
        
        _contents.clear ();
        _contents.add (trimmedOld);
        _contents.add (toBeAppended);
        _isDirty = true;
    }
    

    /**
     * if and only if there is nothing but whitespace after the last \r or \n character,
     *  remove this whitespace
     */
    private static String removeWSAfterLastNewline (String s) {
        for (int i = s.length(); i > 0; i--) {
            final char c = s.charAt (i - 1);
            
            if (! Character.isWhitespace (c))
                return s;
            
            if (isNewLine(c))
                return s.substring (0, i);
        }

        return s;
    }

    private static boolean isNewLine(char c) {
        return c == '\n' || c == '\r';
    }

    private static String trimUntilNewline(String bytes) {
        int i = 0;
        boolean wsOnly = true;
        for (; i < bytes.length() && wsOnly; i++) {
            char c = bytes.charAt(i);
            wsOnly = Character.isWhitespace(c);
            if (wsOnly && isNewLine(c)) {
                if (c == '\r' && i + 1 < bytes.length() && bytes.charAt(i + 1) == '\n')
                    i++;
                return bytes.substring(i + 1);
            }
        }
        return bytes;
    }

    
    public void writeTo (Writer w) throws IOException {
        if (_isDirty) {
            for (Object o: _contents) {
                if (o instanceof EfficientLazyString) 
                    ((EfficientLazyString) o).writeTo(w);
                else
                    w.write(o.toString());
            }
        }
        else {
            w.write(_asString);
        }
    }

    @Override
    public String toString() {
        if (_isDirty) {
            final StringBuilder result = new StringBuilder (32768); // big initial capacity - this is only a temporary object, and the contents can get rather big

            for (Object o: _contents)
                result.append(o);

            _asString = result.toString();
        }        
        return _asString;
    }

    @Override
    public boolean equals(Object obj) {
        throw new IllegalArgumentException ("EfficientLazyString can not be compared directly - compare string representations");
    }
    
    @Override
    public int hashCode() {
        throw new IllegalArgumentException ("EfficientLazyString can not be compared directly - compare string representations");
    }

    public char charAt(int index) {
        return toString().charAt(index);
    }

    public int length() {
        return toString().length();
    }

    public CharSequence subSequence(int start, int end) {
        return toString().subSequence(start, end);
    }
}




