package org.openarchitectureware.compiler.helpers;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import org.openarchitectureware.expression.parser.SyntaxConstants;

public class FeatureHelper {
    public static boolean isTypeName (String name) {
        return name.indexOf(SyntaxConstants.NS_DELIM) != -1;
    }
    
    public static boolean isStaticFeature(String name) {
        if (name.indexOf(SyntaxConstants.NS_DELIM) == -1)
            return false;

        String typeName = name;
        typeName = typeName.substring(0, typeName.lastIndexOf(SyntaxConstants.NS_DELIM));

        final String litName = name.substring(name.lastIndexOf(SyntaxConstants.NS_DELIM) + SyntaxConstants.NS_DELIM.length());

        try {
            final Class<?> type = Class.forName(typeName.replaceAll("::", "."));
            final Field f = type.getField(litName);
            return (f.getModifiers() & Modifier.PUBLIC) != 0 &&
                (f.getModifiers() & Modifier.STATIC) != 0 &&
                (f.getModifiers() & Modifier.FINAL) != 0
            ;
        } catch (Exception exc) {
            return false;
        }
    }
}
