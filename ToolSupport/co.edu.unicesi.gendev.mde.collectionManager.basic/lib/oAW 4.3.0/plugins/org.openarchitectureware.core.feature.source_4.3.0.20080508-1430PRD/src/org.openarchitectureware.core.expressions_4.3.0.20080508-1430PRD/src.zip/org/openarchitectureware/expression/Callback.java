package org.openarchitectureware.expression;

import org.openarchitectureware.expression.ast.Expression;
import org.openarchitectureware.expression.ast.SyntaxElement;
import org.openarchitectureware.type.Type;

/**
 * an instance of this interface can be injected into the execution context.
 * It is notified before and after analyzation/evaluation of each AST node. 
 * @author Sven Efftinge
 */
public interface Callback {
	/**
	 * @param ele
	 * @param ctx
	 */
	void pre(SyntaxElement ele, ExecutionContext ctx);
	/**
	 * @param expressionResult the result of the evaluation (an instance of {@link Type} in analyzation phase) if syntax element was an instance of {@link Expression}
	 */
	void post(Object expressionResult);
}
