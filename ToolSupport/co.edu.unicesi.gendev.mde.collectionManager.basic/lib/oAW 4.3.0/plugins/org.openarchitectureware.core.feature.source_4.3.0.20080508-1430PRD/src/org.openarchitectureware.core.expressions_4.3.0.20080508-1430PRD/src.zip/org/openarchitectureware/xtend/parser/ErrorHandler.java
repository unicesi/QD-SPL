package org.openarchitectureware.xtend.parser;

public interface ErrorHandler {
	public void handleError(OawError e);
}	
