package org.openarchitectureware.xtend.types;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.type.Type;
import org.openarchitectureware.xtend.ast.Extension;

public class AdviceContext {

    private final Extension ext;

    private final ExecutionContext ctx;

	private Object[] parameters;


    public AdviceContext(final Extension ext, final ExecutionContext ctx, Object[] parameters2) {
		super();
		this.ext = ext;
		this.ctx = ctx;
		this.parameters = parameters2;
	}

	public String getName() {
        return ext.getName();
    }

    public List<Type> getParamTypes() {
        return ext.getParameterTypes();
    }

    public List<String> getParamNames() {
        return ext.getParameterNames();
    }
    public List<Object> getParamValues() {
    	return new ArrayList<Object>(Arrays.asList(parameters));
    }

    public Object proceed() {
        return ext.evaluate(parameters,ctx);
    }

    public Object proceed(final Object[] params) {
        return ext.evaluate(params,ctx);
    }

    @Override
    public String toString() {
        return ext.toString();
    }
}
