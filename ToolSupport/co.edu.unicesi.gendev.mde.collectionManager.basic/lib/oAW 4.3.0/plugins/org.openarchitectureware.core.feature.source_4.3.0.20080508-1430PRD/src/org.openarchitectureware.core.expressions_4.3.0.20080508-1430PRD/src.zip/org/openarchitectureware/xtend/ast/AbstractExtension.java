/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.xtend.ast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.expression.EvaluationException;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.Variable;
import org.openarchitectureware.expression.ast.DeclaredParameter;
import org.openarchitectureware.expression.ast.Identifier;
import org.openarchitectureware.expression.ast.SyntaxElement;
import org.openarchitectureware.type.Type;

public abstract class AbstractExtension extends SyntaxElement implements Extension {

	private Identifier name;

	private List<DeclaredParameter> formalParameters;

	protected ExtensionFile file;

	protected boolean cached = false;

	private boolean isPrivate = false;

	public AbstractExtension(final Identifier name, final Identifier returnType, final List<DeclaredParameter> formalParameters,
			final boolean cached, final boolean isPrivate) {
		this.name = name;
		this.formalParameters = formalParameters;
		this.returnType = returnType;
		this.cached = cached;
		this.isPrivate = isPrivate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#getFormalParameters()
	 */
	public List<DeclaredParameter> getFormalParameters() {
		return formalParameters;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#getName()
	 */
	public String getName() {
		return name.getValue();
	}

	public Identifier getNameIdentifier() {
		return name;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#getReturnType(org.openarchitectureware.type.Type[],
	 *      org.openarchitectureware.expression.ExecutionContext, java.util.Set)
	 */
	public final Type getReturnType(final Type[] parameters, ExecutionContext ctx, final Set<AnalysationIssue> issues) {
		ctx = ctx.cloneWithResource(getExtensionFile());
		return internalGetReturnType(parameters, ctx, issues);
	}

	protected abstract Type internalGetReturnType(Type[] parameters, ExecutionContext ctx, Set<AnalysationIssue> issues);

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#analyze(org.openarchitectureware.expression.ExecutionContext,
	 *      java.util.Set)
	 */
	public final void analyze(ExecutionContext ctx, final Set<AnalysationIssue> issues) {
		try {
			if (ctx.getCallback() != null)
				ctx.getCallback().pre(this, ctx);
			final List<DeclaredParameter> params = getFormalParameters();
			final Set<String> usedNames = new HashSet<String>();
			for (final Iterator<DeclaredParameter> iter = params.iterator(); iter.hasNext();) {
				final DeclaredParameter p = iter.next();
				final Type pt = ctx.getTypeForName(p.getType().getValue());
				if (pt == null) {
					issues.add(new AnalysationIssue(AnalysationIssue.TYPE_NOT_FOUND, "Type not found: " + p.getType().getValue(),
							p.getType()));
				}
				if (!usedNames.add(p.getName().getValue())) {
					issues.add(new AnalysationIssue(AnalysationIssue.SYNTAX_ERROR, "Duplicate parameter name: "
							+ p.getName().getValue(), p.getName()));
				}
				ctx = ctx.cloneWithVariable(new Variable(p.getName().getValue(), pt));
			}
			if (returnType != null) {
				final Type pt = ctx.getTypeForName(returnType.getValue());
				if (pt == null) {
					issues.add(new AnalysationIssue(AnalysationIssue.TYPE_NOT_FOUND, "Type not found: " + returnType.getValue(),
							returnType));
				}
			}
			try {
				analyzeInternal(ctx, issues);
			} catch (RuntimeException ex) {
				ctx.handleRuntimeException(ex, this, null);
			}
		} finally {
			if (ctx.getCallback() != null)
				ctx.getCallback().post(null);
		}
	}

	protected abstract void analyzeInternal(ExecutionContext ctx, Set<AnalysationIssue> issues);

	private final Map<List<Object>, Object> cache = new HashMap<List<Object>, Object>();

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#evaluate(java.lang.Object[],
	 *      org.openarchitectureware.expression.ExecutionContext)
	 */
	public Object evaluate(final Object[] parameters, ExecutionContext ctx) {
		try {
			if (ctx.getCallback() != null)
				ctx.getCallback().pre(this, ctx);
			if (cached) {
				final List<Object> l = Arrays.asList(parameters);
				if (cache.containsKey(l))
					return cache.get(l);
			}
			if (getExtensionFile() == null)
				throw new IllegalStateException("No containing file!");
			ctx = ctx.cloneWithResource(getExtensionFile());
			final Object result = evaluateInternal(parameters, ctx);
			if (cached) {
				cache.put(Arrays.asList(parameters), result);
			}
			return result;
		} catch (RuntimeException ex) {
			ctx.handleRuntimeException(ex, this, null);
		} finally {
			if (ctx.getCallback() != null)
				ctx.getCallback().post(null);
		}
		return null;
	}

	public final void setExtensionFile(final ExtensionFile f) {
		file = f;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#getExtensionFile()
	 */
	public ExtensionFile getExtensionFile() {
		return file;
	}

	protected abstract Object evaluateInternal(Object[] parameters, ExecutionContext ctx);

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#getParameterNames()
	 */
	public List<String> getParameterNames() {
		final List<String> names = new ArrayList<String>();
		for (final Iterator<DeclaredParameter> iter = getFormalParameters().iterator(); iter.hasNext();) {
			names.add(iter.next().getName().getValue());
		}
		return names;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#init(org.openarchitectureware.expression.ExecutionContext)
	 */
	public void init(final ExecutionContext ctx) {
		if (parameterTypes == null) {
			try {
				parameterTypes = new ArrayList<Type>();
				for (final Iterator<DeclaredParameter> iter = getFormalParameters().iterator(); iter.hasNext();) {
					final String name = iter.next().getType().getValue();
					final Type t = ctx.getTypeForName(name);
					if (t == null)
						throw new EvaluationException("Couldn't resolve type for '" + name
								+ "'. Did you forget to configure the corresponding metamodel?", this, ctx);
					parameterTypes.add(t);
				}
			} catch (final RuntimeException e) {
				parameterTypes = null;
				throw e;
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#getReturnType()
	 */
	public Type getReturnType() {
		throw new UnsupportedOperationException();
	}

	private List<Type> parameterTypes = null;

	protected Identifier returnType;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#getParameterTypes()
	 */
	public List<Type> getParameterTypes() {
		return parameterTypes;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#getReturnTypeIdentifier()
	 */
	public Identifier getReturnTypeIdentifier() {
		return returnType;
	}

	private String _stringRepresentation = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#toString()
	 */
	@Override
	public String toString() {
		if (_stringRepresentation == null) {
			_stringRepresentation = (returnType != null ? returnType.getValue() + " " : "") + getName() + "(" + paramsToString()
					+ ")";
		}

		return _stringRepresentation;
	}

	private String _outlineRepresentation = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#toOutlineString()
	 */
	public String toOutlineString() {
		if (_outlineRepresentation == null) {
			_outlineRepresentation = getName() + "(" + paramsToOutlineString() + ")"
					+ (returnType != null ? ": " + returnType.getValue() : "");
		}
		return _outlineRepresentation;
	}

	private String paramsToString() {
		final StringBuffer buff = new StringBuffer();
		for (final Iterator<DeclaredParameter> iter = getFormalParameters().iterator(); iter.hasNext();) {
			final DeclaredParameter element = iter.next();
			buff.append(element.getType() + " " + element.getName());
			if (iter.hasNext()) {
				buff.append(",");
			}
		}
		return buff.toString();
	}

	private String paramsToOutlineString() {
		final StringBuffer buff = new StringBuffer();
		for (final Iterator<DeclaredParameter> iter = getFormalParameters().iterator(); iter.hasNext();) {
			final DeclaredParameter element = iter.next();
			buff.append(element.getType());
			if (iter.hasNext()) {
				buff.append(", ");
			}
		}
		return buff.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#isPrivate()
	 */
	public boolean isPrivate() {
		return isPrivate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.xtend.ast.Extension#isCached()
	 */
	public boolean isCached() {
		return cached;
	}

	public String getQualifiedName() {
		return getExtensionFile().getFullyQualifiedName() + "::" + getName();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
		result = prime * result + ((parameterTypes == null) ? 0 : parameterTypes.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final AbstractExtension other = (AbstractExtension) obj;
		if (getName() == null) {
			if (other.getName() != null)
				return false;
		} else if (!getName().equals(other.getName()))
			return false;
		if (parameterTypes == null) {
			if (other.parameterTypes != null)
				return false;
		} else if (!parameterTypes.equals(other.parameterTypes))
			return false;
		return true;
	}

}
