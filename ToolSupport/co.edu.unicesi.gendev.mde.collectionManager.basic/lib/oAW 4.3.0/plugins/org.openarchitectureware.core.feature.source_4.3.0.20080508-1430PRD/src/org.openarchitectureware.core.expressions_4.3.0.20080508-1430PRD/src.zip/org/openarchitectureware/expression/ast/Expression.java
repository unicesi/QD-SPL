/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.expression.ast;

import java.util.Set;

import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.expression.Analyzable;
import org.openarchitectureware.expression.Evaluatable;
import org.openarchitectureware.expression.EvaluationException;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.type.Type;

/**
 * @author Bernd Kolb
 * 
 */
public abstract class Expression extends SyntaxElement implements Analyzable, Evaluatable {

	protected Type findType(final Identifier type, final ExecutionContext ctx, final Set<AnalysationIssue> issues) {
		final Type toCast = ctx.getTypeForName(type.getValue());
		if (toCast == null) {
			issues.add(new AnalysationIssue(AnalysationIssue.TYPE_NOT_FOUND, type.getValue(), type));
		}
		return toCast;
	}

	public final Object evaluate(final ExecutionContext ctx) {
		Object evaluateInternal = null;
		try {
			if (ctx.getCallback() != null)
				ctx.getCallback().pre(this, ctx);
			evaluateInternal = evaluateInternal(ctx);
			return evaluateInternal;
		} catch (final EvaluationException ex) {
			ctx.handleRuntimeException(ex, this, null);
			return null;
		} catch (final RuntimeException ex) {
			EvaluationException evalex = new EvaluationException(ex.getMessage(), this, ctx);
			ctx.handleRuntimeException(evalex, this, null);
			return null;
		} finally {
			if (ctx.getCallback() != null)
				ctx.getCallback().post(evaluateInternal);
		}
	}
	
	public Type analyze(ExecutionContext ctx, Set<AnalysationIssue> issues) {
		Type val = null;
		try {
			if (ctx.getCallback() != null)
				ctx.getCallback().pre(this, ctx);
			val = analyzeInternal(ctx,issues);
			return val;
		} catch (final RuntimeException ex) {
			issues.add(new AnalysationIssue(AnalysationIssue.INTERNAL_ERROR, ex.getMessage(), this));
			return null;
		} finally {
			if (ctx.getCallback() != null)
				ctx.getCallback().post(val);
		}
	}

	protected abstract Type analyzeInternal(ExecutionContext ctx, Set<AnalysationIssue> issues);
	
	@Override
	public final String toString() {
		return toStringInternal();
	}

	protected abstract String toStringInternal();

	protected abstract Object evaluateInternal(ExecutionContext ctx);

}
