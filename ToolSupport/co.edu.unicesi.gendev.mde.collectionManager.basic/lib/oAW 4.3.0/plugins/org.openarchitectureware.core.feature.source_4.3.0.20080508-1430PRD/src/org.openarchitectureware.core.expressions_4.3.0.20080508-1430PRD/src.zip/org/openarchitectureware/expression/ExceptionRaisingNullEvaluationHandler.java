package org.openarchitectureware.expression;

import org.openarchitectureware.expression.ast.SyntaxElement;

public class ExceptionRaisingNullEvaluationHandler implements
		NullEvaluationHandler {

	public Object handleNullEvaluation(SyntaxElement element, ExecutionContext ctx) {
		throw new EvaluationException("null evaluation",element, ctx);
	}

}
