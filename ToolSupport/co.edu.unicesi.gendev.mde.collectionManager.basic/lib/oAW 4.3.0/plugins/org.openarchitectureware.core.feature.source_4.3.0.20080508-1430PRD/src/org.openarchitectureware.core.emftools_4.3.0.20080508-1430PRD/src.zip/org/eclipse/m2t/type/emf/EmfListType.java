package org.eclipse.m2t.type.emf;

import java.util.Collection;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.openarchitectureware.expression.TypeSystem;
import org.openarchitectureware.type.Type;
import org.openarchitectureware.type.baseimpl.types.ListTypeImpl;

public class EmfListType extends ListTypeImpl {

	public EmfListType(final Type innerType, final TypeSystem ts, final String name) {
		super(innerType, ts, name);
	}

	@Override
	public Object convert(Object src, Class<?> targetType) {
		if (targetType != EList.class)
			throw new RuntimeException("Unexpected target type " + targetType.getName());

		if (src instanceof EList)
            return src;

		if (src instanceof Collection) {
			return new BasicEList((Collection)src);
		}
		
		return super.convert(src, targetType);
	}
}
