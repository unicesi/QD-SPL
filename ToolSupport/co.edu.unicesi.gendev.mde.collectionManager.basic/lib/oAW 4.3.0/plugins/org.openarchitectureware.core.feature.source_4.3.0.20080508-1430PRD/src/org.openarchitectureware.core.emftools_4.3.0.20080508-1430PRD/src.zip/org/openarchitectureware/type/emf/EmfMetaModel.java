/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.type.emf;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.m2t.type.emf.EmfRegistryMetaModel;
import org.openarchitectureware.emf.EcoreUtil2;
import org.openarchitectureware.type.MetaModel;
import org.openarchitectureware.workflow.ConfigurationException;

@SuppressWarnings("unchecked")
public class EmfMetaModel extends EmfRegistryMetaModel implements MetaModel {
	private EPackage metamodel;

	public EmfMetaModel() {
	}
	
	public EmfMetaModel(final EPackage metamodel) {
		this.metamodel = metamodel;
	}
	
	public void setMetaModelDescriptor(final String ePackageDescriptor) {
		metamodel = EcoreUtil2.getEPackageByDescriptorClassName(ePackageDescriptor);
		if (metamodel == null) {
			throw new ConfigurationException("Couldn't find ePackage Descriptor '" + ePackageDescriptor);
		}
	}

	public void setMetaModelPackage(final String ePackage) {
		metamodel = EcoreUtil2.getEPackageByClassName(ePackage);
		if (metamodel == null) {
			throw new ConfigurationException("Couldn't find ePackage '" + ePackage);
		}
	}

	public void setMetaModelFile(final String metaModelFile) {
		metamodel = EcoreUtil2.getEPackage(metaModelFile);
		if (metamodel == null) {
			throw new ConfigurationException("Couldn't load ecore file '" + metaModelFile);
		}
	}
	
	@Override
	protected EPackage[] allPackages() {
		return new EPackage[]{metamodel};
	}
}