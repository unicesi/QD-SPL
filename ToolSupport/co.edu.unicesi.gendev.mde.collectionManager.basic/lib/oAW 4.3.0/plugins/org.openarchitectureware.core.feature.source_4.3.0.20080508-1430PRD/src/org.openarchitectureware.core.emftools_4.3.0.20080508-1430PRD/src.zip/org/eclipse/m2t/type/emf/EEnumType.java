/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.eclipse.m2t.type.emf;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EEnumLiteral;
import org.openarchitectureware.type.AbstractTypeImpl;
import org.openarchitectureware.type.Feature;
import org.openarchitectureware.type.baseimpl.StaticPropertyImpl;

@SuppressWarnings("unchecked")
public class EEnumType extends AbstractTypeImpl {

    private EEnum eEnum;

    public EEnumType(final EmfRegistryMetaModel model, final String name, final EEnum eEnum) {
        super(model.getTypeSystem(), name);
        this.eEnum = eEnum;
    }

    @Override
    public Feature[] getContributedFeatures() {
        final Set<StaticPropertyImpl> result = new HashSet<StaticPropertyImpl>();
        final List<EEnumLiteral> enumLiterals = eEnum.getELiterals();
        for (final Iterator<EEnumLiteral> iter = enumLiterals.iterator(); iter.hasNext();) {
            final EEnumLiteral lit = iter.next();
            result.add(new StaticPropertyImpl(this, lit.getName(), this) {
                public Object get() {
                    return lit.getInstance();
                }
            });
        }
        return result.toArray(new Feature[result.size()]);
    }

    public boolean isInstance(final Object o) {
        return eEnum.isInstance(o);
    }

    public Object newInstance() {
        throw new UnsupportedOperationException("Enums are static!");
    }

}
