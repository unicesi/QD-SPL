package org.openarchitectureware.util.uml2ecore;

import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public class ParamChecker extends AbstractWorkflowComponent {

	private boolean resPerTlP;
	private String modelUri;

	public void setResourcePerToplevelPackage( boolean b ) {
		resPerTlP = b;
	}
	
	public void setUri( String uri ) {
		modelUri = uri;
	}
	
	public void checkConfiguration(Issues issues) {
		if ( modelUri.endsWith(".ecore")) {
			if ( resPerTlP ) {
				issues.addError(this, "if you specify resourcePerToplevelPackage='true', the uri parameter must point to a directory!");
			}
		} else {
			if ( !resPerTlP ) {
				issues.addError(this, "if you specify resourcePerToplevelPackage='false', the uri parameter must point to a .ecore file!");
			}
			
		}

	}

	public void invoke(WorkflowContext ctx, ProgressMonitor monitor,
			Issues issues) {
		// do nothin - this is ok.
	}

}
