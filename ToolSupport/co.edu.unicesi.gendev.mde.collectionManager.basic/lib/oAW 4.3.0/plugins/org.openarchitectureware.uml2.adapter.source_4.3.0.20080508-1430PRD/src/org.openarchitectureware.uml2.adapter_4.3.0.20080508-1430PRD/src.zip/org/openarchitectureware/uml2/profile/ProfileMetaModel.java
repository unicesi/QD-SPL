/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.uml2.profile;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.uml2.uml.Element;
import org.eclipse.uml2.uml.Enumeration;
import org.eclipse.uml2.uml.EnumerationLiteral;
import org.eclipse.uml2.uml.NamedElement;
import org.eclipse.uml2.uml.Package;
import org.eclipse.uml2.uml.Profile;
import org.eclipse.uml2.uml.Stereotype;
import org.eclipse.uml2.uml.UMLPackage;
import org.openarchitectureware.expression.TypeSystem;
import org.openarchitectureware.expression.parser.SyntaxConstants;
import org.openarchitectureware.type.MetaModel;
import org.openarchitectureware.type.Type;
import org.openarchitectureware.uml2.UML2MetaModelBase;
import org.openarchitectureware.uml2.UML2Util2;
import org.openarchitectureware.workflow.ConfigurationException;
import org.openarchitectureware.workflow.util.Cache;

public class ProfileMetaModel implements MetaModel {
    public Profile profile;
    
    private TypeSystem typeSystem;
    
    private class InternaleProfileMetaModel extends UML2MetaModelBase {
    	private Profile profile;
		public InternaleProfileMetaModel(Profile profile) {
			super();
			this.profile = profile;
		}
		
		private final Cache<String,Type> typeForNameCache = new Cache<String, Type>() {
			@SuppressWarnings("synthetic-access")
			@Override
			protected Type createNew(String typeName) {
				NamedElement ele = getNamedElementRec(new NamedElement[] { profile }, (String) typeName);
				if (ele!=null) {
					Type result = getTypeForEClassifier(ele.eClass());
					return result;
				} else {
					return null;
				}
			}
		};

		public Type getTypeForName(final String typeName) {
			return typeForNameCache.get(typeName);
		}

		private NamedElement getNamedElementRec(final NamedElement[] elements, final String name) {
			final String[] frags = name.split(SyntaxConstants.NS_DELIM);
			final String firstFrag = frags[0];
			for (final NamedElement ele : elements) {
				if (ele.getName()!=null && ele.getName().equals(firstFrag)) {
					if (frags.length > 1) {
						final Collection<ENamedElement> children = EcoreUtil.getObjectsByType(ele.eContents(),
								UMLPackage.eINSTANCE.getNamedElement());

						return getNamedElementRec(children.toArray(new NamedElement[children.size()]), name.substring(name
								.indexOf(SyntaxConstants.NS_DELIM)
								+ SyntaxConstants.NS_DELIM.length()));
					} else {
						return ele;
					}
				}
			}
			return null;
		}
		
    };
    
    private InternaleProfileMetaModel internalProfileMetaModel;
    
    /**
     * Flag, if an exception should be thrown, if stereotypes, assigned to the
     * model element, are not loaded.
     * If set to 'false', stereotypes not loaded are skipped.
     * Default is 'true'.
     */
    private boolean errorIfStereotypeMissing = true;
    
    private final Set<String> namespaces = new TreeSet<String>();
    
    public void setErrorIfStereotypeMissing(boolean errorIfStereotypeMissing){
    	this.errorIfStereotypeMissing = errorIfStereotypeMissing;
    }

    public ProfileMetaModel() {
    }

    public ProfileMetaModel(Profile profile) {
        assert profile!=null;
        this.profile = profile;
        init();
    }

    public void setProfile(String profile) {
        assert profile!=null;
        Profile p = UML2Util2.loadProfile(profile);
        if (p == null) {
            throw new ConfigurationException("Couldn't load profile from " + profile);
        }
        this.profile = p;
        init();
    }

    private Map<String, Type> stereoTypes = null;

    /**
     * Initializes the metamodel. All stereotypes in the profile are mapped to StereotypeType instances and
     * all Enumerations to EnumType instances.
     */
    private void init() {
        if (stereoTypes != null || profile == null || typeSystem == null)
            return;
        fixName(profile);
        internalProfileMetaModel = new InternaleProfileMetaModel(profile);
        internalProfileMetaModel.setTypeSystem(typeSystem);

        stereoTypes = new HashMap<String, Type>();
        List<org.eclipse.uml2.uml.Type> sts = getAllOwnedTypes(profile);
        for (Iterator<org.eclipse.uml2.uml.Type> iter = sts.iterator(); iter.hasNext();) {
            Object o = iter.next();
            if (o instanceof Stereotype) {
                Stereotype st = (Stereotype) o;
                fixName(st);
                String typeName = getFullName(st);
                Type t = new StereotypeType(this.getTypeSystem(), typeName, st);
                stereoTypes.put(typeName, t);
            } else if (o instanceof Enumeration) {
                Enumeration en = (Enumeration) o;
                fixName(en);
                String typeName = getFullName(en);
                Type t = new EnumType(this.getTypeSystem(), typeName, en);
                stereoTypes.put(typeName, t);
            }
        }
        namespaces.add(profile.getName());
    }
    
    private List<org.eclipse.uml2.uml.Type> getAllOwnedTypes (Package pck) {
    	List<org.eclipse.uml2.uml.Type> result = new ArrayList<org.eclipse.uml2.uml.Type>();
    	result.addAll(pck.getOwnedTypes());
    	for (Package nested : pck.getNestedPackages()) {
    		result.addAll(getAllOwnedTypes(nested));
    	}
    	return result;
    }
    
    /**
     * It is not allowed to have whitespaces in profile, stereotype or tagged value names. Therefore we need to replace them w
     * @param name
     * @return
     */
    private static void fixName (NamedElement elem) {
    	if (elem.getName().matches(".*[\\s].*")) {
    		elem.setName(elem.getName().replaceAll("\\s", "_"));
    	}
    }

    public String getFullName(org.eclipse.uml2.uml.Type st) {
        return st.getQualifiedName();
    }

    public Type getTypeForName(String typeName) {
        Type result = stereoTypes.get(typeName);
        if (result==null && typeName.startsWith(profile.getName()+SyntaxConstants.NS_DELIM)) {
        	result = internalProfileMetaModel.getTypeForName(typeName);
        }
        return result;
    }

    public Type getType(Object obj) {
        if (obj instanceof EnumerationLiteral) {
            EnumerationLiteral el = (EnumerationLiteral) obj;
            String fqn = getFullName(el.getEnumeration());
            return getTypeSystem().getTypeForName(fqn);
        } else if (obj instanceof Element) {
            Element element = (Element) obj;
            List<Stereotype> stereotypes = element.getAppliedStereotypes();
            //if no stereotype is found, the stereotype is skipped or an Exception is thrown
            if (stereotypes.isEmpty())
            	//collection will be empty if the required profile is not loaded
            	if (errorIfStereotypeMissing && !stereotypes.toString().equals("[]"))
            		throw new RuntimeException("Stereotype could not be loaded! Possible hint: '"+stereotypes);
            	else
            		return null;
            
        	List<StereotypeType> types = new ArrayList<StereotypeType>();
        	// collect StereotypeTypes
            for (Iterator<Stereotype> iter = stereotypes.iterator(); iter.hasNext();) {
                Stereotype st = iter.next();
                StereotypeType stType = (StereotypeType) getTypeSystem().getTypeForName(getFullName(st));
                if (stType!=null) {
	                types.add(stType);
                }
            }
            switch (types.size()) {
            	case 0: return null;
            	case 1: return types.get(0);
            	// when more than one stereotype is applied we return a MultipleStereotypeType instance
            	// containing all applied stereotypes
            	default: return new MultipleStereotypeType(getTypeSystem(), types);
            }            	
        }
        return null;
    }

    public Set<Type> getKnownTypes() {
        return new HashSet<Type>(stereoTypes.values());
    }

    public TypeSystem getTypeSystem() {
        return typeSystem;
    }

    public void setTypeSystem(TypeSystem typeSystem) {
        this.typeSystem = typeSystem;
        init();
    }

    public String getName() {
        return profile.getName();
    }

    /**
     * @see MetaModel#getNamespaces()
     */
	public Set<String> getNamespaces() {
		return namespaces;
	}

}
